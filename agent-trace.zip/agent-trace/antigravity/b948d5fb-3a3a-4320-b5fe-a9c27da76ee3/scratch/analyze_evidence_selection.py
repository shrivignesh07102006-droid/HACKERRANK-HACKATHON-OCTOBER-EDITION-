import os
import sys
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

manifest = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv"))
sample_reqs = pd.read_csv(os.path.join(dataset_dir, "sample_deletion_requests.csv"))
sample_outs = pd.read_csv(os.path.join(dataset_dir, "sample_output.csv"))
identities = pd.read_csv(os.path.join(dataset_dir, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(dataset_dir, "user_audit_log.csv"))

merged = sample_reqs.merge(sample_outs, on="case_id")

for idx, r in merged.iterrows():
    cid = r["case_id"]
    email = r["email"]
    audit_at = r["audit_at"]
    status = r["deletion_status"]
    steps = json.loads(r["steps_json"])
    evs = sorted(list(set(s["evidence_id"] for s in steps if s["evidence_id"])))
    
    # Check all manifest files captured at or before audit_at
    avail_ev = manifest[manifest["captured_at"] <= audit_at].sort_values("captured_at", ascending=False)
    latest_few = avail_ev.head(3)[["file_id", "captured_at", "origin", "file_path"]].to_dict(orient="records")
    
    print(f"\n{cid} ({email}) audit_at={audit_at} -> actual={status}")
    print(f"  Cited evidence in golden output: {evs}")
    for k, s in enumerate(steps[:3]):
        print(f"    step {s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev={s['evidence_id']}")
    if len(steps) > 3:
        print(f"    ... ({len(steps)} steps total)")
    print("  Latest available evidence files before audit_at:")
    for lf in latest_few:
        is_cited = lf["file_id"] in evs
        print(f"    {'[*]' if is_cited else '[ ]'} {lf['file_id']} ({lf['captured_at']}) - {lf['origin']} - {lf['file_path']}")
