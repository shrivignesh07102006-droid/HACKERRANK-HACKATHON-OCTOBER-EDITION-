import sys
import pandas as pd
import glob
import os

sys.stdout.reconfigure(encoding='utf-8')

manifest = pd.read_csv('dataset/evidence_files.csv')
print(f"Total evidence files in manifest: {len(manifest)}")
manifest['ext'] = manifest['file_path'].apply(lambda x: os.path.splitext(x)[1])
print(manifest['ext'].value_counts())
print("\nOrigins count:", len(manifest['origin'].unique()))
print(manifest['origin'].value_counts()[:10])
