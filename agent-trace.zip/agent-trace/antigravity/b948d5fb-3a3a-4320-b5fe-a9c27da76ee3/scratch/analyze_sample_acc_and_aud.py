import pandas as pd, json, os

gold_df = pd.read_csv('dataset/sample_output.csv')
sample_reqs = pd.read_csv('dataset/sample_deletion_requests.csv')
req_map = {r['case_id']: r for _, r in sample_reqs.iterrows()}

for _, r in gold_df.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    accs = [s['resource_id'] for s in steps if s['system_id'] == 'account_service']
    auds = [s['resource_id'] for s in steps if s['system_id'] == 'security_service']
    req = req_map[cid]
    st = r['deletion_status']
    print(f"{cid:<8} | st={st:<11} | accs={accs} | auds={auds}")
