import sys
import pandas as pd
import json

sys.stdout.reconfigure(encoding='utf-8')

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')
merged = pd.merge(samples, golden, on='case_id')

for _, r in merged.iterrows():
    steps = json.loads(r['steps_json'])
    ev_ids = [s['evidence_id'] for s in steps if s.get('evidence_id')]
    ops = [s['operation'] for s in steps]
    print(f"{r['case_id']} | {r['email']} | rep:{r['reported_status']} -> actual:{r['deletion_status']} | ev_count:{len(ev_ids)} | ev:{ev_ids}")
