import sys
sys.path.insert(0, 'code')
import os
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

from auditor import DeletionAuditor

auditor = DeletionAuditor('dataset')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')

print("=== Analyzing Sample Mismatches ===")
for _, r in samples.iterrows():
    cid = r['case_id']
    subj = auditor.identity_graph.resolve(r['email'])
    res = auditor.audit_case(r)
    gold = golden[golden['case_id'] == cid].iloc[0]
    g_steps = json.loads(gold['steps_json'])
    p_steps = res.steps

    if res.deletion_status != gold['deletion_status'] or p_steps != g_steps:
        print(f"\n[{cid}] email={r['email']} user={subj.user_id if subj else 'None'}")
        print(f"  Pred Status: {res.deletion_status} | Gold Status: {gold['deletion_status']}")
        print(f"  Pred Steps ({len(p_steps)}):")
        for s in p_steps:
            print(f"    [{s['phase']}] {s['operation']} {s['system_id']}.{s['resource_id']} -> {s['state']} (ev: {s.get('evidence_id')})")
        print(f"  Gold Steps ({len(g_steps)}):")
        for s in g_steps:
            print(f"    [{s['phase']}] {s['operation']} {s['system_id']}.{s['resource_id']} -> {s['state']} (ev: {s.get('evidence_id')})")
