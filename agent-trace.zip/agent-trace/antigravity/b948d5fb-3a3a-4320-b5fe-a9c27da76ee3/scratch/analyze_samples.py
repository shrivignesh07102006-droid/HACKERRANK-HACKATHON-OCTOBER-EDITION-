import os
import sys
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

manifest_df = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv")).set_index("file_id")
sample_reqs = pd.read_csv(os.path.join(dataset_dir, "sample_deletion_requests.csv")).set_index("case_id")
sample_outs = pd.read_csv(os.path.join(dataset_dir, "sample_output.csv")).set_index("case_id")
identities = pd.read_csv(os.path.join(dataset_dir, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(dataset_dir, "user_audit_log.csv"))

print("=== DEEP ANALYSIS OF ALL 32 SAMPLE CASES ===")

case_summaries = []

for case_id in sorted(sample_reqs.index):
    req = sample_reqs.loc[case_id]
    out = sample_outs.loc[case_id]
    steps = json.loads(out["steps_json"])
    status = out["deletion_status"]
    
    email = req["email"]
    audit_at = req["audit_at"]
    reported_status = req["reported_status"]
    
    # Resolve user
    # Check by email (case-insensitive)
    matched_users = identities[identities["email"].str.lower() == email.lower()]
    user_id = matched_users.iloc[0]["user_id"] if len(matched_users) > 0 else None
    
    # Check audit log if not in current identities
    if not user_id:
        audit_match = audit_log[(audit_log["field_name"] == "email") & (audit_log["old_value"].str.lower() == email.lower())]
        if len(audit_match) > 0:
            user_id = audit_match.iloc[0]["user_id"]
    
    findings = [s for s in steps if s["phase"] == "FINDING"]
    remediations = [s for s in steps if s["phase"] == "REMEDIATION"]
    verifications = [s for s in steps if s["phase"] == "VERIFICATION"]
    
    cited_ev = sorted(list(set(s["evidence_id"] for s in steps if s["evidence_id"])))
    
    case_summaries.append({
        "case_id": case_id,
        "email": email,
        "user_id": user_id,
        "reported": reported_status,
        "actual": status,
        "finding_count": len(findings),
        "remediation_count": len(remediations),
        "verification_count": len(verifications),
        "cited_evidence": cited_ev,
        "finding_ops": [f["operation"] for f in findings],
        "audit_at": audit_at
    })

df_summary = pd.DataFrame(case_summaries)
print(df_summary[["case_id", "email", "user_id", "reported", "actual", "finding_count", "remediation_count", "verification_count", "cited_evidence"]].to_string())
