import sys
import glob
import json
import sqlite3
import time
import base64
import zlib
import re

sys.stdout.reconfigure(encoding='utf-8')

t0 = time.time()

# 1. SQL files
sql_files = glob.glob('dataset/evidence/databases/*.sql')
dbs = {}
for p in sql_files:
    fname = p.replace('\\', '/').split('/')[-1]
    conn = sqlite3.connect(':memory:')
    with open(p, 'r', encoding='utf-8') as f:
        conn.executescript(f.read())
    dbs[fname] = conn

# 2. JSON files
json_files = glob.glob('dataset/evidence/records/*.json')
jsons = {}
for p in json_files:
    fname = p.replace('\\', '/').split('/')[-1]
    with open(p, 'r', encoding='utf-8') as f:
        jsons[fname] = json.load(f)

# 3. TXT file
txt_files = glob.glob('dataset/evidence/records/*.txt')
txts = {}
for p in txt_files:
    fname = p.replace('\\', '/').split('/')[-1]
    with open(p, 'r', encoding='utf-8') as f:
        txts[fname] = f.readlines()

# 4. LOG files
log_files = glob.glob('dataset/evidence/logs/*.log')
logs = {}
for p in log_files:
    fname = p.replace('\\', '/').split('/')[-1]
    with open(p, 'r', encoding='utf-8') as f:
        logs[fname] = f.readlines()

# 5. PDF files
pdf_files = glob.glob('dataset/evidence/documents/*.pdf')
pdfs = {}
for p in pdf_files:
    fname = p.replace('\\', '/').split('/')[-1]
    with open(p, 'rb') as f:
        data = f.read()
    texts = []
    pos = 0
    while True:
        s_idx = data.find(b'stream', pos)
        if s_idx == -1: break
        e_idx = data.find(b'endstream', s_idx)
        if e_idx == -1: break
        meta_start = data.rfind(b'<<', 0, s_idx)
        meta = data[meta_start:s_idx] if meta_start != -1 else b''
        content_start = s_idx + len(b'stream')
        while content_start < e_idx and data[content_start] in (10, 13):
            content_start += 1
        raw_stream = data[content_start:e_idx].rstrip(b'\r\n')
        if b'ASCII85Decode' in meta:
            s_adobe = raw_stream
            if not s_adobe.startswith(b'<~'): s_adobe = b'<~' + s_adobe
            if not s_adobe.endswith(b'~>'): s_adobe = s_adobe + b'~>'
            try: raw_stream = base64.a85decode(s_adobe, adobe=True)
            except Exception: pass
        if b'FlateDecode' in meta:
            try: raw_stream = zlib.decompress(raw_stream)
            except Exception: pass
        tj_matches = re.findall(rb'\((.*?)\)\s*Tj', raw_stream)
        for tm in tj_matches:
            t = tm.decode('latin1', errors='ignore').strip()
            if t: texts.append(t)
        pos = e_idx + len(b'endstream')
    pdfs[fname] = texts

t1 = time.time()
print(f"Loaded ALL evidence files in {t1 - t0:.2f} seconds!")
print(f"  SQL: {len(dbs)}, JSON: {len(jsons)}, TXT: {len(txts)}, LOGS: {len(logs)}, PDF: {len(pdfs)}")
