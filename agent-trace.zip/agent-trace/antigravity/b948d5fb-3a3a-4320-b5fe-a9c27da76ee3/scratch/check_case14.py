import sys, os, json, pandas as pd
sys.path.insert(0, os.path.abspath('code'))

from auditor import DeletionAuditor

auditor = DeletionAuditor('dataset')
req = pd.read_csv('dataset/sample_deletion_requests.csv')
gold = pd.read_csv('dataset/sample_output.csv')
for cid in ['case_11', 'case_12', 'case_13', 'case_14']:
    row = req[req['case_id'] == cid].iloc[0]
    res = auditor.audit_case(row)
    g_row = gold[gold['case_id'] == cid].iloc[0]
    g_steps = json.loads(g_row['steps_json'])
    match = (res.deletion_status == g_row['deletion_status'] and res.steps == g_steps)
    print(f"\n=== {cid}: match={match} (pred_st={res.deletion_status}, gold_st={g_row['deletion_status']}) ===")
    if not match:
        print("Pred steps:")
        for s in res.steps: print(' ', s)
        print("Gold steps:")
        for s in g_steps: print(' ', s)
