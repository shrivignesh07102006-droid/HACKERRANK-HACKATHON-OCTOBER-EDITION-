import pandas as pd
manifest = pd.read_csv('dataset/evidence_files.csv')
target_fids = ['evidence_54', 'evidence_94', 'evidence_56', 'evidence_92', 'evidence_51']
for _, r in manifest[manifest['file_id'].isin(target_fids)].iterrows():
    print(f"{r['file_id']:<15} {r['captured_at']:<25} {r['origin']:<35} {r['file_path']}")
