import pandas as pd
import json

act_df = pd.read_csv('dataset/system_activity.csv')
del_act = act_df[act_df['source_system'] == 'deletion_worker'].copy()
del_act['dt'] = pd.to_datetime(del_act['event_time'])

req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: json.loads(r['steps_json']) for _, r in gold_df.iterrows()}

for _, row in req_df.iterrows():
    cid = row['case_id']
    req_dt = pd.to_datetime(row['requested_at'])
    rep_dt = pd.to_datetime(row['reported_at'])
    
    # window between req_dt and rep_dt + 15 min
    w = del_act[(del_act['dt'] >= req_dt) & (del_act['dt'] <= rep_dt + pd.Timedelta(minutes=30))]
    worker_res = list(w['resource_id'])
    gold_res = [s['resource_id'] for s in gold_map[cid]]
    print(f"{cid}: worker_res={worker_res} | gold_res={gold_res}")
