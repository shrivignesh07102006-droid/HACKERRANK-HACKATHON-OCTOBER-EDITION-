import sqlite3, json, os

print("=== evidence_57 ===")
conn = sqlite3.connect(":memory:")
with open("dataset/evidence/databases/customer_search_primary_20260910.sql", "r") as fp:
    conn.executescript(fp.read())
tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
print("Tables:", tables)
for t in tables:
    rows = conn.execute(f"SELECT * FROM {t}").fetchall()
    print(f"  {t}: {len(rows)} rows")
    for r in rows:
        print("   ", r)
conn.close()

print("\n=== evidence_59 ===")
with open("dataset/evidence/records/customer_export_jobs_20260914.json", "r") as fp:
    d = json.load(fp)
    print(json.dumps(d, indent=2))

print("\n=== evidence_58 ===")
import zlib, re
with open("dataset/evidence/documents/delivery_correction_attachment.pdf", "rb") as fp:
    content = fp.read()
    streams = re.findall(b"stream[\r\n]+(.*?)[\r\n]+endstream", content, re.DOTALL)
    for s in streams:
        try:
            print(zlib.decompress(s).decode("utf-8", "ignore"))
        except Exception:
            pass
