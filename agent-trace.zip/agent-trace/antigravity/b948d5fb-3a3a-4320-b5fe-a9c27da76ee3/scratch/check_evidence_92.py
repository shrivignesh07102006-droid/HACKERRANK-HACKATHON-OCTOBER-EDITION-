import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json') as f:
    d = json.load(f)

exp = d.get('service_exports', {})
for svc, val in exp.items():
    sval = json.dumps(val)
    if '7012' in sval or '3954' in sval:
        print(f"Found in {svc}!")
