import os
import sys
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

manifest = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv")).set_index("file_id")
sample_reqs = pd.read_csv(os.path.join(dataset_dir, "sample_deletion_requests.csv")).set_index("case_id")
sample_outs = pd.read_csv(os.path.join(dataset_dir, "sample_output.csv")).set_index("case_id")

for case_id, req_row in sample_reqs.iterrows():
    audit_at = req_row["audit_at"]
    out_row = sample_outs.loc[case_id]
    steps = json.loads(out_row["steps_json"])
    cited_evidence = set(s["evidence_id"] for s in steps if s["evidence_id"])
    print(f"\n{case_id} (audit_at: {audit_at}):")
    for ev in sorted(cited_evidence):
        ev_row = manifest.loc[ev]
        cap_at = ev_row["captured_at"]
        valid = cap_at <= audit_at
        diff = pd.to_datetime(audit_at) - pd.to_datetime(cap_at)
        print(f"  Cited: {ev} ({ev_row['file_path']}) captured_at: {cap_at} <= audit_at? {valid} (diff: {diff})")
