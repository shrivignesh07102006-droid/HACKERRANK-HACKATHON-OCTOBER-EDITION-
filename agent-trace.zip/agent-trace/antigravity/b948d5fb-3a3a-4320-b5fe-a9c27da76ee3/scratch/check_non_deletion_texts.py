import sys
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
df = pd.read_csv('dataset/deletion_requests.csv')
for cid in ['case_535', 'case_540', 'case_541', 'case_542']:
    r = df[df['case_id'] == cid].iloc[0]
    print(f"[{cid}] email={r['email']} rep={r['reported_status']}")
    print(f"text: {r['request_text']}\n")
