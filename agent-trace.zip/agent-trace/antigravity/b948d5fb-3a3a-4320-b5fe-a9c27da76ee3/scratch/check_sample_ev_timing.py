import sys
import pandas as pd
import json

sys.stdout.reconfigure(encoding='utf-8')

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')
manifest = pd.read_csv('dataset/evidence_files.csv').set_index('file_id')

merged = pd.merge(samples, golden, on='case_id')

for _, r in merged.iterrows():
    cid = r['case_id']
    audit_at = r['audit_at']
    steps = json.loads(r['steps_json'])
    evs = set(s['evidence_id'] for s in steps if s.get('evidence_id'))
    for ev in evs:
        cap_at = manifest.loc[ev, 'captured_at']
        origin = manifest.loc[ev, 'origin']
        path = manifest.loc[ev, 'file_path']
        diff = pd.to_datetime(audit_at) - pd.to_datetime(cap_at)
        print(f"{cid} | audit_at:{audit_at} | ev:{ev} captured_at:{cap_at} | diff:{diff} | origin:{origin}")
