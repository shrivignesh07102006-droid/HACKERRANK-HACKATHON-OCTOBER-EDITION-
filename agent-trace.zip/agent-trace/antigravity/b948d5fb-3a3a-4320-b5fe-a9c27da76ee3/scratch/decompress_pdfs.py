import zlib, re, glob, os

for fpath in glob.glob('dataset/evidence/documents/*.pdf'):
    fname = os.path.basename(fpath)
    with open(fpath, 'rb') as f:
        data = f.read()
    print(f"\n=== {fname} ===")
    idx = 0
    while True:
        s_pos = data.find(b'stream\n', idx)
        if s_pos == -1: break
        content_start = s_pos + 7
        e_pos = data.find(b'endstream', content_start)
        if e_pos == -1: break
        raw_stream = data[content_start:e_pos].rstrip(b'\r\n')
        
        # Try zlib
        try:
            decompressed = zlib.decompress(raw_stream)
            text = decompressed.decode('latin1', errors='ignore')
            matches = re.findall(r'\(([^\)]+)\)', text)
            if matches:
                print('Stream text:', ' '.join(matches))
        except Exception:
            # Try ASCII85
            pass
        idx = e_pos + 9
