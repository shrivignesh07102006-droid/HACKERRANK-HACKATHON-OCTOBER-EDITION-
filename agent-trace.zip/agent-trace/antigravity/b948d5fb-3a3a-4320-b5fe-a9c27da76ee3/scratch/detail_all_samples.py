import sys
import pandas as pd
import json

sys.stdout.reconfigure(encoding='utf-8')

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')
merged = pd.merge(samples, golden, on='case_id')

for _, r in merged.iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    evs = set(s['evidence_id'] for s in steps if s.get('evidence_id'))
    print(f"[{cid}] email={r['email']} status={status} evs={evs}")
    for s in steps:
        print(f"   {s['phase']} | {s['operation']} | {s['system_id']}.{s['resource_id']} | state={s['state']} | ev='{s.get('evidence_id')}'")
