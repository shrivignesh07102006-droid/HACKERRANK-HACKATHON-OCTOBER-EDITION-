import os, sys, json
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from auditor import DeletionAuditor

auditor = DeletionAuditor('dataset')
req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}

mismatch_report = []

print("Running deep diagnostic on all 32 sample cases...")

for _, row in req_df.iterrows():
    cid = row['case_id']
    res = auditor.audit_case(row)
    pred_st = res.deletion_status
    pred_steps = res.steps
    
    gold_row = gold_map[cid]
    gold_st = gold_row['deletion_status']
    gold_steps = json.loads(gold_row['steps_json'])
    
    is_status_match = (pred_st == gold_st)
    is_exact_match = (is_status_match and pred_steps == gold_steps)
    
    if not is_exact_match:
        # Classify differences
        diff_info = {
            'case_id': cid,
            'email': row['email'],
            'status_pred': pred_st,
            'status_gold': gold_st,
            'pred_count': len(pred_steps),
            'gold_count': len(gold_steps),
            'pred_steps': pred_steps,
            'gold_steps': gold_steps,
            'differences': []
        }
        
        # Compare step by step
        # 1. Missing or extra steps
        pred_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) for s in pred_steps]
        gold_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) for s in gold_steps]
        
        missing_in_pred = [s for s in gold_steps if (s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) not in pred_keys]
        extra_in_pred = [s for s in pred_steps if (s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) not in gold_keys]
        
        diff_info['missing_in_pred'] = missing_in_pred
        diff_info['extra_in_pred'] = extra_in_pred
        mismatch_report.append(diff_info)

print(f"\nTotal mismatched cases: {len(mismatch_report)} / 32")
print("=" * 80)

for d in mismatch_report:
    cid = d['case_id']
    print(f"\n### Case: {cid} ({d['email']})")
    print(f"Status: Pred={d['status_pred']} | Gold={d['status_gold']} | Step Counts: Pred={d['pred_count']} vs Gold={d['gold_count']}")
    
    if d['missing_in_pred']:
        print("  [-] MISSING in Pred:")
        for s in d['missing_in_pred']:
            print(f"      Phase: {s['phase']:<12} | Sys: {s['system_id']:<20} | Res: {s['resource_id']:<20} | Op: {s['operation']:<25} | St: {s['state']:<10} | Ev: {s['evidence_id']}")
            
    if d['extra_in_pred']:
        print("  [+] EXTRA in Pred:")
        for s in d['extra_in_pred']:
            print(f"      Phase: {s['phase']:<12} | Sys: {s['system_id']:<20} | Res: {s['resource_id']:<20} | Op: {s['operation']:<25} | St: {s['state']:<10} | Ev: {s['evidence_id']}")

