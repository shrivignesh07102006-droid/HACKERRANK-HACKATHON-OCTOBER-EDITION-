import json, sys, os
sys.path.insert(0, os.path.abspath('.'))
import pandas as pd
from code.identity import build_identity_graph
from code.evidence_index import EvidenceIndex
from code.auditor import DeletionAuditor

def main():
    gold_df = pd.read_csv('dataset/sample_output.csv')
    requests_df = pd.read_csv('dataset/sample_deletion_requests.csv')
    
    id_graph = build_identity_graph('dataset/user_identities.csv', 'dataset/user_audit_log.csv')
    ev_index = EvidenceIndex('dataset/evidence_files.csv', 'dataset/evidence')
    auditor = DeletionAuditor(id_graph, ev_index, 'dataset/deletion_rules.csv', 'dataset/system_activity.csv')
    
    gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}
    
    print(f"{'Case':<9} | {'Pred Status':<12} | {'Gold Status':<12} | {'P_Steps':<7} | {'G_Steps':<7} | {'Match?':<6} | Notes")
    print("-" * 85)
    
    status_matches = 0
    exact_matches = 0
    
    for _, row in requests_df.iterrows():
        cid = row['case_id']
        email = row['email']
        audit_at = row['audit_at']
        req_text = row['request_text']
        
        status, steps = auditor.audit_case(cid, email, audit_at, req_text)
        gold = gold_map[cid]
        gold_status = gold['deletion_status']
        gold_steps = json.loads(gold['steps_json'])
        
        s_match = (status == gold_status)
        if s_match: status_matches += 1
        
        # Check exact steps match
        e_match = False
        if s_match and len(steps) == len(gold_steps):
            e_match = True
            for ps, gs in zip(steps, gold_steps):
                for k in ['phase', 'system_id', 'resource_id', 'operation', 'state', 'evidence_id']:
                    if ps.get(k) != gs.get(k):
                        e_match = False
                        break
        if e_match: exact_matches += 1
        
        notes = []
        if not s_match:
            notes.append(f"STATUS MISMATCH (pred={status}, gold={gold_status})")
        elif len(steps) != len(gold_steps):
            notes.append(f"Step count diff (pred={len(steps)}, gold={len(gold_steps)})")
        elif not e_match:
            notes.append("Step content diff")
        else:
            notes.append("EXACT MATCH")
            
        print(f"{cid:<9} | {status:<12} | {gold_status:<12} | {len(steps):<7} | {len(gold_steps):<7} | {str(e_match):<6} | {'; '.join(notes)}")
        
    print("-" * 85)
    print(f"Status Accuracy: {status_matches}/32 ({status_matches/32*100:.1f}%)")
    print(f"Exact Matches:   {exact_matches}/32 ({exact_matches/32*100:.1f}%)")

if __name__ == '__main__':
    main()
