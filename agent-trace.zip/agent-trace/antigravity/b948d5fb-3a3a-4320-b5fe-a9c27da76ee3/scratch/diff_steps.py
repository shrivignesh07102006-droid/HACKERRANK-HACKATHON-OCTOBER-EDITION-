import pandas as pd, json, sys, os
sys.path.insert(0, os.path.abspath('code'))
sys.path.insert(0, r"C:\Users\ACER\.gemini\antigravity-ide\brain\b948d5fb-3a3a-4320-b5fe-a9c27da76ee3\scratch")
from identity import IdentityGraph
from test_perfect_auditor_v2 import CompleteEvidenceIndexV2, audit_case_perfect_v2

id_graph = IdentityGraph('dataset')
index = CompleteEvidenceIndexV2('dataset')
req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}

for cid in ['case_09', 'case_10', 'case_12', 'case_31', 'case_32']:
    row = req_df[req_df['case_id'] == cid].iloc[0]
    st, steps = audit_case_perfect_v2(row, index, id_graph)
    gsteps = json.loads(gold_map[cid]['steps_json'])
    print(f"\n=== {cid} ===")
    print("Pred steps:")
    for s in steps:
        print(f"  {s['phase']:<12} {s['system_id']:<20} {s['resource_id']:<20} {s['operation']:<25} {s['evidence_id']}")
    print("Gold steps:")
    for s in gsteps:
        print(f"  {s['phase']:<12} {s['system_id']:<20} {s['resource_id']:<20} {s['operation']:<25} {s['evidence_id']}")
