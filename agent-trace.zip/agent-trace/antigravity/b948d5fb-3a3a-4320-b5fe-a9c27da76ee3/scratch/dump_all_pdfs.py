import base64, zlib, re, glob, os

pdf_records = []

for fpath in sorted(glob.glob('dataset/evidence/documents/*.pdf')):
    fname = os.path.basename(fpath)
    with open(fpath, 'rb') as f:
        data = f.read()
    
    idx = 0
    all_text = []
    while True:
        s_pos = data.find(b'stream\n', idx)
        if s_pos == -1: break
        content_start = s_pos + 7
        e_pos = data.find(b'endstream', content_start)
        if e_pos == -1: break
        raw_stream = data[content_start:e_pos].rstrip(b'\r\n')
        
        try:
            s_adobe = raw_stream
            if not s_adobe.startswith(b'<~'): s_adobe = b'<~' + s_adobe
            if not s_adobe.endswith(b'~>'): s_adobe = s_adobe + b'~>'
            a85 = base64.a85decode(s_adobe, adobe=True)
            dec = zlib.decompress(a85)
            text = dec.decode('latin1', errors='ignore')
            matches = re.findall(r'\(([^\)]+)\)', text)
            all_text.extend(matches)
        except Exception:
            pass
        idx = e_pos + 9
        
    full_str = ' '.join(all_text)
    print(f"=== {fname} ({len(all_text)} tokens) ===")
    print(full_str[:300])
    print()
