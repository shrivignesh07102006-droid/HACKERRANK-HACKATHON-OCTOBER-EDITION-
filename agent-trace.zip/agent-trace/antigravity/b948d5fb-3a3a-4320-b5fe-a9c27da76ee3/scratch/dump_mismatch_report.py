import os, sys, json
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from auditor import DeletionAuditor

auditor = DeletionAuditor('dataset')
req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}

out_lines = []
out_lines.append(f"TOTAL SAMPLE CASES: {len(req_df)}\n")

mismatches = 0
matches = 0

for _, row in req_df.iterrows():
    cid = row['case_id']
    res = auditor.audit_case(row)
    pred_st = res.deletion_status
    pred_steps = res.steps
    
    gold_row = gold_map[cid]
    gold_st = gold_row['deletion_status']
    gold_steps = json.loads(gold_row['steps_json'])
    
    is_status_match = (pred_st == gold_st)
    is_exact_match = (is_status_match and pred_steps == gold_steps)
    
    if is_exact_match:
        matches += 1
        out_lines.append(f"[{cid}] MATCH: status={pred_st}, steps={len(pred_steps)}")
    else:
        mismatches += 1
        out_lines.append(f"[{cid}] MISMATCH: status_pred={pred_st}, status_gold={gold_st}, pred_steps={len(pred_steps)}, gold_steps={len(gold_steps)}")
        pred_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) for s in pred_steps]
        gold_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) for s in gold_steps]
        
        missing = [s for s in gold_steps if (s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) not in pred_keys]
        extra = [s for s in pred_steps if (s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) not in gold_keys]
        
        if missing:
            out_lines.append("  MISSING IN PRED:")
            for s in missing:
                out_lines.append(f"    - {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev:{s['evidence_id']}")
        if extra:
            out_lines.append("  EXTRA IN PRED:")
            for s in extra:
                out_lines.append(f"    + {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev:{s['evidence_id']}")
        
        # Also print full gold vs full pred for comparison
        out_lines.append("  GOLD STEPS:")
        for s in gold_steps:
            out_lines.append(f"    G{s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev:{s['evidence_id']}")
        out_lines.append("  PRED STEPS:")
        for s in pred_steps:
            out_lines.append(f"    P{s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev:{s['evidence_id']}")
        out_lines.append("-" * 60)

out_lines.append(f"\nSUMMARY: {matches} exact matches, {mismatches} mismatches out of {len(req_df)}")

out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mismatch_report.txt")
with open(out_path, "w", encoding="utf-8") as f:
    f.write("\n".join(out_lines))

print(f"Report written to {out_path}. Exact matches: {matches}, Mismatches: {mismatches}")
