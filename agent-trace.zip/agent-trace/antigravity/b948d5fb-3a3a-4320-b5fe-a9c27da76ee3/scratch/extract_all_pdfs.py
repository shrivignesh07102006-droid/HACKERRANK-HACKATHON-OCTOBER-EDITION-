import sys
import zlib
import re
import glob

sys.stdout.reconfigure(encoding='utf-8')

for path in glob.glob('dataset/evidence/documents/*.pdf'):
    print(f"=== {path} ===")
    with open(path, 'rb') as f:
        data = f.read()
    streams = re.findall(b'stream[\r\n]+(.*?)[\r\n]+endstream', data, re.DOTALL)
    extracted = []
    for s in streams:
        try:
            decomp = zlib.decompress(s)
            extracted.append(decomp.decode('latin1', errors='ignore'))
        except Exception:
            pass
    full_text = " ".join(extracted)
    # Extract readable text from Tj / TJ operators
    tj_text = re.findall(r'\((.*?)\)\s*Tj', full_text)
    print("Text count:", len(tj_text))
    print("Lines:", " | ".join(tj_text[:20]))
    # Search for identifiers: user_, account_, support_, @, etc.
    emails = re.findall(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', full_text)
    print("Found emails:", set(emails))
    res = re.findall(r'(?:account|support|audit|search|data_flow|backup)_[0-9]+', full_text)
    print("Found resources:", set(res))
