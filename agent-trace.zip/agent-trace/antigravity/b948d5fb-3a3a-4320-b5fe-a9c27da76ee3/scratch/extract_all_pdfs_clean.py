import sys
import base64
import zlib
import re
import glob

sys.stdout.reconfigure(encoding='utf-8')

def extract_pdf_text(filepath):
    with open(filepath, 'rb') as f:
        data = f.read()
    
    texts = []
    # Find all objects with /Contents or streams
    # Find all stream blocks with /Filter
    pattern = re.compile(rb'<<\s*(.*?)\s*>>\s*stream[\r\n]+(.*?)[\r\n]+endstream', re.DOTALL)
    for meta, stream_bytes in pattern.findall(data):
        raw_stream = stream_bytes.strip()
        # Decode ASCII85 if present
        if b'ASCII85Decode' in meta:
            if not raw_stream.startswith(b'<~'):
                raw_stream = b'<~' + raw_stream
            if not raw_stream.endswith(b'~>'):
                raw_stream = raw_stream + b'~>'
            try:
                raw_stream = base64.a85decode(raw_stream, adobe=True)
            except Exception:
                continue
        # Decode FlateDecode if present
        if b'FlateDecode' in meta:
            try:
                raw_stream = zlib.decompress(raw_stream)
            except Exception:
                continue
        
        # Extract text in parentheses ( ... ) Tj or [( ... )] TJ
        tj_matches = re.findall(rb'\((.*?)\)\s*Tj', raw_stream)
        for tm in tj_matches:
            try:
                t = tm.decode('latin1')
                if t.strip():
                    texts.append(t.strip())
            except Exception:
                pass
    return texts

for path in glob.glob('dataset/evidence/documents/*.pdf'):
    print(f"\n==================== {path} ====================")
    lines = extract_pdf_text(path)
    print(f"Total lines: {len(lines)}")
    for l in lines:
        print("  ", l)
