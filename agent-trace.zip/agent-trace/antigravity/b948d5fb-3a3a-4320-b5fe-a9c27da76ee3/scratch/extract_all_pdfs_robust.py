import sys
import base64
import zlib
import re
import glob

sys.stdout.reconfigure(encoding='utf-8')

def extract_pdf_text_robust(filepath):
    with open(filepath, 'rb') as f:
        data = f.read()

    texts = []
    # Find each "stream\n"
    pos = 0
    while True:
        s_idx = data.find(b'stream', pos)
        if s_idx == -1:
            break
        e_idx = data.find(b'endstream', s_idx)
        if e_idx == -1:
            break
        
        # Get metadata dictionary before stream
        meta_start = data.rfind(b'<<', 0, s_idx)
        meta = data[meta_start:s_idx] if meta_start != -1 else b''
        
        # Stream content starts after stream\r\n or stream\n
        content_start = s_idx + len(b'stream')
        while content_start < e_idx and data[content_start] in (10, 13):
            content_start += 1
        
        raw_stream = data[content_start:e_idx].rstrip(b'\r\n')
        
        # Filter decoding
        if b'ASCII85Decode' in meta:
            s_adobe = raw_stream
            if not s_adobe.startswith(b'<~'):
                s_adobe = b'<~' + s_adobe
            if not s_adobe.endswith(b'~>'):
                s_adobe = s_adobe + b'~>'
            try:
                raw_stream = base64.a85decode(s_adobe, adobe=True)
            except Exception:
                pass
        
        if b'FlateDecode' in meta:
            try:
                raw_stream = zlib.decompress(raw_stream)
            except Exception:
                pass
        
        # Extract text strings ( ... ) Tj
        tj_matches = re.findall(rb'\((.*?)\)\s*Tj', raw_stream)
        for tm in tj_matches:
            t = tm.decode('latin1', errors='ignore').strip()
            if t:
                texts.append(t)
        
        pos = e_idx + len(b'endstream')
        
    return texts

for path in glob.glob('dataset/evidence/documents/*.pdf'):
    print(f"\n==================== {path} ====================")
    lines = extract_pdf_text_robust(path)
    print(f"Total lines: {len(lines)}")
    for l in lines[:15]:
        print("  ", l)
