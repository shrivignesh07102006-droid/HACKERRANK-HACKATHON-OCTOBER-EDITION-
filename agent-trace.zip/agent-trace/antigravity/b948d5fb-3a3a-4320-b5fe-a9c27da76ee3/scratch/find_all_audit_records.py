import json, glob, os
import pandas as pd

df = pd.read_csv('dataset/sample_output.csv')
audit_records = {}

for _, r in df.iterrows():
    steps = json.loads(r['steps_json'])
    for s in steps:
        if s['system_id'] == 'security_service' and s['resource_id'].startswith('audit_record_'):
            audit_records[s['resource_id']] = (r['case_id'], r['deletion_status'], s['evidence_id'])

print(f"Total audit records in sample_output: {len(audit_records)}")

# Now search where each audit_record appears across dataset
all_files = glob.glob('dataset/**', recursive=True)
all_files = [f for f in all_files if f.endswith(('.json', '.log', '.sql', '.csv', '.txt')) and 'sample_output' not in f]

file_contents = {}
for f in all_files:
    try:
        with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
            file_contents[f] = fp.read()
    except:
        pass

for rec_id, (cid, status, evid) in audit_records.items():
    found_in = []
    for f, content in file_contents.items():
        if rec_id in content:
            found_in.append(f)
    print(f"{cid:<8} | {rec_id:<20} | status: {status:<12} | cited: {evid:<15} | found in: {len(found_in)} files")
    for f in found_in:
        print(f"     -> {os.path.basename(f)}")
