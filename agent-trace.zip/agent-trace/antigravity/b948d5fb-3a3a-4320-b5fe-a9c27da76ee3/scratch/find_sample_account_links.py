import json, pandas as pd

requests = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')
sample_output = pd.read_csv('dataset/sample_output.csv')
users = pd.read_csv('dataset/user_identities.csv')

user_email_map = dict(zip(users['email'], users['user_id']))

activity['dt'] = pd.to_datetime(activity['event_time'])

for _, req in requests.iterrows():
    cid = req['case_id']
    email = req['email']
    uid = user_email_map.get(email)
    req_dt = pd.to_datetime(req['requested_at'])
    rep_dt = pd.to_datetime(req['reported_at'])
    aud_dt = pd.to_datetime(req['audit_at'])
    
    g_row = sample_output[sample_output['case_id'] == cid].iloc[0]
    g_steps = json.loads(g_row['steps_json'])
    g_acc = [s['resource_id'] for s in g_steps if s['system_id'] == 'account_service']
    g_sec = [s['resource_id'] for s in g_steps if s['system_id'] == 'security_service']
    
    # Check activity around reported_at (+- 4 hours)
    window = activity[(activity['dt'] >= rep_dt - pd.Timedelta(hours=4)) & (activity['dt'] <= rep_dt + pd.Timedelta(hours=2))]
    dw_acc = window[(window['source_system'] == 'deletion_worker') & (window['target_system'] == 'account_service')]['resource_id'].tolist()
    
    print(f"{cid:<8} | uid={str(uid):<9} | rep_dt={str(rep_dt)[:19]} | gold_acc={str(g_acc):<18} | found_acc_dw={dw_acc}")
