import sys
sys.path.insert(0, 'code')
import os
import json
import sqlite3
import pandas as pd
from identity import IdentityGraph

sys.stdout.reconfigure(encoding='utf-8')

g = IdentityGraph('dataset')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')
manifest = pd.read_csv('dataset/evidence_files.csv')

# Build mapping of file_id -> actual file content
print("Searching evidence for sample cases...")
matches_per_case = {}

for _, r in samples.iterrows():
    cid = r['case_id']
    email = r['email']
    audit_at = r['audit_at']
    subj = g.resolve(email)
    gold_row = golden[golden['case_id'] == cid].iloc[0]
    gold_steps = json.loads(gold_row['steps_json'])
    gold_evs = set(s['evidence_id'] for s in gold_steps if s.get('evidence_id'))
    
    print(f"[{cid}] user={subj.user_id} email={email} expected_status={gold_row['deletion_status']} expected_evs={gold_evs}")
