import os, sys, json
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from auditor import DeletionAuditor

auditor = DeletionAuditor('dataset')
req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}

mismatches = []
for _, row in req_df.iterrows():
    cid = row['case_id']
    res = auditor.audit_case(row)
    g_row = gold_map[cid]
    g_status = g_row['deletion_status']
    g_steps = json.loads(g_row['steps_json'])
    p_status = res.deletion_status
    p_steps = res.steps

    if p_status != g_status or p_steps != g_steps:
        mismatches.append({
            'case_id': cid,
            'email': row['email'],
            'requested_at': row['requested_at'],
            'reported_at': row['reported_at'],
            'audit_at': row['audit_at'],
            'pred_status': p_status,
            'gold_status': g_status,
            'pred_steps': p_steps,
            'gold_steps': g_steps
        })

print(f"Total failing cases: {len(mismatches)}")
for m in mismatches:
    print(f"- {m['case_id']}: pred={m['pred_status']} ({len(m['pred_steps'])} steps) vs gold={m['gold_status']} ({len(m['gold_steps'])} steps)")
