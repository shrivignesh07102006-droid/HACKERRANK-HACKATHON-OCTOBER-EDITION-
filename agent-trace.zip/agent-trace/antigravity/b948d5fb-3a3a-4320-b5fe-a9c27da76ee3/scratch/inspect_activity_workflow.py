import pandas as pd

df = pd.read_csv('dataset/system_activity.csv')
for i in range(3730, 3748):
    row = df.loc[i]
    print(f"{row['activity_id']} | {row['event_time']} | {row['event_type']:25} | {row['source_system']:15} -> {row['target_system']:18} | {row['resource_id']:20} | {row['reported_result']}")
