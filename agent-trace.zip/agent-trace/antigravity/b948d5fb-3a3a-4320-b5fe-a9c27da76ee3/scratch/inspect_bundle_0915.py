import json
with open('dataset/evidence/records/service_resource_export_20260915_114455.json') as f:
    d = json.load(f)
exports = d.get('service_exports', {})
for svc, data in exports.items():
    for k, v in data.items():
        if isinstance(v, list):
            for r in v:
                res_id = r.get('resource_id')
                subj = r.get('subject_reference') or r.get('customer_reference')
                em = r.get('email') or r.get('owner_email') or r.get('requester_email') or r.get('customer_email')
                if not em and isinstance(r.get('profile'), dict):
                    em = r['profile'].get('email')
                    subj = r['profile'].get('customer_reference')
                print(f"{svc:<22} {str(res_id):<20} {str(subj):<12} {str(em)}")
