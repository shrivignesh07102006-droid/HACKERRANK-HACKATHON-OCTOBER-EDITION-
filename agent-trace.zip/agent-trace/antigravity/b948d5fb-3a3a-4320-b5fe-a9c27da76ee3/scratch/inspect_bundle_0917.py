import json
with open('dataset/evidence/records/customer_data_snapshot_bundle_20260917.json') as f:
    d = json.load(f)
for s in d.get('snapshots', []):
    ds = s.get('data_store')
    for r in s.get('records', []):
        res_id = r.get('resource_id')
        subj = r.get('subject_reference') or r.get('customer_reference')
        em = r.get('email') or r.get('owner_email') or r.get('requester_email')
        print(f"{ds:<22} {res_id:<20} {str(subj):<12} {str(em)}")
