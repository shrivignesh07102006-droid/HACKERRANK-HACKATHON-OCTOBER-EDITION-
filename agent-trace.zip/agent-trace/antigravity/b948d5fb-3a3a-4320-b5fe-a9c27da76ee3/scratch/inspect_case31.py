import pandas as pd, json

# Search system_activity.csv
act_df = pd.read_csv('dataset/system_activity.csv')
print("system_activity matches for user_541:")
m = act_df[act_df['details'].str.contains('user_541', na=False)]
print(m[['activity_id', 'event_time', 'source_system', 'target_system', 'resource_id', 'event_type', 'details']])

print("\nsystem_activity matches for account_4857:")
m2 = act_df[act_df['resource_id'] == 'account_4857']
print(m2[['activity_id', 'event_time', 'source_system', 'target_system', 'resource_id', 'event_type', 'details']])

print("\nsystem_activity matches for audit_record_6909:")
m3 = act_df[act_df['resource_id'] == 'audit_record_6909']
print(m3[['activity_id', 'event_time', 'source_system', 'target_system', 'resource_id', 'event_type', 'details']])

# Search evidence_51
with open('dataset/evidence/records/records_assurance_snapshot_bundle_006.json') as f:
    d = json.load(f)
    print("\nevidence_51 data_stores:")
    for s in d.get('snapshots', []):
        ds = s.get('data_store')
        recs = [r for r in s.get('records', []) if r.get('subject_reference') == 'user_541' or 'user_541' in str(r)]
        print(f"  Store: {ds}, matching recs: {recs}")
