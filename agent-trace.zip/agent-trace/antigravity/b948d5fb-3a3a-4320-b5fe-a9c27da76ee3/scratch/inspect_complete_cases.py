import pandas as pd, json
df = pd.read_csv('dataset/sample_output.csv')
complete_cases = df[df['deletion_status'] == 'COMPLETE']
print(f"Total COMPLETE cases: {len(complete_cases)}")
for _, r in complete_cases.iterrows():
    steps = json.loads(r['steps_json'])
    print(f"\n{r['case_id']} ({len(steps)} steps):")
    for s in steps:
        print(f"  {s['system_id']:<20} {s['resource_id']:<15} {s['operation']:<25} {s['state']:<10} {s['evidence_id']}")
