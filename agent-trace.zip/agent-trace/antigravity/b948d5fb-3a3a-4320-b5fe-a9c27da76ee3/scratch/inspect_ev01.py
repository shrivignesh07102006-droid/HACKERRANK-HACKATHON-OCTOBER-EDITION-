with open('dataset/evidence/logs/service_events_ap_south_20260915.log', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines in evidence_01: {len(lines)}")
for target in ['minjun.kim@gmail.com', 'lucia-torres@gmail.com', 'leonie.g9352@outlook.com', 'e.varga90@yahoo.com']:
    print(f"=== Matches for {target} ===")
    for l in lines:
        if target in l:
            print("  ", l.strip())
