import sqlite3
import json

conn = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_data_read_replica_20260921.sql', 'r', encoding='utf-8') as f:
    conn.executescript(f.read())
cur = conn.cursor()

for uid in ['user_53', 'user_51']:
    print(f"=== {uid} ===")
    for tbl in ['customer_data_primary', 'customer_data_read_replica']:
        cur.execute(f"SELECT resource_id, origin_system, collection_name, record_json FROM {tbl} WHERE record_json LIKE '%{uid}%'")
        rows = cur.fetchall()
        for r in rows:
            d = json.loads(r[3])
            print(f"  {tbl}: res={r[0]} sys={r[1]} col={r[2]} email={d.get('email')} user_id={d.get('user_id')}")
