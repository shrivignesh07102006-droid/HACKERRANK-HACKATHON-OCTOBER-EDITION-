import sqlite3

conn = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_search_primary_20260910.sql', 'r', encoding='utf-8') as f:
    conn.executescript(f.read())
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
print("Tables in evidence_57:", cur.fetchall())
cur.execute("SELECT * FROM search_documents_primary")
print("Rows in search_documents_primary:", cur.fetchall())
