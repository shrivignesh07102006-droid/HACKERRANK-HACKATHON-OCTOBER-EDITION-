import json

with open('dataset/evidence/records/customer_export_jobs_20260914.json', 'r', encoding='utf-8') as f:
    d = json.load(f)
print("Keys in evidence_59:", list(d.keys()) if isinstance(d, dict) else len(d))
print("Content:", d)
