with open('dataset/evidence/logs/support_replica.log', 'r', encoding='utf-8') as f:
    lines = f.readlines()
print(f"Total lines in support_replica.log: {len(lines)}")
for l in lines:
    if 'nadia.ionescu@yahoo.com' in l or 'support_' in l:
        print("  ", l.strip())
