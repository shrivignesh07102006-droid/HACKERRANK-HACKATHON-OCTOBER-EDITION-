import sqlite3

conn = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_data_inventory_20260916.sql', 'r', encoding='utf-8') as f:
    conn.executescript(f.read())
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
print("Tables in evidence_93:", cur.fetchall())

for t in cur.fetchall():
    tname = t[0]
    cur.execute(f"SELECT * FROM {tname} WHERE email LIKE '%appiah%' OR user_id = 'user_61'")
    print(tname, cur.fetchall())

# Let's inspect all tables
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [row[0] for row in cur.fetchall()]
for tname in tables:
    cur.execute(f"PRAGMA table_info({tname})")
    cols = [r[1] for r in cur.fetchall()]
    print(f"Table {tname} cols: {cols}")
    cur.execute(f"SELECT * FROM {tname} LIMIT 5")
    print("  sample rows:", cur.fetchall())
