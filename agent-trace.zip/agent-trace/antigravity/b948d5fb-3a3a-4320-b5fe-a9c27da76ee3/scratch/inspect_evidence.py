import os
import glob
import json
import sqlite3
import pandas as pd

def inspect_all():
    print("=== DATASET INVENTORY ===")
    dataset_dir = r"d:\hackathon october 26\dataset"
    for f in sorted(os.listdir(dataset_dir)):
        p = os.path.join(dataset_dir, f)
        if os.path.isfile(p):
            print(f"File: {f} ({os.path.getsize(p):,} bytes)")
        elif os.path.isdir(p):
            subcount = sum(len(files) for _, _, files in os.walk(p))
            print(f"Dir: {f}/ ({subcount} files)")

    print("\n=== EVIDENCE SUMMARY ===")
    manifest_df = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv"))
    print(f"Evidence files in manifest: {len(manifest_df)}")
    print(manifest_df.groupby("origin")["file_id"].count())

    print("\n=== SQL SCHEMAS ===")
    sql_files = glob.glob(os.path.join(dataset_dir, "evidence", "databases", "*.sql"))
    all_tables = {}
    for sf in sql_files:
        conn = sqlite3.connect(":memory:")
        with open(sf, "r", encoding="utf-8", errors="ignore") as f:
            sql = f.read()
        conn.executescript(sql)
        c = conn.cursor()
        c.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [r[0] for r in c.fetchall()]
        for t in tables:
            c.execute(f"PRAGMA table_info({t});")
            cols = [f"{r[1]} ({r[2]})" for r in c.fetchall()]
            if t not in all_tables:
                all_tables[t] = cols
        conn.close()
    for t, cols in sorted(all_tables.items()):
        print(f"Table '{t}': {', '.join(cols)}")

    print("\n=== JSON RECORDS SAMPLES ===")
    json_files = glob.glob(os.path.join(dataset_dir, "evidence", "records", "*.json"))
    print(f"Total JSON files: {len(json_files)}")
    for jf in json_files[:5]:
        with open(jf, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            sample = data[0] if data else {}
            print(f"{os.path.basename(jf)}: list of {len(data)} items, keys={list(sample.keys()) if isinstance(sample, dict) else type(sample)}")
        elif isinstance(data, dict):
            print(f"{os.path.basename(jf)}: dict with keys={list(data.keys())}")

    print("\n=== LOG FILES SAMPLES ===")
    log_files = glob.glob(os.path.join(dataset_dir, "evidence", "logs", "*.log"))
    print(f"Total Log files: {len(log_files)}")
    for lf in log_files[:5]:
        with open(lf, "r", encoding="utf-8", errors="ignore") as f:
            first_lines = [f.readline().strip() for _ in range(2)]
        print(f"{os.path.basename(lf)}:\n  1: {first_lines[0][:100]}\n  2: {first_lines[1][:100] if len(first_lines)>1 else ''}")

if __name__ == "__main__":
    inspect_all()
