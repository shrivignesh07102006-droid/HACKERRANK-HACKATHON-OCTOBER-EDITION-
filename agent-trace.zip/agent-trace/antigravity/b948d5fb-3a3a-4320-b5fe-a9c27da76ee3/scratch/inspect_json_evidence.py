import os
import sys
import json

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

with open(os.path.join(dataset_dir, "evidence/records/service_resource_export_20260915_114455.json"), "r", encoding="utf-8") as f:
    e92 = json.load(f)

print("e92 keys:", list(e92.keys()) if isinstance(e92, dict) else f"list of {len(e92)}")
if isinstance(e92, dict):
    for k in e92:
        val = e92[k]
        if isinstance(val, list):
            print(f"  {k}: list of {len(val)} items, sample={val[0] if val else None}")
        else:
            print(f"  {k}: {val}")

with open(os.path.join(dataset_dir, "evidence/records/customer_data_snapshot_bundle_20260915.json"), "r", encoding="utf-8") as f:
    e51 = json.load(f)

print("\ne51 keys:", list(e51.keys()) if isinstance(e51, dict) else f"list of {len(e51)}")
if isinstance(e51, dict):
    for k in e51:
        val = e51[k]
        if isinstance(val, dict):
            print(f"  {k}: dict with keys={list(val.keys())}")
        elif isinstance(val, list):
            print(f"  {k}: list of {len(val)} items, sample={val[0] if val else None}")
        else:
            print(f"  {k}: {val}")
