import sys
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

print("--- evidence_92 ---")
with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r', encoding='utf-8') as f:
    d92 = json.load(f)
print(f"type: {type(d92)}, len: {len(d92)}")
if isinstance(d92, list):
    print("sample 0:", d92[0])
elif isinstance(d92, dict):
    print("keys:", list(d92.keys())[:5])
    k0 = list(d92.keys())[0]
    print(f"sample key {k0}:", d92[k0])

print("--- evidence_94 ---")
with open('dataset/evidence/logs/resource_lookup_trace_20260926_103856.log', 'r', encoding='utf-8') as f:
    lines = [f.readline() for _ in range(5)]
    for l in lines:
        print("line:", l.strip())

print("--- evidence_51 ---")
with open('dataset/evidence/records/customer_data_snapshot_bundle_20260915.json', 'r', encoding='utf-8') as f:
    d51 = json.load(f)
print(f"type: {type(d51)}, len: {len(d51)}")
if isinstance(d51, list):
    print("sample 0:", d51[0])
elif isinstance(d51, dict):
    print("keys:", list(d51.keys())[:5])
