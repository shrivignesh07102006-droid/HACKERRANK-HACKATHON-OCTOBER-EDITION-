import os
import sys
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"
df = pd.read_csv(os.path.join(dataset_dir, "deletion_requests.csv"))

non_ascii = []
for idx, r in df.iterrows():
    txt = r['request_text']
    try:
        txt.encode('ascii')
    except UnicodeEncodeError:
        non_ascii.append((r['case_id'], r['email'], txt))

print(f"Total non-ascii requests: {len(non_ascii)}")

for cid, email, txt in non_ascii:
    # check if it contains negation or keep keywords in spanish, french, portuguese, japanese, korean
    print(f"{cid} | {email} | {txt}")
