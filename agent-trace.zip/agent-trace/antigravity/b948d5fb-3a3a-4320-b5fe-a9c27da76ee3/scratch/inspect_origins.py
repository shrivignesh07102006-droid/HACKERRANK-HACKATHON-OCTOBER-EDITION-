import sys
import os
import glob
import json
import sqlite3
import pandas as pd
import re
from typing import Dict, List, Any

sys.stdout.reconfigure(encoding='utf-8')

manifest = pd.read_csv('dataset/evidence_files.csv')
print(f"Manifest rows: {len(manifest)}")

# Let's inspect how each origin maps to files and structure
origins = manifest['origin'].unique()
print(f"Total origins: {len(origins)}")
for orig in origins[:10]:
    sample = manifest[manifest['origin'] == orig].iloc[0]
    print(f"Origin: {orig:35} -> File: {sample['file_path']}")
