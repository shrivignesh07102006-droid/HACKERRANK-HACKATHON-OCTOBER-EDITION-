import json, pandas as pd

df = pd.read_csv('dataset/sample_output.csv')
for _, r in df.iterrows():
    steps = json.loads(r['steps_json'])
    evs = sorted(set(s['evidence_id'] for s in steps if s['evidence_id']))
    res = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['evidence_id']) for s in steps]
    print(f"{r['case_id']} | {r['deletion_status']} | evs: {evs}")
    for phase, sys_id, res_id, op, ev in res:
        print(f"   {phase:<12} {sys_id:<20} {res_id:<25} {op:<25} {ev}")
