import os
import sys
import json
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

dataset_dir = r"d:\hackathon october 26\dataset"

sample_reqs = pd.read_csv(os.path.join(dataset_dir, "sample_deletion_requests.csv"))
sample_outs = pd.read_csv(os.path.join(dataset_dir, "sample_output.csv"))
identities = pd.read_csv(os.path.join(dataset_dir, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(dataset_dir, "user_audit_log.csv"))

merged = sample_reqs.merge(sample_outs, on="case_id")

print(f"Total sample cases: {len(merged)}")
print("Status counts:\n", merged["deletion_status"].value_counts())

for idx, row in merged.iterrows():
    steps = json.loads(row["steps_json"])
    print(f"\n--- {row['case_id']}: {row['email']} -> {row['deletion_status']} (reported: {row['reported_status']}) ---")
    print(f"Request: {row['request_text'][:80]}...")
    print(f"Steps count: {len(steps)}")
    for s in steps:
        print(f"  [{s['step_no']}] {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev={s['evidence_id']}")
