import glob
import re

tables = set()
for p in glob.glob('dataset/evidence/databases/*.sql'):
    with open(p, 'r', encoding='utf-8') as f:
        text = f.read()
    found = re.findall(r'CREATE TABLE (?:IF NOT EXISTS )?`?([a-zA-Z0-9_]+)`?', text, re.IGNORECASE)
    tables.update(found)
print('Tables in SQL evidence files:', sorted(tables))
