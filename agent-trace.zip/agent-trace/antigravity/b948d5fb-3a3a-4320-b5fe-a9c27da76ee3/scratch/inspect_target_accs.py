import pandas as pd
df_act = pd.read_csv('dataset/system_activity.csv')
del_acts = df_act[df_act['source_system'] == 'deletion_worker']

for acc in ['account_5521', 'account_5037', 'account_4990', 'account_7012', 'account_4163', 'account_4857', 'account_8858']:
    idx = del_acts[del_acts['resource_id'] == acc].index[0]
    print(f"=== Around {acc} (idx {idx}) ===")
    sub = df_act.loc[max(0, idx-4):min(len(df_act)-1, idx+6)]
    for _, r in sub.iterrows():
        print(f"  {r['activity_id']} | {r['event_time']} | {r['source_system']} | {r['target_system']} | {r['event_type']} | {r['resource_id']}")
