import sys
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

manifest = pd.read_csv('dataset/evidence_files.csv')
manifest['captured_dt'] = pd.to_datetime(manifest['captured_at'])
print("Captured dates summary:")
print(manifest[['file_id', 'captured_at', 'origin', 'file_path']].sort_values('captured_at').to_string())
