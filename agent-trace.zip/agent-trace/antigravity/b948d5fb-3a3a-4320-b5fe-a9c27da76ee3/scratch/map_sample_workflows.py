import pandas as pd, json

requests = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')
sample_output = pd.read_csv('dataset/sample_output.csv')

activity['dt'] = pd.to_datetime(activity['event_time'])

for _, req in requests.iterrows():
    cid = req['case_id']
    email = req['email']
    req_dt = pd.to_datetime(req['requested_at'])
    rep_dt = pd.to_datetime(req['reported_at'])
    aud_dt = pd.to_datetime(req['audit_at'])
    
    # Gold steps
    gold_row = sample_output[sample_output['case_id'] == cid].iloc[0]
    g_steps = json.loads(gold_row['steps_json'])
    g_resources = [(s['system_id'], s['resource_id'], s['operation']) for s in g_steps]
    
    # Filter activity between req_dt and rep_dt (with a small buffer or up to aud_dt)
    act_window = activity[(activity['dt'] >= req_dt - pd.Timedelta(hours=2)) & (activity['dt'] <= rep_dt + pd.Timedelta(hours=2))]
    dw_events = act_window[act_window['source_system'] == 'deletion_worker']
    
    print(f"\n=== {cid} ({email}) req: {req['requested_at']} rep: {req['reported_at']} status: {gold_row['deletion_status']} ===")
    print(f"  Gold resources ({len(g_resources)}): {g_resources}")
    print(f"  Deletion worker events in window ({len(dw_events)}):")
    for _, a in dw_events.iterrows():
        print(f"    {a['event_time']} | {a['target_system']:<20} | {a['resource_id']:<20} | {a['event_type']:<20} | {a['reported_result']}")
