import sys
import zlib
import re
import glob

sys.stdout.reconfigure(encoding='utf-8')

for path in glob.glob('dataset/evidence/documents/*.pdf'):
    print(f"\n==================== {path} ====================")
    with open(path, 'rb') as f:
        data = f.read()

    # Find /Length N >> \n stream \n <data> \n endstream
    pattern = re.compile(rb'/Length\s+(\d+)\s*>>\s*stream[\r\n]+', re.DOTALL)
    for m in pattern.finditer(data):
        length = int(m.group(1))
        stream_start = m.end()
        stream_data = data[stream_start : stream_start + length]
        try:
            decomp = zlib.decompress(stream_data)
            # Find all Tj strings: (text) Tj or [(text)] TJ
            # in ReportLab, text is often in (text) Tj
            tj_strings = re.findall(rb'\((.*?)\)\s*Tj', decomp)
            if tj_strings:
                decoded = [s.decode('latin1', errors='ignore') for s in tj_strings]
                print("Extracted Tj text:")
                for line in decoded:
                    if line.strip():
                        print("  ", line.strip())
        except Exception as e:
            pass
