import os, glob, re, pandas as pd

log_files = glob.glob('dataset/evidence/logs/*.log')
manifest = pd.read_csv('dataset/evidence_files.csv')
file_to_fid = dict(zip(manifest['file_path'].apply(os.path.basename), manifest['file_id']))

traces = {}

for lpath in log_files:
    fname = os.path.basename(lpath)
    fid = file_to_fid.get(fname, '')
    with open(lpath, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            clean_pairs = {}
            for m in re.finditer(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line):
                k = m.group(1)
                v = m.group(2) if m.group(2) is not None else m.group(3)
                clean_pairs[k] = v
                
            tid = clean_pairs.get('trace_id')
            if not tid:
                # Some logs use requestId or correlation_key
                tid = clean_pairs.get('requestId') or f"{fname}_{clean_pairs.get('resource_id')}"
                
            key = (fid, tid)
            if key not in traces:
                traces[key] = {
                    'file_id': fid,
                    'trace_id': tid,
                    'service': clean_pairs.get('service') or clean_pairs.get('function'),
                    'resource_id': None,
                    'status': None,
                    'keys': set(),
                    'events': []
                }
            tr = traces[key]
            if clean_pairs.get('service'): tr['service'] = clean_pairs['service']
            if clean_pairs.get('function'): tr['service'] = clean_pairs['function']
            if clean_pairs.get('resource_id'): tr['resource_id'] = clean_pairs['resource_id']
            if clean_pairs.get('http_status'): tr['status'] = clean_pairs['http_status']
            if clean_pairs.get('result'): tr['result'] = clean_pairs['result']
            if clean_pairs.get('integrity_check'): tr['integrity'] = clean_pairs['integrity_check']
            for k in ['lookup_key', 'correlation_key', 'subject_key', 'subject_ref', 'match_key', 'matched_value', 'scan_key']:
                if clean_pairs.get(k):
                    tr['keys'].add(clean_pairs[k])
            if clean_pairs.get('event'):
                tr['events'].append(clean_pairs['event'])

print(f"Total traces aggregated across all logs: {len(traces)}")

# Check for user_17 or leonie.g9352@outlook.com
print("\nTraces for leonie.g9352@outlook.com or user_17:")
for (fid, tid), tr in traces.items():
    if any('leonie' in k or 'user_17' in k for k in tr['keys']):
        print(f"  {fid} | {tr['service']} | {tr['resource_id']} | keys: {tr['keys']} | status={tr.get('status')} result={tr.get('result')} events={tr['events']}")
