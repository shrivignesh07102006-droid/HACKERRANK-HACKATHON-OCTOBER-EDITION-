import zlib, re

with open('dataset/evidence/documents/delivery_correction_attachment.pdf', 'rb') as f:
    data = f.read()

streams = re.findall(rb'stream[\r\n]+(.*?)[\r\n]+endstream', data, re.DOTALL)
print(f"Found {len(streams)} streams")
for idx, s in enumerate(streams):
    try:
        dec = zlib.decompress(s)
        # find readable strings
        text = dec.decode('latin1', errors='ignore')
        matches = re.findall(r'\(([^\)]+)\)', text)
        print(f"Stream {idx}: {' '.join(matches[:20])}")
    except Exception as e:
        pass
