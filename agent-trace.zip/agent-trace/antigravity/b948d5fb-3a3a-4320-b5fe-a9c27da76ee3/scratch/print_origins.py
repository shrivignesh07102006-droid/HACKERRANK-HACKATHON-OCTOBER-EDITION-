import pandas as pd
ef = pd.read_csv('dataset/evidence_files.csv')
for fid in ['evidence_01', 'evidence_02', 'evidence_05', 'evidence_06', 'evidence_51', 'evidence_92', 'evidence_94']:
    row = ef[ef['file_id'] == fid].iloc[0]
    print(f"{fid}: origin={row['origin']}, path={row['file_path']}")
