import sys
sys.path.insert(0, 'code')
import os
import json
import pandas as pd
from typing import Dict, List, Set, Any, Optional

sys.stdout.reconfigure(encoding='utf-8')

from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key

# Import get_observations from earlier
from test_all_sample_parsers import get_observations

g = IdentityGraph('dataset')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')

def evaluate_case(cid, subj, audit_at):
    obs = get_observations(cid, subj, audit_at)
    
    findings = []
    remediations = []
    verifications = []
    remediated_resources = set()
    has_finding = False

    for o in obs:
        st = o['state']
        cat = o['category']
        sys_id = o['system_id']
        res_id = o['resource_id']
        ev_id = o['evidence_id']

        if st == 'PRESENT' and cat in ('USER_PROFILE', 'SEARCH_INDEX_ENTRY', 'USER_EXPORT', 'SUPPORT_ATTACHMENT'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_REMAINING_RECORD', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'DELETE_RECORD', 'state': 'ABSENT', 'evidence_id': ''})
            remediated_resources.add((sys_id, res_id))
        elif st == 'PRESENT' and cat in ('SUPPORT_MESSAGE', 'ACCOUNT_TOMBSTONE'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REDACT_RECORD', 'state': 'REDACTED', 'evidence_id': ''})
            remediated_resources.add((sys_id, res_id))
        elif st == 'PRESENT' and cat in ('ANALYTICS_PROFILE', 'PRODUCT_TELEMETRY'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'ANONYMIZE_RECORD', 'state': 'ANONYMIZED', 'evidence_id': ''})
            remediated_resources.add((sys_id, res_id))
        elif st == 'ACTIVE' and cat == 'DATA_FLOW':
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_ACTIVE_DATA_FLOW', 'state': 'ACTIVE', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'DISABLE_DATA_FLOW', 'state': 'DISABLED', 'evidence_id': ''})
            remediated_resources.add((sys_id, res_id))
        elif st == 'ACTIVE' and cat == 'BACKUP_ARCHIVE':
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_RESTORE_RISK', 'state': 'ACTIVE', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'BLOCK_RESTORE', 'state': 'BLOCKED', 'evidence_id': ''})
            remediated_resources.add((sys_id, res_id))

    if has_finding:
        status = 'INCOMPLETE'
        for o in obs:
            sys_id = o['system_id']
            res_id = o['resource_id']
            cat = o['category']
            st = o['state']
            if (sys_id, res_id) in remediated_resources:
                if cat in ('USER_PROFILE', 'SEARCH_INDEX_ENTRY', 'USER_EXPORT', 'SUPPORT_ATTACHMENT'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ''})
                elif cat in ('SUPPORT_MESSAGE', 'ACCOUNT_TOMBSTONE'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ''})
                elif cat in ('ANALYTICS_PROFILE', 'PRODUCT_TELEMETRY'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ''})
                elif cat == 'DATA_FLOW':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ''})
                elif cat == 'BACKUP_ARCHIVE':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ''})
            else:
                if st == 'ABSENT':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ''})
                elif st == 'PRESENT' and cat in ('SECURITY_AUDIT_LOG', 'LEGAL_HOLD_RECORD'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_PRESENT', 'state': 'PRESENT', 'evidence_id': ''})
                elif st == 'REDACTED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ''})
                elif st == 'ANONYMIZED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ''})
                elif st == 'DISABLED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ''})
                elif st == 'BLOCKED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ''})
        all_steps = findings + remediations + verifications
    else:
        status = 'COMPLETE'
        for o in obs:
            sys_id = o['system_id']
            res_id = o['resource_id']
            cat = o['category']
            st = o['state']
            ev_id = o['evidence_id']
            if st == 'ABSENT':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ev_id})
            elif st == 'PRESENT' and cat in ('SECURITY_AUDIT_LOG', 'LEGAL_HOLD_RECORD'):
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_PRESENT', 'state': 'PRESENT', 'evidence_id': ev_id})
            elif st == 'REDACTED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ev_id})
            elif st == 'ANONYMIZED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ev_id})
            elif st == 'DISABLED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ev_id})
            elif st == 'BLOCKED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ev_id})
        all_steps = verifications

    # Canonical sorting
    sorted_steps = sorted(all_steps, key=step_sort_key)
    for idx, s in enumerate(sorted_steps, 1):
        s['step_no'] = idx

    return status, sorted_steps

# Evaluate all 32 cases
status_matches = 0
step_matches = 0

for _, r in samples.iterrows():
    cid = r['case_id']
    subj = g.resolve(r['email'])
    audit_at = r['audit_at']
    pred_status, pred_steps = evaluate_case(cid, subj, audit_at)
    
    gold_row = golden[golden['case_id'] == cid].iloc[0]
    gold_status = gold_row['deletion_status']
    gold_steps = json.loads(gold_row['steps_json'])

    if pred_status == gold_status:
        status_matches += 1
    else:
        print(f"Status mismatch in {cid}: pred={pred_status} gold={gold_status}")

    # Compare steps
    # Grader checks: step_no, phase, system_id, resource_id, operation, state, evidence_id
    if pred_steps == gold_steps:
        step_matches += 1
    else:
        print(f"Step mismatch in {cid}:")
        print("  Pred:", pred_steps)
        print("  Gold:", gold_steps)

print(f"\nResults on 32 Public Sample Cases:")
print(f"  Status Accuracy: {status_matches}/32 ({status_matches/32*100:.1f}%)")
print(f"  Step Accuracy:   {step_matches}/32 ({step_matches/32*100:.1f}%)")
