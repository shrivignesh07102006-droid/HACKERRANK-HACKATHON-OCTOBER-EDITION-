import os
import sys
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

reqs = pd.read_csv(os.path.join(dataset_dir, "deletion_requests.csv"))

print(f"Total requests: {len(reqs)}")

# Let's inspect potential non-deletion requests
non_deletion_candidates = []
for idx, r in reqs.iterrows():
    text = str(r["request_text"]).strip()
    tl = text.lower()
    
    # Check for keywords indicating access, export, email change, or keeping account
    is_non_deletion = False
    reasons = []
    
    if "continue using" in tl or "still use" in tl or "keep using" in tl:
        is_non_deletion = True
        reasons.append("continue_using")
    if "don't delete" in tl or "do not delete" in tl or "ne supprimez pas" in tl or "no elimine" in tl or "nao exclua" in tl or "não exclua" in tl:
        is_non_deletion = True
        reasons.append("explicit_do_not_delete")
    if ("copy of" in tl or "send me" in tl or "export" in tl or "download" in tl) and not any(k in tl for k in ["delete", "close", "erase", "remove", "supprimer", "eliminar", "excluir", "削除"]):
        is_non_deletion = True
        reasons.append("export_only")
    if ("change" in tl or "update" in tl or "modifier" in tl or "actualizar" in tl or "alterar" in tl) and ("email" in tl or "address" in tl) and not any(k in tl for k in ["delete", "close", "erase", "remove", "supprimer", "eliminar", "excluir", "削除"]):
        is_non_deletion = True
        reasons.append("change_email_only")
        
    if is_non_deletion:
        non_deletion_candidates.append((r["case_id"], r["email"], reasons, text))

print(f"\nFound {len(non_deletion_candidates)} potential non-deletion candidates:")
for cid, email, reasons, text in non_deletion_candidates:
    print(f"  {cid} ({email}) [{', '.join(reasons)}]:\n    \"{text}\"")
