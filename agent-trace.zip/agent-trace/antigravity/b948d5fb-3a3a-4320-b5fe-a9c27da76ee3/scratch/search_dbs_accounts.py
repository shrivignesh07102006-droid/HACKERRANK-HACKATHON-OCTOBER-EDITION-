import os, glob, sqlite3

db_files = glob.glob('dataset/evidence/databases/*.db')
targets = ['account_4857', 'account_8858', 'account_3677', 'account_5482', 'account_3866', 'account_7012']

for db_path in db_files:
    fname = os.path.basename(db_path)
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [t[0] for t in cur.fetchall()]
        for tbl in tables:
            cur.execute(f"PRAGMA table_info({tbl})")
            cols = [c[1] for c in cur.fetchall()]
            for tgt in targets:
                # check each column
                for col in cols:
                    try:
                        cur.execute(f"SELECT * FROM {tbl} WHERE CAST({col} AS TEXT) LIKE '%{tgt}%'")
                        rows = cur.fetchall()
                        if rows:
                            print(f"{fname} -> {tbl}.{col} matches {tgt}: {rows}")
                    except:
                        pass
        conn.close()
    except Exception as e:
        print(f"Error reading {fname}: {e}")
