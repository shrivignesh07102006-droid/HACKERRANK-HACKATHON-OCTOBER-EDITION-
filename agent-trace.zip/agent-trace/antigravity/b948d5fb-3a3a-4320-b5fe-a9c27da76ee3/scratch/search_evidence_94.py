with open('dataset/evidence/logs/resource_lookup_trace_20260926_103856.log') as f:
    for line in f:
        if any(x in line for x in ['7566', '2016', '9406', 'c.alvarez74@gmail.com', 'user_03']):
            print(line.strip())
