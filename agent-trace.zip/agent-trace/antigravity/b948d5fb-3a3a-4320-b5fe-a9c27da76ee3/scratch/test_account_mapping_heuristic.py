import pandas as pd, json

requests = pd.read_csv('dataset/sample_deletion_requests.csv')
activity = pd.read_csv('dataset/system_activity.csv')
sample_output = pd.read_csv('dataset/sample_output.csv')

activity['dt'] = pd.to_datetime(activity['event_time'])

# Find all deletion_worker events on account_service
dw_acc_events = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service')].copy()

# For each sample case, find matching account
for _, req in requests.iterrows():
    cid = req['case_id']
    rep_dt = pd.to_datetime(req['reported_at'])
    g_row = sample_output[sample_output['case_id'] == cid].iloc[0]
    g_steps = json.loads(g_row['steps_json'])
    g_acc = [s['resource_id'] for s in g_steps if s['system_id'] == 'account_service']
    
    # Candidate accounts: within 3 hours prior to reported_at
    cand = dw_acc_events[(dw_acc_events['dt'] >= rep_dt - pd.Timedelta(hours=3)) & (dw_acc_events['dt'] <= rep_dt + pd.Timedelta(minutes=5))]
    
    print(f"{cid:<8} | rep_dt={str(rep_dt)[:19]} | gold={str(g_acc):<22} | candidates={cand['resource_id'].tolist()}")
