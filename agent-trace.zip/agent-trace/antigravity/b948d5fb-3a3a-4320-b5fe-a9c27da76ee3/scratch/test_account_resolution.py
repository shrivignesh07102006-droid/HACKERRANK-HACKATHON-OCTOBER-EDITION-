import pandas as pd

reqs = pd.read_csv('dataset/sample_deletion_requests.csv')
acts = pd.read_csv('dataset/system_activity.csv')
del_acts = acts[acts['source_system'] == 'deletion_worker']
del_acts = del_acts[del_acts['event_type'] == 'DELETE_RECORD']
del_acts['dt'] = pd.to_datetime(del_acts['event_time'])

print(f"{'Case':<9} | {'Reported At':<22} | {'Matched Activity Resource':<25} | {'Gold Account':<15} | Match?")
print("-" * 90)

gold_df = pd.read_csv('dataset/sample_output.csv')
gold_accounts = {}
for _, r in gold_df.iterrows():
    import json
    steps = json.loads(r['steps_json'])
    for s in steps:
        if s['system_id'] == 'account_service' and s['resource_id'].startswith('account_'):
            gold_accounts[r['case_id']] = s['resource_id']

for _, r in reqs.iterrows():
    cid = r['case_id']
    rep_dt = pd.to_datetime(r['reported_at'])
    req_dt = pd.to_datetime(r['requested_at'])
    
    # Find delete record activities in [rep_dt - 3 hours, rep_dt + 10 mins]
    candidates = del_acts[(del_acts['dt'] >= req_dt) & (del_acts['dt'] <= rep_dt + pd.Timedelta(minutes=15))]
    # Pick the one closest to rep_dt before rep_dt
    candidates = candidates.sort_values('dt', ascending=False)
    
    g_acc = gold_accounts.get(cid, 'None')
    matched = 'None'
    # Check if any candidate matches or is closest
    if len(candidates):
        # find the candidate that is an account_
        for _, c in candidates.iterrows():
            if str(c['resource_id']).startswith('account_'):
                # Also check details if mentioned
                matched = str(c['resource_id'])
                break
                
    is_match = (matched == g_acc)
    print(f"{cid:<9} | {r['reported_at']:<22} | {matched:<25} | {g_acc:<15} | {str(is_match)}")
