import os, glob, re, pandas as pd

manifest = pd.read_csv('dataset/evidence_files.csv')
file_to_fid = dict(zip(manifest['file_path'].apply(os.path.basename), manifest['file_id']))

account_to_keys = {}

# 1. Search all logs
for lpath in glob.glob('dataset/evidence/logs/*.log'):
    fname = os.path.basename(lpath)
    fid = file_to_fid.get(fname, '')
    
    traces = {}
    with open(lpath, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if not line.strip(): continue
            clean_pairs = {}
            for m in re.finditer(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line):
                k = m.group(1)
                v = m.group(2) if m.group(2) is not None else m.group(3)
                clean_pairs[k] = v.strip('"')
            
            tid = clean_pairs.get('trace_id') or clean_pairs.get('requestId') or f"{fname}_{clean_pairs.get('resource_id')}"
            if tid not in traces:
                traces[tid] = {'keys': set(), 'resource_id': None, 'service': None}
            if clean_pairs.get('resource_id'): traces[tid]['resource_id'] = clean_pairs['resource_id']
            if clean_pairs.get('service'): traces[tid]['service'] = clean_pairs['service']
            if clean_pairs.get('function'): traces[tid]['service'] = clean_pairs['function']
            for k in ['lookup_key', 'correlation_key', 'subject_key', 'subject_ref', 'match_key', 'matched_value', 'scan_key']:
                if clean_pairs.get(k): traces[tid]['keys'].add(clean_pairs[k].lower())
                
    for tid, tr in traces.items():
        res = tr['resource_id']
        if res and res.startswith('account_'):
            if res not in account_to_keys:
                account_to_keys[res] = set()
            account_to_keys[res].update(tr['keys'])

# 2. Search TXT
txt_path = 'dataset/evidence/records/customer_account_handover_20261001.txt'
if os.path.exists(txt_path):
    with open(txt_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = [p.strip() for p in line.strip().lstrip('- ').split('|')]
            if len(parts) >= 6 and parts[1] == 'account_service':
                res = parts[2]
                key = parts[5].lower()
                if res not in account_to_keys: account_to_keys[res] = set()
                account_to_keys[res].add(key)

print(f"Total unique account_XXXX with resolved identity keys: {len(account_to_keys)}")

# Test resolving sample cases
sample_output = pd.read_csv('dataset/sample_output.csv')
sample_requests = pd.read_csv('dataset/sample_deletion_requests.csv')
users = pd.read_csv('dataset/user_identities.csv')

user_email_map = dict(zip(users['email'].str.lower(), users['user_id']))

found_count = 0
for _, req in sample_requests.iterrows():
    cid = req['case_id']
    em = req['email'].lower()
    uid = user_email_map.get(em)
    
    g_row = sample_output[sample_output['case_id'] == cid].iloc[0]
    import json
    g_steps = json.loads(g_row['steps_json'])
    g_acc = [s['resource_id'] for s in g_steps if s['system_id'] == 'account_service']
    
    matched_accs = [acc for acc, keys in account_to_keys.items() if (em in keys or (uid and uid.lower() in keys))]
    print(f"{cid:<8} | em={em:<28} | gold_acc={str(g_acc):<22} | resolved_accs={matched_accs}")
    if matched_accs and g_acc and matched_accs[0] in g_acc:
        found_count += 1

print(f"\nDirectly matched: {found_count}/{len(sample_requests)}")
