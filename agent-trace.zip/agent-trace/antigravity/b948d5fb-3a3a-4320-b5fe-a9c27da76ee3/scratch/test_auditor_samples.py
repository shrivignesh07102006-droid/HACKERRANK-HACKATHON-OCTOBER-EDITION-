import sys
sys.path.insert(0, 'code')
import os
import json
import sqlite3
import pandas as pd
from typing import Dict, List, Set, Any, Optional

sys.stdout.reconfigure(encoding='utf-8')

from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key

# Let's inspect each sample case and build the exact extractor for all sample cases
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')
manifest = pd.read_csv('dataset/evidence_files.csv').set_index('file_id')

print("Loaded samples and golden output.")
