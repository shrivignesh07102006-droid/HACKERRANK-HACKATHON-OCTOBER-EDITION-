import os, sys, json, glob, re, sqlite3
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from identity import IdentityGraph

id_graph = IdentityGraph('dataset')
manifest_df = pd.read_csv('dataset/evidence_files.csv')
file_to_fid = dict(zip(manifest_df['file_path'].apply(os.path.basename), manifest_df['file_id']))

res_to_user = {}
res_to_email = {}

# 1. JSON records
for fp in glob.glob('dataset/evidence/records/*.json'):
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            d = json.load(f)
            # Service exports
            if 'service_exports' in d:
                for sname, sdata in d['service_exports'].items():
                    for coll, items in sdata.items():
                        for it in items:
                            rid = it.get('resource_id')
                            if not rid: continue
                            u = it.get('customer_reference') or it.get('subject_reference') or it.get('user_id')
                            em = it.get('email') or it.get('owner_email') or it.get('customer_email') or it.get('requester_email')
                            if u: res_to_user[rid] = u
                            if em: res_to_email[rid] = em.lower()
                            # check inner doc or profile
                            if 'profile' in it and isinstance(it['profile'], dict):
                                pu = it['profile'].get('customer_reference')
                                pem = it['profile'].get('email')
                                if pu: res_to_user[rid] = pu
                                if pem: res_to_email[rid] = pem.lower()
            # Snapshots
            if 'snapshots' in d:
                for s in d['snapshots']:
                    for r in s.get('records', []):
                        rid = r.get('resource_id')
                        if not rid: continue
                        u = r.get('subject_reference') or r.get('customer_reference') or r.get('user_id')
                        em = r.get('email') or r.get('owner_email') or r.get('customer_email') or r.get('requester_email')
                        if u: res_to_user[rid] = u
                        if em: res_to_email[rid] = em.lower()
                        if 'document' in r and isinstance(r['document'], dict):
                            du = r['document'].get('customer_reference')
                            dem = r['document'].get('email')
                            if du: res_to_user[rid] = du
                            if dem: res_to_email[rid] = dem.lower()
            # Direct collections
            if 'records' in d:
                for r in d.get('records', []):
                    rid = r.get('resource_id')
                    if not rid: continue
                    u = r.get('subject_reference') or r.get('customer_reference') or r.get('user_id')
                    em = r.get('email') or r.get('owner_email') or r.get('customer_email') or r.get('requester_email')
                    if u: res_to_user[rid] = u
                    if em: res_to_email[rid] = em.lower()
    except Exception:
        pass

# 2. SQL snapshots
for fp in glob.glob('dataset/evidence/databases/*.sql'):
    conn = sqlite3.connect(':memory:')
    try:
        with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
            conn.executescript(f.read())
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        for t in tables:
            cols = [c[1] for c in conn.execute(f"PRAGMA table_info({t})").fetchall()]
            if 'resource_id' in cols:
                q_cols = ['resource_id']
                for c in ['customer_reference', 'subject_reference', 'user_id', 'email', 'owner_email', 'requester_email', 'record_json']:
                    if c in cols: q_cols.append(c)
                rows = conn.execute(f"SELECT {','.join(q_cols)} FROM {t}").fetchall()
                for row in rows:
                    rid = row[0]
                    for idx, c in enumerate(q_cols[1:], 1):
                        val = row[idx]
                        if not val: continue
                        if c == 'record_json':
                            try:
                                rj = json.loads(val)
                                ru = rj.get('customer_reference') or rj.get('subject_reference') or rj.get('user_id')
                                rem = rj.get('email') or rj.get('owner_email') or rj.get('customer_email') or rj.get('requester_email')
                                if ru: res_to_user[rid] = ru
                                if rem: res_to_email[rid] = rem.lower()
                                doc = rj.get('document') or {}
                                if doc.get('customer_reference'): res_to_user[rid] = doc['customer_reference']
                                if doc.get('email'): res_to_email[rid] = doc['email'].lower()
                            except Exception:
                                pass
                        elif 'email' in c:
                            res_to_email[rid] = str(val).lower()
                        else:
                            res_to_user[rid] = str(val)
    except Exception:
        pass
    finally:
        conn.close()

# 3. TXT handover
txt_fp = 'dataset/evidence/records/customer_account_handover_20261001.txt'
if os.path.exists(txt_fp):
    with open(txt_fp, 'r', encoding='utf-8') as f:
        for line in f:
            parts = [p.strip() for p in line.strip().lstrip('- ').split('|')]
            if len(parts) >= 6:
                rid = parts[2]
                key = parts[5].lower()
                if '@' in key:
                    res_to_email[rid] = key
                elif key.startswith('user_'):
                    res_to_user[rid] = key

# 4. Logs
for fp in glob.glob('dataset/evidence/logs/*.log'):
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if 'resource_id=' in line:
                m_res = re.search(r'resource_id=([^\s]+)', line)
                if m_res:
                    rid = m_res.group(1).strip('"')
                    # look for email or user_id
                    m_em = re.search(r'(?:email|requester_email|lookup_key|subject_key|customer_email)="?([^"\s]+@[^"\s]+)"?', line)
                    m_u = re.search(r'(?:customer_reference|subject_reference|correlation_key|user_id)="?(user_\d+)"?', line)
                    if m_em: res_to_email[rid] = m_em.group(1).lower()
                    if m_u: res_to_user[rid] = m_u.group(1)

print(f"Indexed {len(res_to_user)} resource-to-user links")
print(f"Indexed {len(res_to_email)} resource-to-email links")

for u in ['user_21', 'user_25', 'user_26', 'user_27', 'user_28']:
    res_list = [r for r, user in res_to_user.items() if user == u]
    print(u, 'mapped resources in res_to_user:', res_list)
