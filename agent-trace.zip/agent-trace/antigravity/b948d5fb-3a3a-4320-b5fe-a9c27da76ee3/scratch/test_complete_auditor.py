import sys
sys.path.insert(0, 'code')
import os
import json
import pandas as pd
from typing import Dict, List, Set, Any, Optional

sys.stdout.reconfigure(encoding='utf-8')

from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key
from evidence_index import EvidenceIndex

g = IdentityGraph('dataset')
ev_idx = EvidenceIndex('dataset')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')

print("EvidenceIndex initialized in test script.")
