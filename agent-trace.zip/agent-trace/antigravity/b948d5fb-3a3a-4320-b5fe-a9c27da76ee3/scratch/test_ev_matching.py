import sys
sys.path.insert(0, 'code')
import pandas as pd
import json

sys.stdout.reconfigure(encoding='utf-8')

from identity import IdentityGraph

g = IdentityGraph('dataset')
manifest = pd.read_csv('dataset/evidence_files.csv')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')

# Test finding evidence for each sample case
print("Testing identity matching for sample cases:")
for _, r in samples.head(10).iterrows():
    cid = r['case_id']
    email = r['email']
    audit_at = r['audit_at']
    subj = g.resolve(email)
    print(f"[{cid}] email={email} -> user_id={subj.user_id if subj else 'None'}")
