import sys
sys.path.insert(0, 'code')
import pandas as pd
from identity import IdentityGraph

sys.stdout.reconfigure(encoding='utf-8')

g = IdentityGraph('dataset')
eval_reqs = pd.read_csv('dataset/deletion_requests.csv')

print("First 10 evaluation requests:")
for _, r in eval_reqs.head(10).iterrows():
    cid = r['case_id']
    email = r['email']
    audit_at = r['audit_at']
    subj = g.resolve(email)
    print(f"[{cid}] email={email:30} audit_at={audit_at} -> user_id={subj.user_id if subj else 'NOT FOUND'}")
