import sys
sys.path.insert(0, 'code')
import os
import json
import sqlite3
import pandas as pd
from typing import Dict, List, Set, Any, Optional

sys.stdout.reconfigure(encoding='utf-8')

from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key

g = IdentityGraph('dataset')
manifest = pd.read_csv('dataset/evidence_files.csv')
manifest['captured_dt'] = pd.to_datetime(manifest['captured_at'])

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
golden = pd.read_csv('dataset/sample_output.csv')

def parse_service_resource_export(json_path: str, subj, file_id: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    exports = data.get('service_exports', {})
    obs = []
    
    # 1. account_service
    accs = exports.get('account_service', {}).get('accounts', [])
    for a in accs:
        # check if belongs to subject
        if a.get('customer_reference') == subj.user_id or a.get('email', '').lower() in subj.all_emails:
            st = 'PRESENT' if a.get('account_status') == 'ACTIVE' else 'ABSENT'
            obs.append({
                'system_id': 'account_service', 'resource_id': a['resource_id'],
                'category': 'USER_PROFILE', 'state': st, 'evidence_id': file_id
            })

    # 2. security_service
    auds = exports.get('security_service', {}).get('audit_records', [])
    for aud in auds:
        if aud.get('subject_reference') == subj.user_id:
            obs.append({
                'system_id': 'security_service', 'resource_id': aud['resource_id'],
                'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT', 'evidence_id': file_id
            })

    # 3. support_platform
    tix = exports.get('support_platform', {}).get('tickets', [])
    for t in tix:
        if t.get('customer_reference') == subj.user_id or (t.get('requester_email') and t['requester_email'].lower() in subj.all_emails):
            is_pii = bool(t.get('requester_email') or t.get('requester_name') or t.get('requester_phone'))
            st = 'PRESENT' if is_pii else 'REDACTED'
            obs.append({
                'system_id': 'support_platform', 'resource_id': t['resource_id'],
                'category': 'SUPPORT_MESSAGE', 'state': st, 'evidence_id': file_id
            })

    # 4. analytics_platform
    profs = exports.get('analytics_platform', {}).get('profiles', [])
    for p in profs:
        if p.get('email') and p['email'].lower() in subj.all_emails:
            obs.append({
                'system_id': 'analytics_platform', 'resource_id': p['resource_id'],
                'category': 'ANALYTICS_PROFILE', 'state': 'PRESENT', 'evidence_id': file_id
            })
        elif p.get('customer_reference') == subj.user_id:
            obs.append({
                'system_id': 'analytics_platform', 'resource_id': p['resource_id'],
                'category': 'ANALYTICS_PROFILE', 'state': 'PRESENT', 'evidence_id': file_id
            })
        elif not p.get('email') and not p.get('customer_reference'):
            # Anonymized profile matching audience cohort or order
            pass

    # 5. integration_service
    conns = exports.get('integration_service', {}).get('connectors', [])
    for c in conns:
        if c.get('customer_reference') == subj.user_id or (c.get('customer_email') and c['customer_email'].lower() in subj.all_emails):
            st = 'ACTIVE' if c.get('enabled') else 'DISABLED'
            obs.append({
                'system_id': 'integration_service', 'resource_id': c['resource_id'],
                'category': 'DATA_FLOW', 'state': st, 'evidence_id': file_id
            })

    # 6. backup_service
    baks = exports.get('backup_service', {}).get('restore_entries', [])
    for b in baks:
        if b.get('customer_reference') == subj.user_id or (b.get('customer_email') and b['customer_email'].lower() in subj.all_emails):
            st = 'ACTIVE' if b.get('restore_allowed') else 'BLOCKED'
            obs.append({
                'system_id': 'backup_service', 'resource_id': b['resource_id'],
                'category': 'BACKUP_ARCHIVE', 'state': st, 'evidence_id': file_id
            })

    # 7. search_service
    s_queries = exports.get('search_service', {}).get('index_queries', [])
    for sq in s_queries:
        if sq.get('query', '').lower() in subj.all_emails or sq.get('resource_id') == subj.user_id:
            docs = sq.get('hits', {}).get('documents', [])
            for d in docs:
                obs.append({
                    'system_id': 'search_service', 'resource_id': d['resource_id'],
                    'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT', 'evidence_id': file_id
                })

    # 8. export_service
    exps = exports.get('export_service', {}).get('exports', [])
    for exp in exps:
        if (exp.get('owner_email') and exp['owner_email'].lower() in subj.all_emails) or exp.get('customer_reference') == subj.user_id:
            obs.append({
                'system_id': 'export_service', 'resource_id': exp['resource_id'],
                'category': 'USER_EXPORT', 'state': 'PRESENT', 'evidence_id': file_id
            })

    return obs

print("Tested parse_service_resource_export definition.")
