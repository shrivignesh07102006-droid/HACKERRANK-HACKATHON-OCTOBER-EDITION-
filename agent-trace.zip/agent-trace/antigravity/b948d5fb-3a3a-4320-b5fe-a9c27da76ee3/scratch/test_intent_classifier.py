import sys
import pandas as pd
import re

sys.stdout.reconfigure(encoding='utf-8')

def is_deletion_request(text: str) -> bool:
    if not isinstance(text, str) or not text.strip():
        return False
    t = text.lower()
    
    # Explicit non-deletion requests: explicitly asking to keep, continue using, not delete, or only access/export
    non_deletion_patterns = [
        r'keep the account',
        r'leave my profile',
        r'continue using the service',
        r"don't delete",
        r"do not delete",
        r'still use it',
        r'just want to download',
        r'only want a copy',
        r'change the email address.*want to continue',
        r'invoices for my records.*leave',
    ]
    for p in non_deletion_patterns:
        if re.search(p, t):
            return False
            
    # Also check other languages if any
    # Japanese: アカウントを維持, 削除しないで
    if 'アカウントを維持' in text or '削除しないで' in text or '使い続け' in text:
        return False
    # German: Konto behalten, nicht löschen
    if 'konto behalten' in t or 'nicht löschen' in t or 'weiterhin nutzen' in t:
        return False
    # French: garder le compte, ne pas supprimer
    if 'garder le compte' in t or 'ne pas supprimer' in t or 'continuer à utiliser' in t:
        return False
    # Spanish: mantener la cuenta, no eliminar
    if 'mantener la cuenta' in t or 'no eliminar' in t or 'seguir usando' in t:
        return False

    return True

reqs = pd.read_csv('dataset/deletion_requests.csv')
non_del = []
for _, r in reqs.iterrows():
    if not is_deletion_request(r['request_text']):
        non_del.append((r['case_id'], r['email'], r['request_text']))

print(f"Total non-deletion requests found: {len(non_del)}")
for cid, em, txt in non_del:
    print(f"  {cid} ({em}): {txt}")
