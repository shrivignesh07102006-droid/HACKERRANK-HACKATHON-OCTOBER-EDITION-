import sys
import glob
import sqlite3
import time
import re

sys.stdout.reconfigure(encoding='utf-8')

t0 = time.time()
sql_files = glob.glob('dataset/evidence/databases/*.sql')
print(f"Loading {len(sql_files)} SQL files...")

db_by_file = {}
for path in sql_files:
    fname = path.replace('\\', '/').split('/')[-1]
    conn = sqlite3.connect(':memory:')
    with open(path, 'r', encoding='utf-8') as f:
        sql = f.read()
    # SQLite compatibility adjustments if any
    try:
        conn.executescript(sql)
        db_by_file[fname] = conn
    except Exception as e:
        print(f"Error loading {fname}: {e}")

t1 = time.time()
print(f"Loaded {len(db_by_file)} SQLite databases in {t1 - t0:.2f} seconds!")
