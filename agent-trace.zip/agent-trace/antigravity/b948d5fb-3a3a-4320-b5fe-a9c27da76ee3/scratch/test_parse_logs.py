import os, glob, re, pandas as pd

log_files = glob.glob('dataset/evidence/logs/*.log')
manifest = pd.read_csv('dataset/evidence_files.csv')
file_to_fid = dict(zip(manifest['file_path'].apply(os.path.basename), manifest['file_id']))

parsed_log_records = []

for lpath in log_files:
    fname = os.path.basename(lpath)
    fid = file_to_fid.get(fname, '')
    with open(lpath, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or 'service=' not in line:
                continue
            
            clean_pairs = {}
            for m in re.finditer(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line):
                k = m.group(1)
                v = m.group(2) if m.group(2) is not None else m.group(3)
                clean_pairs[k] = v
            
            svc = clean_pairs.get('service') or clean_pairs.get('function')
            res = clean_pairs.get('resource_id')
            if svc and res:
                parsed_log_records.append({
                    'file': fname,
                    'file_id': fid,
                    'service': svc,
                    'resource_id': res,
                    'event': clean_pairs.get('event'),
                    'http_status': clean_pairs.get('http_status'),
                    'rows': clean_pairs.get('rows'),
                    'result': clean_pairs.get('result'),
                    'integrity': clean_pairs.get('integrity_check'),
                    'keys': [clean_pairs.get(k) for k in ['correlation_key', 'lookup_key', 'subject_key', 'subject_ref', 'match_key', 'matched_value', 'scan_key'] if clean_pairs.get(k)]
                })

df = pd.DataFrame(parsed_log_records)
print(f"Total structured service events parsed from logs: {len(df)}")
print("\n--- Evidence 94 records ---")
print(df[df['file_id'] == 'evidence_94'].head(20).to_string())
print("\n--- Evidence 01 records ---")
print(df[df['file_id'] == 'evidence_01'].head(20).to_string())
