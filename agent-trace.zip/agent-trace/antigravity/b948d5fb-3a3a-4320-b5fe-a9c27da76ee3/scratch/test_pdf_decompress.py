import zlib
import re

with open('dataset/evidence/documents/delivery_correction_attachment.pdf', 'rb') as f:
    data = f.read()

# Match << ... >> stream ... endstream
matches = re.findall(b'<<(.*?)>>[\r\n\s]*stream[\r\n]+(.*?)[\r\n]+endstream', data, re.DOTALL)
print(f"Total stream objects: {len(matches)}")
for i, (meta, s) in enumerate(matches):
    try:
        decomp = zlib.decompress(s)
        print(f"Stream {i} decompressed! Length: {len(decomp)}")
        # print some strings
        txt = re.findall(b'\\(([a-zA-Z0-9@._ -]+)\\)', decomp)
        if txt:
            print("  Strings:", b" | ".join(txt[:10]).decode('latin1'))
    except Exception as e:
        print(f"Stream {i} decompression error: {e}")
