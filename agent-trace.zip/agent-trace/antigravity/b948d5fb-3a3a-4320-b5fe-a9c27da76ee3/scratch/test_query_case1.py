import sqlite3

conn = sqlite3.connect(':memory:')
with open('dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql', 'r', encoding='utf-8') as f:
    conn.executescript(f.read())
cur = conn.cursor()

for uid in ['user_01', 'user_02', 'user_03', 'user_04', 'user_05']:
    cur.execute(f"SELECT resource_id, user_id, account_status FROM customer_profiles_primary WHERE user_id = '{uid}'")
    prim = cur.fetchall()
    cur.execute(f"SELECT resource_id, user_id, account_status FROM customer_profiles_failover_replica WHERE user_id = '{uid}'")
    rep = cur.fetchall()
    print(f"{uid}: primary={prim} replica={rep}")
