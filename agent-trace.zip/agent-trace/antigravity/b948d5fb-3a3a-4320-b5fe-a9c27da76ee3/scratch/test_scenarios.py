import os
import sys
import json
import unittest

sys.stdout.reconfigure(encoding='utf-8')

class TestDeletionAuditScenarios(unittest.TestCase):
    
    def test_01_non_deletion_request(self):
        """Scenario 1: Non-deletion request (access, export, or email change only)."""
        text = "Please change the email address used for this account. I want to continue using the service."
        is_deletion = any(w in text.lower() for w in ["delete", "erase", "close", "suppression", "exclusão", "削除", "eliminar"])
        wants_to_continue = "continue using" in text.lower() or "don't delete" in text.lower() or "do not delete" in text.lower()
        status = "NOT_APPLICABLE" if (wants_to_continue or not is_deletion) else "INCOMPLETE"
        steps = [] if status == "NOT_APPLICABLE" else [{"dummy": 1}]
        self.assertEqual(status, "NOT_APPLICABLE")
        self.assertEqual(steps, [])

    def test_02_historical_identity_resolution(self):
        """Scenario 2: Request uses an old email that was changed in user_audit_log."""
        # Simulated lookup
        req_email = "nadia.ionescu@yahoo.com"
        # In audit log: nadia.ionescu -> nadia.petrescu -> n.petrescu (user_10)
        resolved_user_id = "user_10"
        all_emails = {"nadia.ionescu@yahoo.com", "nadia.petrescu@yahoo.com", "n.petrescu@yahoo.com"}
        self.assertIn(req_email, all_emails)
        self.assertEqual(resolved_user_id, "user_10")

    def test_03_remaining_replica_record(self):
        """Scenario 3: Failover replica still holds customer record while primary deleted it."""
        primary_present = False
        failover_present = True
        resource_id = "account_005"
        system_id = "account_service"
        
        findings = []
        if failover_present:
            findings.append({
                "step_no": 1,
                "phase": "FINDING",
                "system_id": system_id,
                "resource_id": resource_id,
                "operation": "REPORT_REMAINING_RECORD",
                "state": "PRESENT",
                "evidence_id": "evidence_54"
            })
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["operation"], "REPORT_REMAINING_RECORD")
        self.assertEqual(findings[0]["state"], "PRESENT")

    def test_04_exposed_pii_in_support_attachment(self):
        """Scenario 4: Support attachment contains PII belonging only to deletion subject."""
        # Policy rule_06: SUPPORT_ATTACHMENT -> DELETE
        resource_id = "support_001"
        system_id = "support_platform"
        finding = {
            "step_no": 1,
            "phase": "FINDING",
            "system_id": system_id,
            "resource_id": resource_id,
            "operation": "REPORT_REMAINING_RECORD",
            "state": "PRESENT",
            "evidence_id": "evidence_58"
        }
        remediation = {
            "step_no": 2,
            "phase": "REMEDIATION",
            "system_id": system_id,
            "resource_id": resource_id,
            "operation": "DELETE_RECORD",
            "state": "ABSENT",
            "evidence_id": ""
        }
        self.assertEqual(finding["operation"], "REPORT_REMAINING_RECORD")
        self.assertEqual(remediation["operation"], "DELETE_RECORD")

    def test_05_active_data_flow(self):
        """Scenario 5: Active background data flow that can replicate customer data."""
        flow_id = "data_flow_9846"
        is_enabled = True
        findings = []
        remediations = []
        if is_enabled:
            findings.append({
                "step_no": 1,
                "phase": "FINDING",
                "system_id": "integration_service",
                "resource_id": flow_id,
                "operation": "REPORT_ACTIVE_DATA_FLOW",
                "state": "ACTIVE",
                "evidence_id": "evidence_01"
            })
            remediations.append({
                "step_no": 2,
                "phase": "REMEDIATION",
                "system_id": "integration_service",
                "resource_id": flow_id,
                "operation": "DISABLE_DATA_FLOW",
                "state": "DISABLED",
                "evidence_id": ""
            })
        self.assertEqual(findings[0]["operation"], "REPORT_ACTIVE_DATA_FLOW")
        self.assertEqual(remediations[0]["operation"], "DISABLE_DATA_FLOW")

    def test_06_restore_risk(self):
        """Scenario 6: Backup snapshot has restore_allowed=True."""
        restore_allowed = True
        backup_id = "backup_4978"
        findings = []
        remediations = []
        if restore_allowed:
            findings.append({
                "step_no": 1,
                "phase": "FINDING",
                "system_id": "backup_service",
                "resource_id": backup_id,
                "operation": "REPORT_RESTORE_RISK",
                "state": "ACTIVE",
                "evidence_id": "evidence_93"
            })
            remediations.append({
                "step_no": 2,
                "phase": "REMEDIATION",
                "system_id": "backup_service",
                "resource_id": backup_id,
                "operation": "BLOCK_RESTORE",
                "state": "BLOCKED",
                "evidence_id": ""
            })
        self.assertEqual(findings[0]["operation"], "REPORT_RESTORE_RISK")
        self.assertEqual(remediations[0]["operation"], "BLOCK_RESTORE")

    def test_07_tombstone_and_retained_records(self):
        """Scenario 7: Retained audit log remains PRESENT, but tombstone must be REDACTED."""
        audit_id = "audit_record_6909"
        tombstone_id = "tombstone_440"
        # When compliant
        steps = [
            {"step_no": 1, "phase": "VERIFICATION", "system_id": "account_service", "resource_id": "account_4857", "operation": "VERIFY_RECORD_ABSENT", "state": "ABSENT", "evidence_id": "evidence_51"},
            {"step_no": 2, "phase": "VERIFICATION", "system_id": "security_service", "resource_id": audit_id, "operation": "VERIFY_RECORD_PRESENT", "state": "PRESENT", "evidence_id": "evidence_51"},
            {"step_no": 3, "phase": "VERIFICATION", "system_id": "identity_service", "resource_id": tombstone_id, "operation": "VERIFY_RECORD_REDACTED", "state": "REDACTED", "evidence_id": "evidence_51"}
        ]
        self.assertEqual(steps[1]["operation"], "VERIFY_RECORD_PRESENT")
        self.assertEqual(steps[1]["state"], "PRESENT")
        self.assertEqual(steps[2]["operation"], "VERIFY_RECORD_REDACTED")
        self.assertEqual(steps[2]["state"], "REDACTED")

if __name__ == "__main__":
    unittest.main()
