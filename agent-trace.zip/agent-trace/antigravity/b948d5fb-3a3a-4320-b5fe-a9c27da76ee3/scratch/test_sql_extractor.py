import sqlite3, glob, os, json, re
import pandas as pd
import sys
sys.path.insert(0, os.path.abspath('code'))
from identity import IdentityGraph

id_graph = IdentityGraph('dataset')
manifest = pd.read_csv('dataset/evidence_files.csv')
file_to_fid = dict(zip(manifest['file_path'].apply(os.path.basename), manifest['file_id']))

# Load all SQL files and parse observations
sql_files = sorted(glob.glob('dataset/evidence/databases/*.sql'))
print(f"Loading {len(sql_files)} SQL files...")

all_sql_obs = []

for fpath in sql_files:
    fname = os.path.basename(fpath)
    fid = file_to_fid.get(fname, '')
    conn = sqlite3.connect(':memory:')
    with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
        conn.executescript(fp.read())
    
    tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    
    # 1. Check inventory tables
    if 'customer_profiles' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, full_name, email, phone, email_hash, account_status FROM customer_profiles").fetchall():
            res_id, ref, name, email, phone, eh, status = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'account_service', 'resource_id': res_id,
                'category': 'USER_PROFILE',
                'state': 'PRESENT' if status == 'ACTIVE' else 'ABSENT',
                'refs': {x.lower() for x in [ref, email, phone, eh] if x}
            })
            
    if 'customer_search_documents' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, display_name, email, phone, email_hash FROM customer_search_documents").fetchall():
            res_id, ref, name, email, phone, eh = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'search_service', 'resource_id': res_id,
                'category': 'SEARCH_INDEX_ENTRY',
                'state': 'PRESENT',
                'refs': {x.lower() for x in [ref, email, phone, eh] if x}
            })

    if 'customer_analytics_profiles' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, email, phone, email_hash FROM customer_analytics_profiles").fetchall():
            res_id, ref, email, phone, eh = r
            is_pii = bool(email or phone or eh)
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'analytics_platform', 'resource_id': res_id,
                'category': 'ANALYTICS_PROFILE',
                'state': 'PRESENT' if is_pii else 'ANONYMIZED',
                'refs': {x.lower() for x in [ref, email, phone, eh] if x}
            })

    if 'support_records' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, requester_name, requester_email, requester_phone FROM support_records").fetchall():
            res_id, ref, name, email, phone = r
            is_pii = bool(name or email or phone)
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'support_platform', 'resource_id': res_id,
                'category': 'SUPPORT_MESSAGE',
                'state': 'PRESENT' if is_pii else 'REDACTED',
                'refs': {x.lower() for x in [ref, email, phone] if x}
            })

    if 'customer_exports' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, owner_email, owner_phone FROM customer_exports").fetchall():
            res_id, ref, email, phone = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'export_service', 'resource_id': res_id,
                'category': 'USER_EXPORT',
                'state': 'PRESENT',
                'refs': {x.lower() for x in [ref, email, phone] if x}
            })

    if 'connector_subscriptions' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, customer_email, enabled FROM connector_subscriptions").fetchall():
            res_id, ref, email, en = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'integration_service', 'resource_id': res_id,
                'category': 'DATA_FLOW',
                'state': 'ACTIVE' if en == 1 else 'DISABLED',
                'refs': {x.lower() for x in [ref, email] if x}
            })

    if 'backup_restore_entries' in tables:
        for r in conn.execute("SELECT resource_id, customer_reference, customer_email, restore_allowed FROM backup_restore_entries").fetchall():
            res_id, ref, email, ra = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'backup_service', 'resource_id': res_id,
                'category': 'BACKUP_ARCHIVE',
                'state': 'ACTIVE' if ra == 1 else 'BLOCKED',
                'refs': {x.lower() for x in [ref, email] if x}
            })

    if 'security_audit_records' in tables:
        for r in conn.execute("SELECT resource_id, subject_reference FROM security_audit_records").fetchall():
            res_id, ref = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'security_service', 'resource_id': res_id,
                'category': 'SECURITY_AUDIT_LOG',
                'state': 'PRESENT',
                'refs': {x.lower() for x in [ref] if x}
            })

    # 2. Check accounts failover replica
    if 'customer_profiles_failover_replica' in tables:
        for r in conn.execute("SELECT resource_id, user_id, full_name, email, phone, account_status FROM customer_profiles_failover_replica").fetchall():
            res_id, uid, name, email, phone, status = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'account_service', 'resource_id': res_id,
                'category': 'USER_PROFILE',
                'state': 'PRESENT' if status == 'ACTIVE' else 'ABSENT',
                'refs': {x.lower() for x in [uid, email, phone] if x}
            })

    # 3. Check JSON-record replica tables
    replica_tables = [t for t in tables if t.startswith('customer_data_') and t != 'customer_data_primary']
    for rt in replica_tables:
        for r in conn.execute(f"SELECT resource_id, origin_system, collection_name, record_json FROM {rt}").fetchall():
            res_id, origin_sys, coll, rjson_str = r
            try:
                rj = json.loads(rjson_str)
                refs = set()
                for k in ['user_id', 'customer_reference', 'subject_reference', 'email', 'owner_email', 'phone', 'email_hash']:
                    if rj.get(k): refs.add(str(rj[k]).lower())
                
                cat = 'USER_PROFILE'
                st = 'PRESENT'
                if origin_sys == 'account_service':
                    cat = 'USER_PROFILE'
                    st = 'PRESENT' if rj.get('account_status') == 'ACTIVE' else 'ABSENT'
                elif origin_sys == 'search_service':
                    cat = 'SEARCH_INDEX_ENTRY'
                elif origin_sys == 'analytics_platform':
                    cat = 'ANALYTICS_PROFILE'
                    is_pii = bool(rj.get('email') or rj.get('phone') or rj.get('user_id'))
                    st = 'PRESENT' if is_pii else 'ANONYMIZED'
                elif origin_sys == 'integration_service':
                    cat = 'DATA_FLOW'
                    st = 'ACTIVE' if rj.get('enabled') else 'DISABLED'
                elif origin_sys == 'backup_service':
                    cat = 'BACKUP_ARCHIVE'
                    st = 'ACTIVE' if rj.get('restore_allowed') else 'BLOCKED'
                
                all_sql_obs.append({
                    'file_id': fid, 'system_id': origin_sys, 'resource_id': res_id,
                    'category': cat, 'state': st, 'refs': refs
                })
            except:
                pass

    # 4. Search primary
    if 'search_documents_primary' in tables:
        for r in conn.execute("SELECT resource_id, email FROM search_documents_primary").fetchall():
            res_id, email = r
            all_sql_obs.append({
                'file_id': fid, 'system_id': 'search_service', 'resource_id': res_id,
                'category': 'SEARCH_INDEX_ENTRY',
                'state': 'PRESENT',
                'refs': {x.lower() for x in [email] if x}
            })

print(f"Total SQL observations extracted: {len(all_sql_obs)}")

# Check against sample cases case_05 and case_09
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
for cid in ['case_01', 'case_02', 'case_05', 'case_09']:
    row = samples[samples['case_id'] == cid].iloc[0]
    sub = id_graph.resolve(row['email'])
    print(f"\n--- Checking {cid} ({sub.user_id}, {sub.all_emails}) ---")
    matched = []
    for obs in all_sql_obs:
        if obs['refs'] & (sub.all_emails | {sub.user_id.lower()} | sub.all_phones | sub.all_hashes):
            matched.append(obs)
    for m in matched:
        print(f"  [{m['file_id']}] {m['system_id']} {m['resource_id']} {m['category']} {m['state']}")
