import sqlite3, glob, os

files = {
    'inventory': 'dataset/evidence/databases/customer_data_inventory_20260916.sql',
    'accounts_failover': 'dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql',
    'data_failover': 'dataset/evidence/databases/customer_data_failover_replica_20260920.sql',
    'read_replica': 'dataset/evidence/databases/customer_data_read_replica_20260921.sql',
    'regional_replica': 'dataset/evidence/databases/customer_data_regional_replicas_20260519.sql',
    'search_primary': 'dataset/evidence/databases/customer_search_primary_20260910.sql'
}

for name, f in files.items():
    conn = sqlite3.connect(':memory:')
    with open(f, 'r', encoding='utf-8') as fp:
        conn.executescript(fp.read())
    print(f"=== {name} ({os.path.basename(f)}) ===")
    for tbl in conn.execute("SELECT name, sql FROM sqlite_master WHERE type='table'").fetchall():
        print(f"Table: {tbl[0]}")
        print(f"  SQL: {tbl[1]}")
