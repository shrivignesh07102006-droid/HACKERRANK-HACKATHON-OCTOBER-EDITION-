import sqlite3, glob, os

files = sorted(glob.glob('dataset/evidence/databases/*.sql'))
print(f"Total SQL files: {len(files)}")
for f in files:
    conn = sqlite3.connect(':memory:')
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        sql = fp.read()
    try:
        conn.executescript(sql)
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        print(f"{os.path.basename(f)}: {tables}")
    except Exception as e:
        print(f"{os.path.basename(f)}: ERROR: {e}")
