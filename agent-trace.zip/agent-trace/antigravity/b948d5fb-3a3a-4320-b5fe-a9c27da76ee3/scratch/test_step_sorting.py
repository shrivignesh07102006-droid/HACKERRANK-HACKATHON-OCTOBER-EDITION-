import sys
import pandas as pd
import json

sys.stdout.reconfigure(encoding='utf-8')

PHASE_ORDER = {
    'FINDING': 1,
    'REMEDIATION': 2,
    'VERIFICATION': 3
}

OP_ORDER = {
    # Findings
    'REPORT_REMAINING_RECORD': 1,
    'REPORT_EXPOSED_PII': 2,
    'REPORT_ACTIVE_DATA_FLOW': 3,
    'REPORT_RESTORE_RISK': 4,
    
    # Remediation
    'DISABLE_DATA_FLOW': 1,
    'BLOCK_RESTORE': 2,
    'DELETE_RECORD': 3,
    'REDACT_RECORD': 4,
    'ANONYMIZE_RECORD': 5,
    
    # Verification
    'VERIFY_RECORD_ABSENT': 1,
    'VERIFY_RECORD_PRESENT': 2,
    'VERIFY_RECORD_REDACTED': 3,
    'VERIFY_RECORD_ANONYMIZED': 4,
    'VERIFY_DATA_FLOW_DISABLED': 5,
    'VERIFY_RESTORE_BLOCKED': 6,
}

def step_sort_key(step):
    p = PHASE_ORDER.get(step['phase'], 99)
    op = OP_ORDER.get(step['operation'], 99)
    sys_id = step.get('system_id', '')
    res_id = step.get('resource_id', '')
    return (p, op, sys_id, res_id)

df = pd.read_csv('dataset/sample_output.csv')
mismatches = 0
for _, r in df.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    # Check if steps is already sorted according to step_sort_key
    sorted_steps = sorted(steps, key=step_sort_key)
    # Check sequence
    orig_keys = [(s['phase'], s['operation'], s['system_id'], s['resource_id']) for s in steps]
    new_keys = [(s['phase'], s['operation'], s['system_id'], s['resource_id']) for s in sorted_steps]
    if orig_keys != new_keys:
        mismatches += 1
        print(f"Mismatch in {cid}:")
        print("  Original:", orig_keys)
        print("  Sorted:  ", new_keys)

print(f"Total step ordering mismatches across 32 sample cases: {mismatches}")
