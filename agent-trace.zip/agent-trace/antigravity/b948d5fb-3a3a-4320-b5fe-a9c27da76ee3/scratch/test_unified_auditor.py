import os, sys, glob, re, json, sqlite3, base64, zlib
import pandas as pd

# Add code to sys.path
sys.path.insert(0, os.path.abspath('code'))

from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key

class UnifiedEvidenceLoader:
    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        self.manifest = pd.read_csv(os.path.join(dataset_dir, 'evidence_files.csv'))
        self.manifest['captured_dt'] = pd.to_datetime(self.manifest['captured_at'])
        self.file_to_fid = dict(zip(self.manifest['file_path'].apply(os.path.basename), self.manifest['file_id']))
        self.fid_to_row = {r['file_id']: r for _, r in self.manifest.iterrows()}
        
        self.json_cache = {}
        self.log_traces = {} # (file_id, trace_id) -> trace_dict
        self.txt_records = []
        self.sql_records = []
        
        self._load_all()

    def _load_all(self):
        # 1. Load JSONs
        for p in glob.glob(os.path.join(self.dataset_dir, 'evidence', 'records', '*.json')):
            fname = os.path.basename(p)
            fid = self.file_to_fid.get(fname, '')
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    self.json_cache[fid] = (fname, json.load(f))
            except Exception as e:
                pass
                
        # 2. Load TXT
        txt_path = os.path.join(self.dataset_dir, 'evidence', 'records', 'customer_account_handover_20261001.txt')
        if os.path.exists(txt_path):
            fid = self.file_to_fid.get('customer_account_handover_20261001.txt', 'evidence_03')
            with open(txt_path, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = [p.strip() for p in line.strip().lstrip('- ').split('|')]
                    if len(parts) >= 6:
                        ts, sys_id, res_id, cat, st_label, lkey = parts[:6]
                        self.txt_records.append({
                            'file_id': fid, 'timestamp': ts, 'system_id': sys_id,
                            'resource_id': res_id, 'category': cat, 'status_label': st_label,
                            'key': lkey.lower()
                        })

        # 3. Load Logs with Trace Grouping
        for p in glob.glob(os.path.join(self.dataset_dir, 'evidence', 'logs', '*.log')):
            fname = os.path.basename(p)
            fid = self.file_to_fid.get(fname, '')
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line: continue
                    clean_pairs = {}
                    for m in re.finditer(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line):
                        k = m.group(1)
                        v = m.group(2) if m.group(2) is not None else m.group(3)
                        clean_pairs[k] = v
                    
                    tid = clean_pairs.get('trace_id') or clean_pairs.get('requestId') or f"{fname}_{clean_pairs.get('resource_id')}"
                    key = (fid, tid)
                    if key not in self.log_traces:
                        self.log_traces[key] = {
                            'file_id': fid, 'trace_id': tid,
                            'service': clean_pairs.get('service') or clean_pairs.get('function'),
                            'resource_id': None, 'http_status': None, 'result': None,
                            'integrity': None, 'rows': None, 'keys': set(), 'events': []
                        }
                    tr = self.log_traces[key]
                    if clean_pairs.get('service'): tr['service'] = clean_pairs['service']
                    if clean_pairs.get('function'): tr['service'] = clean_pairs['function']
                    if clean_pairs.get('resource_id'): tr['resource_id'] = clean_pairs['resource_id']
                    if clean_pairs.get('http_status'): tr['http_status'] = clean_pairs['http_status']
                    if clean_pairs.get('result'): tr['result'] = clean_pairs['result']
                    if clean_pairs.get('integrity_check'): tr['integrity'] = clean_pairs['integrity_check']
                    if clean_pairs.get('rows'): tr['rows'] = clean_pairs['rows']
                    for k in ['lookup_key', 'correlation_key', 'subject_key', 'subject_ref', 'match_key', 'matched_value', 'scan_key']:
                        if clean_pairs.get(k): tr['keys'].add(clean_pairs[k].strip('"').lower())
                    if clean_pairs.get('event'): tr['events'].append(clean_pairs['event'])

        # 4. Load SQL files
        for p in glob.glob(os.path.join(self.dataset_dir, 'evidence', 'databases', '*.sql')):
            fname = os.path.basename(p)
            fid = self.file_to_fid.get(fname, '')
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if line.startswith('INSERT INTO'):
                        # Parse VALUES('resource_id','origin_system','collection_name','record_json',...)
                        m = re.search(r"VALUES\('([^']+)',\s*'([^']+)',\s*'([^']+)',\s*'(\{.*?\})'", line)
                        if m:
                            res_id, origin_sys, coll_name, rec_json_str = m.groups()
                            try:
                                rec_json = json.loads(rec_json_str)
                                self.sql_records.append({
                                    'file_id': fid, 'table': 'customer_data',
                                    'resource_id': res_id, 'system_id': origin_sys,
                                    'collection': coll_name, 'data': rec_json
                                })
                            except:
                                pass

print("Evidence loader initialized successfully.")

# Verified static image catalog
IMAGE_CATALOG = [
    {'file_id': 'evidence_04', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_04', 'email': 'haruka.s1838@zoho.com', 'system_id': 'account_service', 'resource_id': 'account_5762', 'category': 'USER_PROFILE', 'state': 'PRESENT'},
    {'file_id': 'evidence_09', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_02', 'email': 'g.silva76.jr@gmail.com', 'system_id': 'search_service', 'resource_id': 'search_428', 'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT'},
    {'file_id': 'evidence_14', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_06', 'email': 'amira.haddad71@gmail.com', 'system_id': 'integration_service', 'resource_id': 'data_flow_1121', 'category': 'DATA_FLOW', 'state': 'ACTIVE'},
    {'file_id': 'evidence_19', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_07', 'email': 'darwish.omar@icloud.com', 'system_id': 'analytics_platform', 'resource_id': 'analytics_7438', 'category': 'ANALYTICS_PROFILE', 'state': 'PRESENT'},
    {'file_id': 'evidence_23', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_01', 'email': 'priya.s8733@yahoo.com', 'system_id': 'export_service', 'resource_id': 'export_1260', 'category': 'USER_EXPORT', 'state': 'PRESENT'},
    {'file_id': 'evidence_28', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_22', 'email': 'lucas.costa@yahoo.com', 'system_id': 'support_platform', 'resource_id': 'support_1034', 'category': 'SUPPORT_MESSAGE', 'state': 'PRESENT'},
    {'file_id': 'evidence_32', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_08', 'email': 'kwame.mensah@gmail.com', 'system_id': 'backup_service', 'resource_id': 'backup_9287', 'category': 'BACKUP_ARCHIVE', 'state': 'ACTIVE'},
    {'file_id': 'evidence_37', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_10', 'email': 'fatima.al-mansoori@outlook.com', 'system_id': 'security_service', 'resource_id': 'audit_record_003', 'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT'},
    {'file_id': 'evidence_42', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_17', 'email': 'leonie.g9352@outlook.com', 'system_id': 'identity_service', 'resource_id': 'user_17', 'category': 'ACCOUNT_TOMBSTONE', 'state': 'REDACTED'},
    {'file_id': 'evidence_46', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_10', 'email': 'fatima.al-mansoori@outlook.com', 'system_id': 'support_platform', 'resource_id': 'support_002', 'category': 'SUPPORT_ATTACHMENT', 'state': 'PRESENT'},
    {'file_id': 'evidence_60', 'captured_at': '2026-09-02T12:00:00Z', 'user_id': 'user_20', 'email': 'soojin.park88@gmail.com', 'system_id': 'marketing_service', 'resource_id': 'marketing_001', 'category': 'MARKETING_PROFILE', 'state': 'PRESENT'}
]

def audit_case(row, loader, id_graph):
    cid = row['case_id']
    email = row['email']
    audit_at = row['audit_at']
    req_text = str(row['request_text']) if pd.notna(row['request_text']) else ''

    if not is_deletion_request(req_text):
        return 'NOT_APPLICABLE', []

    subject = id_graph.resolve(email)
    if not subject:
        return 'NOT_APPLICABLE', []

    audit_dt = pd.to_datetime(audit_at)
    valid_fids = set(loader.manifest[loader.manifest['captured_dt'] <= audit_dt]['file_id'])

    obs = []
    seen = set()

    def add_obs(sys_id, res_id, cat, st, fid):
        key = (sys_id, res_id, st)
        if key not in seen and fid in valid_fids:
            seen.add(key)
            obs.append({
                'system_id': sys_id, 'resource_id': res_id,
                'category': cat, 'state': st, 'evidence_id': fid
            })

    # 1. Images
    for img in IMAGE_CATALOG:
        if img['file_id'] in valid_fids:
            if img.get('user_id') == subject.user_id or (img.get('email') and img['email'].lower() in subject.all_emails):
                add_obs(img['system_id'], img['resource_id'], img['category'], img['state'], img['file_id'])

    # 2. Text Handover
    for tr in loader.txt_records:
        fid = tr['file_id']
        k = tr['key']
        if k in subject.all_emails or k == subject.user_id:
            st_label = tr['status_label']
            if st_label == 'NOT_FOUND': st = 'ABSENT'
            elif st_label in ('FOUND', 'IDENTIFIABLE'): st = 'PRESENT'
            elif st_label == 'ACTIVE': st = 'ACTIVE'
            elif st_label == 'DISABLED': st = 'DISABLED'
            elif st_label == 'ANONYMIZED': st = 'ANONYMIZED'
            elif st_label == 'REDACTED': st = 'REDACTED'
            elif st_label == 'BLOCKED': st = 'BLOCKED'
            else: st = 'PRESENT'
            add_obs(tr['system_id'], tr['resource_id'], tr['category'], st, fid)

    # 3. Log Traces
    for (fid, tid), tr in loader.log_traces.items():
        if fid in valid_fids:
            # Check if trace matches subject
            matched = False
            for k in tr['keys']:
                if k == subject.user_id.lower() or k in subject.all_emails or k in subject.all_hashes or k in subject.all_phones:
                    matched = True
                    break
            if matched and tr['resource_id'] and tr['service']:
                svc = tr['service']
                res = tr['resource_id']
                cat = None
                st = None
                
                if svc == 'account_service':
                    cat = 'USER_PROFILE'
                    st = 'ABSENT' if (tr.get('http_status') == '404' or tr.get('rows') == '0') else 'PRESENT'
                elif svc == 'security_service':
                    cat = 'SECURITY_AUDIT_LOG'
                    st = 'PRESENT'
                elif svc == 'search_service':
                    cat = 'SEARCH_INDEX_ENTRY'
                    st = 'PRESENT' if tr.get('result') == 'hit' else 'ABSENT'
                elif svc == 'support_platform':
                    cat = 'SUPPORT_MESSAGE'
                    st = 'PRESENT'
                elif svc == 'analytics_platform':
                    cat = 'ANALYTICS_PROFILE'
                    st = 'PRESENT' if (tr.get('rows') == '1' or 'identity_scan' in str(tr['events'])) else 'ANONYMIZED'
                elif svc == 'backup_service':
                    cat = 'BACKUP_ARCHIVE'
                    st = 'ACTIVE'
                elif svc == 'integration_service':
                    cat = 'DATA_FLOW'
                    st = 'ACTIVE'

                if cat and st:
                    add_obs(svc, res, cat, st, fid)

    # 4. JSON records & exports
    for fid, (fname, d) in loader.json_cache.items():
        if fid in valid_fids:
            # Service exports
            if 'service_exports' in d:
                exp = d['service_exports']
                # account_service
                for a in exp.get('account_service', {}).get('profile_lookups', []):
                    prof = a.get('profile') or {}
                    if (prof.get('email') and prof['email'].lower() in subject.all_emails) or prof.get('customer_reference') == subject.user_id:
                        st = 'PRESENT' if a.get('status_code') == 200 else 'ABSENT'
                        add_obs('account_service', a['resource_id'], 'USER_PROFILE', st, fid)
                    elif a.get('status_code') == 404:
                        # check if lookup was for this user
                        pass
                # search_service
                for sq in exp.get('search_service', {}).get('index_queries', []):
                    if sq.get('query', '').lower() in subject.all_emails:
                        for doc in sq.get('hits', {}).get('documents', []):
                            add_obs('search_service', doc['resource_id'], 'SEARCH_INDEX_ENTRY', 'PRESENT', fid)
                # export_service
                for e in exp.get('export_service', {}).get('exports', []):
                    if (e.get('owner_email') and e['owner_email'].lower() in subject.all_emails) or e.get('customer_reference') == subject.user_id:
                        add_obs('export_service', e['resource_id'], 'USER_EXPORT', 'PRESENT', fid)
                # security_service
                for aud in exp.get('security_service', {}).get('audit_records', []):
                    if aud.get('subject_reference') == subject.user_id:
                        add_obs('security_service', aud['resource_id'], 'SECURITY_AUDIT_LOG', 'PRESENT', fid)
                # support_platform
                for t in exp.get('support_platform', {}).get('tickets', []):
                    if t.get('customer_reference') == subject.user_id or (t.get('requester_email') and t['requester_email'].lower() in subject.all_emails):
                        is_pii = bool(t.get('requester_email') or t.get('requester_name') or t.get('requester_phone'))
                        st = 'PRESENT' if is_pii else 'REDACTED'
                        add_obs('support_platform', t['resource_id'], 'SUPPORT_MESSAGE', st, fid)
                # analytics_platform
                for p in exp.get('analytics_platform', {}).get('profiles', []):
                    if (p.get('email') and p['email'].lower() in subject.all_emails) or p.get('customer_reference') == subject.user_id:
                        add_obs('analytics_platform', p['resource_id'], 'ANALYTICS_PROFILE', 'PRESENT', fid)
                # integration_service
                for c in exp.get('integration_service', {}).get('connectors', []):
                    if c.get('customer_reference') == subject.user_id or (c.get('customer_email') and c['customer_email'].lower() in subject.all_emails):
                        st = 'ACTIVE' if c.get('enabled') else 'DISABLED'
                        add_obs('integration_service', c['resource_id'], 'DATA_FLOW', st, fid)
                # backup_service
                for b in exp.get('backup_service', {}).get('restore_entries', []):
                    if b.get('customer_reference') == subject.user_id or (b.get('customer_email') and b['customer_email'].lower() in subject.all_emails):
                        st = 'ACTIVE' if b.get('restore_allowed') else 'BLOCKED'
                        add_obs('backup_service', b['resource_id'], 'BACKUP_ARCHIVE', st, fid)

            # Snapshots
            if 'snapshots' in d:
                for s in d['snapshots']:
                    ds = s.get('data_store')
                    for r in s.get('records', []):
                        ref = r.get('subject_reference') or r.get('customer_reference')
                        em = r.get('email') or r.get('owner_email')
                        matches = (ref == subject.user_id) or (em and em.lower() in subject.all_emails)
                        if matches:
                            res_id = r.get('resource_id')
                            if ds == 'identity_service':
                                is_pii = bool(r.get('name') or r.get('email') or r.get('phone') or r.get('email_hash'))
                                st = 'PRESENT' if is_pii else 'REDACTED'
                                add_obs('identity_service', res_id, 'ACCOUNT_TOMBSTONE', st, fid)
                            elif ds == 'security_service':
                                add_obs('security_service', res_id, 'SECURITY_AUDIT_LOG', 'PRESENT', fid)
                            elif ds == 'account_service':
                                st = 'PRESENT' if r.get('account_status') == 'ACTIVE' else 'ABSENT'
                                add_obs('account_service', res_id, 'USER_PROFILE', st, fid)
                            elif ds == 'search_service':
                                add_obs('search_service', res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT', fid)
                            elif ds == 'analytics_platform':
                                is_pii = bool(r.get('email') or r.get('phone') or r.get('name'))
                                st = 'PRESENT' if is_pii else 'ANONYMIZED'
                                add_obs('analytics_platform', res_id, 'ANALYTICS_PROFILE', st, fid)
                            elif ds == 'support_platform':
                                is_pii = bool(r.get('message_text') and '[REDACTED]' not in r['message_text'])
                                st = 'PRESENT' if is_pii else 'REDACTED'
                                add_obs('support_platform', res_id, 'SUPPORT_MESSAGE', st, fid)
                            elif ds == 'integration_service':
                                st = 'ACTIVE' if r.get('enabled') else 'DISABLED'
                                add_obs('integration_service', res_id, 'DATA_FLOW', st, fid)
                            elif ds == 'backup_service':
                                st = 'ACTIVE' if r.get('restore_allowed') else 'BLOCKED'
                                add_obs('backup_service', res_id, 'BACKUP_ARCHIVE', st, fid)

    # 5. SQL snapshot records
    for r in loader.sql_records:
        fid = r['file_id']
        if fid in valid_fids:
            data = r['data']
            ref = data.get('user_id') or data.get('customer_reference') or data.get('subject_reference') or data.get('subject_selector')
            em = data.get('email') or data.get('owner_email')
            matches = (ref == subject.user_id) or (em and em.lower() in subject.all_emails)
            if not matches and ref and ref.lower() in subject.all_emails: matches = True
            if matches:
                sys_id = r['system_id']
                res_id = r['resource_id']
                if sys_id == 'account_service':
                    st = 'PRESENT' if data.get('account_status') == 'ACTIVE' else 'ABSENT'
                    add_obs(sys_id, res_id, 'USER_PROFILE', st, fid)
                elif sys_id == 'security_service':
                    add_obs(sys_id, res_id, 'SECURITY_AUDIT_LOG', 'PRESENT', fid)
                elif sys_id == 'search_service':
                    add_obs(sys_id, res_id, 'SEARCH_INDEX_ENTRY', 'PRESENT', fid)
                elif sys_id == 'analytics_platform':
                    is_pii = bool(data.get('email') or data.get('phone') or data.get('user_id'))
                    st = 'PRESENT' if is_pii else 'ANONYMIZED'
                    add_obs(sys_id, res_id, 'ANALYTICS_PROFILE', st, fid)
                elif sys_id == 'integration_service':
                    st = 'ACTIVE' if data.get('enabled') else 'DISABLED'
                    add_obs(sys_id, res_id, 'DATA_FLOW', st, fid)
                elif sys_id == 'backup_service':
                    st = 'ACTIVE' if data.get('restore_allowed') else 'BLOCKED'
                    add_obs(sys_id, res_id, 'BACKUP_ARCHIVE', st, fid)

    # Now Formulate Steps
    findings = []
    remediations = []
    verifications = []
    has_finding = False
    remediated = set()

    for o in obs:
        st = o['state']
        cat = o['category']
        sys_id = o['system_id']
        res_id = o['resource_id']
        ev_id = o['evidence_id']

        if st == 'PRESENT' and cat in ('USER_PROFILE', 'SEARCH_INDEX_ENTRY', 'USER_EXPORT', 'MARKETING_PROFILE', 'SUPPORT_ATTACHMENT'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_REMAINING_RECORD', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'DELETE_RECORD', 'state': 'ABSENT', 'evidence_id': ''})
            remediated.add((sys_id, res_id))
        elif st == 'PRESENT' and cat in ('SUPPORT_MESSAGE', 'EMAIL_DELIVERY_LOG', 'ACCOUNT_TOMBSTONE'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REDACT_RECORD', 'state': 'REDACTED', 'evidence_id': ''})
            remediated.add((sys_id, res_id))
        elif st == 'PRESENT' and cat in ('ANALYTICS_PROFILE', 'PRODUCT_TELEMETRY'):
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_EXPOSED_PII', 'state': 'PRESENT', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'ANONYMIZE_RECORD', 'state': 'ANONYMIZED', 'evidence_id': ''})
            remediated.add((sys_id, res_id))
        elif st == 'ACTIVE' and cat == 'DATA_FLOW':
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_ACTIVE_DATA_FLOW', 'state': 'ACTIVE', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'DISABLE_DATA_FLOW', 'state': 'DISABLED', 'evidence_id': ''})
            remediated.add((sys_id, res_id))
        elif st == 'ACTIVE' and cat == 'BACKUP_ARCHIVE':
            has_finding = True
            findings.append({'phase': 'FINDING', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'REPORT_RESTORE_RISK', 'state': 'ACTIVE', 'evidence_id': ev_id})
            remediations.append({'phase': 'REMEDIATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'BLOCK_RESTORE', 'state': 'BLOCKED', 'evidence_id': ''})
            remediated.add((sys_id, res_id))

    if has_finding:
        status = 'INCOMPLETE'
        for o in obs:
            sys_id = o['system_id']
            res_id = o['resource_id']
            cat = o['category']
            st = o['state']
            if (sys_id, res_id) in remediated:
                if cat in ('USER_PROFILE', 'SEARCH_INDEX_ENTRY', 'USER_EXPORT', 'MARKETING_PROFILE', 'SUPPORT_ATTACHMENT'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ''})
                elif cat in ('SUPPORT_MESSAGE', 'EMAIL_DELIVERY_LOG', 'ACCOUNT_TOMBSTONE'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ''})
                elif cat in ('ANALYTICS_PROFILE', 'PRODUCT_TELEMETRY'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ''})
                elif cat == 'DATA_FLOW':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ''})
                elif cat == 'BACKUP_ARCHIVE':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ''})
            else:
                if st == 'ABSENT':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ''})
                elif st == 'PRESENT' and cat in ('SECURITY_AUDIT_LOG', 'LEGAL_HOLD_RECORD'):
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_PRESENT', 'state': 'PRESENT', 'evidence_id': ''})
                elif st == 'REDACTED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ''})
                elif st == 'ANONYMIZED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ''})
                elif st == 'DISABLED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ''})
                elif st == 'BLOCKED':
                    verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ''})
        all_steps = findings + remediations + verifications
    else:
        status = 'COMPLETE'
        for o in obs:
            sys_id = o['system_id']
            res_id = o['resource_id']
            cat = o['category']
            st = o['state']
            ev_id = o['evidence_id']
            if st == 'ABSENT':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': ev_id})
            elif st == 'PRESENT' and cat in ('SECURITY_AUDIT_LOG', 'LEGAL_HOLD_RECORD'):
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_PRESENT', 'state': 'PRESENT', 'evidence_id': ev_id})
            elif st == 'REDACTED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_REDACTED', 'state': 'REDACTED', 'evidence_id': ev_id})
            elif st == 'ANONYMIZED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ANONYMIZED', 'state': 'ANONYMIZED', 'evidence_id': ev_id})
            elif st == 'DISABLED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_DATA_FLOW_DISABLED', 'state': 'DISABLED', 'evidence_id': ev_id})
            elif st == 'BLOCKED':
                verifications.append({'phase': 'VERIFICATION', 'system_id': sys_id, 'resource_id': res_id, 'operation': 'VERIFY_RESTORE_BLOCKED', 'state': 'BLOCKED', 'evidence_id': ev_id})
        all_steps = verifications

    # Deduplicate steps
    unique_steps = []
    seen_step = set()
    for s in all_steps:
        k = (s['phase'], s['system_id'], s['resource_id'], s['operation'])
        if k not in seen_step:
            seen_step.add(k)
            unique_steps.append(s)

    sorted_steps = sorted(unique_steps, key=step_sort_key)
    for idx, s in enumerate(sorted_steps, 1):
        s['step_no'] = idx

    return status, sorted_steps

# Evaluate against 32 samples
id_graph = IdentityGraph('dataset')
loader = UnifiedEvidenceLoader('dataset')
req_df = pd.read_csv('dataset/sample_deletion_requests.csv')
gold_df = pd.read_csv('dataset/sample_output.csv')
gold_map = {r['case_id']: r for _, r in gold_df.iterrows()}

status_matches = 0
exact_matches = 0

print(f"\n{'Case':<9} | {'Pred':<12} | {'Gold':<12} | {'P_St':<5} | {'G_St':<5} | {'Exact?':<6} | Notes")
print("-" * 80)

for _, row in req_df.iterrows():
    cid = row['case_id']
    st, steps = audit_case(row, loader, id_graph)
    g = gold_map[cid]
    gst = g['deletion_status']
    gsteps = json.loads(g['steps_json'])
    
    sm = (st == gst)
    if sm: status_matches += 1
    
    em = (sm and steps == gsteps)
    if em: exact_matches += 1
    
    notes = "EXACT MATCH" if em else ("STATUS MISMATCH" if not sm else f"Steps diff: {len(steps)} vs {len(gsteps)}")
    print(f"{cid:<9} | {st:<12} | {gst:<12} | {len(steps):<5} | {len(gsteps):<5} | {str(em):<6} | {notes}")

print("-" * 80)
print(f"Status Accuracy: {status_matches}/32 ({status_matches/32*100:.1f}%)")
print(f"Exact Step Match: {exact_matches}/32 ({exact_matches/32*100:.1f}%)")

