import os, sys, json, glob, re, sqlite3
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from identity import IdentityGraph

id_graph = IdentityGraph('dataset')
df_reqs = pd.read_csv('dataset/sample_deletion_requests.csv')
df_act = pd.read_csv('dataset/system_activity.csv')
del_acts = df_act[df_act['source_system'] == 'deletion_worker'].copy()
del_acts['dt'] = pd.to_datetime(del_acts['event_time'])

# For each request, find deletion worker activity window
for _, r in df_reqs.iterrows():
    cid = r['case_id']
    req_dt = pd.to_datetime(r['requested_at'])
    rep_dt = pd.to_datetime(r['reported_at'])
    # Look at the window [rep_dt - 2 hours, rep_dt + 15 min]
    # Because deletion worker finishes right before reported_at!
    sub = del_acts[(del_acts['dt'] >= rep_dt - pd.Timedelta(hours=2)) & (del_acts['dt'] <= rep_dt + pd.Timedelta(minutes=15))]
    resources = sub['resource_id'].tolist()
    if any(k in resources for k in ['analytics_1895', 'analytics_4566', 'analytics_4574', 'analytics_6077', 'analytics_5335']):
        print(f"{cid} ({r['email']}) reported at {rep_dt}:")
        for _, act in sub.iterrows():
            print(f"  {act['event_time']} | {act['target_system']} | {act['event_type']} | {act['resource_id']}")
