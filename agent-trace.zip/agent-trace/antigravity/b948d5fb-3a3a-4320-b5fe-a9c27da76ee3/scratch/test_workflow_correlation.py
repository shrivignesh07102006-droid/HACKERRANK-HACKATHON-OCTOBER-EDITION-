import os, sys, json
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from identity import IdentityGraph

id_graph = IdentityGraph('dataset')
df_reqs = pd.read_csv('dataset/sample_deletion_requests.csv')
df_act = pd.read_csv('dataset/system_activity.csv')
del_acts = df_act[df_act['source_system'] == 'deletion_worker'].copy()

# Known resource links from evidence
res_to_case = {
    'search_9359': 'case_30', 'support_6477': 'case_30', 'data_flow_8524': 'case_30', 'analytics_3697': 'case_30',
    'search_2568': 'case_22', 'data_flow_2406': 'case_22', 'analytics_4440': 'case_22', 'support_835': 'case_22',
    'tombstone_440': 'case_31',
    'tombstone_9178': 'case_32',
    'search_4013': 'case_18', 'analytics_037': 'case_18', 'support_5569': 'case_18', 'data_flow_4890': 'case_18',
    'search_4262': 'case_20', 'data_flow_1770': 'case_20',
    'search_1993': 'case_29', 'support_5281': 'case_29', 'data_flow_3827': 'case_29', 'analytics_5208': 'case_29',
    'search_898': 'case_23', 'export_7364': 'case_23',
    'backup_4978': 'case_09'
}

for cid in ['case_09', 'case_18', 'case_20', 'case_22', 'case_23', 'case_29', 'case_30', 'case_31', 'case_32']:
    # Find rows in del_acts matching any known resource for this case
    c_res = [r for r, c in res_to_case.items() if c == cid]
    matched_acts = del_acts[del_acts['resource_id'].isin(c_res)]
    if len(matched_acts):
        # Look in surrounding window (+/- 10 rows or 2 hours)
        indices = matched_acts.index
        window_indices = set()
        for idx in indices:
            window_indices.update(range(max(0, idx-10), min(len(df_act), idx+11)))
        window_df = del_acts.loc[del_acts.index.intersection(window_indices)]
        accs = window_df[window_df['target_system'] == 'account_service']['resource_id'].tolist()
        print(f"{cid}: known res {c_res} -> window accs: {accs}")
