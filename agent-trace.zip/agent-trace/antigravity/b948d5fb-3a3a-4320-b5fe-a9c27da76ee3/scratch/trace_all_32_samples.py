import os, sys, json, re
import pandas as pd

sys.path.insert(0, os.path.abspath('code'))
from identity import IdentityGraph
from intent import is_deletion_request

samples_req = pd.read_csv('dataset/sample_deletion_requests.csv')
samples_out = pd.read_csv('dataset/sample_output.csv')
id_graph = IdentityGraph('dataset')

print(f"{'Case':<8} | {'Status':<12} | {'Steps':<5} | Breakdown")
print("-" * 80)

for _, r in samples_out.iterrows():
    cid = r['case_id']
    st = r['deletion_status']
    steps = json.loads(r['steps_json'])
    req_row = samples_req[samples_req['case_id'] == cid].iloc[0]
    email = req_row['email']
    sub = id_graph.resolve(email)
    uid = sub.user_id if sub else 'None'
    
    phases = [s['phase'] for s in steps]
    f_count = phases.count('FINDING')
    r_count = phases.count('REMEDIATION')
    v_count = phases.count('VERIFICATION')
    
    step_desc = []
    for s in steps:
        step_desc.append(f"{s['phase'][0]}:{s['system_id']}.{s['resource_id']}:{s['operation']}:{s['state']}:{s['evidence_id']}")
    
    print(f"{cid:<8} | {st:<12} | {len(steps):<5} | ({uid}, {email}) F:{f_count} R:{r_count} V:{v_count}")
    for d in step_desc:
        print(f"         {d}")
