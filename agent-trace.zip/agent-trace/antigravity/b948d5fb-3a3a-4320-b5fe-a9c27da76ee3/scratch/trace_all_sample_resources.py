import json, os, glob, pandas as pd

sample_output = pd.read_csv('dataset/sample_output.csv')
evidence_files = pd.read_csv('dataset/evidence_files.csv')

# Build file map
file_map = dict(zip(evidence_files['file_id'], evidence_files['file_path']))

# Track every (system_id, resource_id) in sample_output
sample_resources = {}
for _, row in sample_output.iterrows():
    cid = row['case_id']
    steps = json.loads(row['steps_json'])
    for s in steps:
        key = (s['system_id'], s['resource_id'])
        if key not in sample_resources:
            sample_resources[key] = []
        sample_resources[key].append((cid, s['phase'], s['operation'], s['evidence_id']))

print(f"Total unique (system_id, resource_id) across all 32 samples: {len(sample_resources)}")

# Let's search where each resource exists across ALL files in dataset/
results = {}
for (sys_id, res_id), cases in sample_resources.items():
    found_in = []
    # 1. Search in evidence_files
    for fid, fpath in file_map.items():
        full_p = os.path.join('dataset', fpath)
        if os.path.exists(full_p):
            try:
                with open(full_p, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if res_id in content:
                        found_in.append(('evidence', fid, fpath))
            except:
                pass
    # 2. Search in system_activity
    # check system_activity
    results[(sys_id, res_id)] = {'cases': cases, 'found_in': found_in}

# Print summary
for (sys_id, res_id), info in sorted(results.items()):
    ev_found = [f[1] for f in info['found_in']]
    case_info = [(c[0], c[1], c[2], c[3]) for c in info['cases']]
    print(f"{sys_id:<20} {res_id:<22} -> Cited in: {case_info} | Found in files: {ev_found}")
