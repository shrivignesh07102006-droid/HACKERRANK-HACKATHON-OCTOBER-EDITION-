import pandas as pd, json, os

output_file = 'output.csv'
req_file = 'dataset/deletion_requests.csv'
manifest_file = 'dataset/evidence_files.csv'

print(f"=== Validating {output_file} against Challenge Contract ===")

# 1. File existence and basic checks
assert os.path.exists(output_file), f"{output_file} missing"
df_out = pd.read_csv(output_file)
df_req = pd.read_csv(req_file)
manifest = pd.read_csv(manifest_file)
manifest['captured_dt'] = pd.to_datetime(manifest['captured_at'])
fid_to_dt = dict(zip(manifest['file_id'], manifest['captured_dt']))
valid_fids = set(manifest['file_id'])

# 2. Row count check
print(f"1. Row count: {len(df_out)} rows (Target: {len(df_req)} rows)")
assert len(df_out) == len(df_req) == 518, f"Expected 518 rows, got {len(df_out)}"

# 3. Columns check
print(f"2. Columns: {df_out.columns.tolist()}")
assert df_out.columns.tolist() == ['case_id', 'deletion_status', 'steps_json'], "Columns mismatch"

# 4. Case ID alignment and ordering
print(f"3. Case ID alignment: {df_out['case_id'].tolist() == df_req['case_id'].tolist()}")
assert df_out['case_id'].tolist() == df_req['case_id'].tolist(), "Case IDs do not match dataset ordering"

# Allowed sets
ALLOWED_STATUSES = {'COMPLETE', 'INCOMPLETE', 'NOT_APPLICABLE'}
ALLOWED_PHASES = {'FINDING', 'REMEDIATION', 'VERIFICATION'}
ALLOWED_OP_STATE = {
    # Findings
    ('REPORT_REMAINING_RECORD', 'PRESENT'),
    ('REPORT_EXPOSED_PII', 'PRESENT'),
    ('REPORT_ACTIVE_DATA_FLOW', 'ACTIVE'),
    ('REPORT_RESTORE_RISK', 'ACTIVE'),
    # Remediation
    ('DISABLE_DATA_FLOW', 'DISABLED'),
    ('BLOCK_RESTORE', 'BLOCKED'),
    ('DELETE_RECORD', 'ABSENT'),
    ('REDACT_RECORD', 'REDACTED'),
    ('ANONYMIZE_RECORD', 'ANONYMIZED'),
    # Verification
    ('VERIFY_RECORD_ABSENT', 'ABSENT'),
    ('VERIFY_RECORD_PRESENT', 'PRESENT'),
    ('VERIFY_RECORD_REDACTED', 'REDACTED'),
    ('VERIFY_RECORD_ANONYMIZED', 'ANONYMIZED'),
    ('VERIFY_DATA_FLOW_DISABLED', 'DISABLED'),
    ('VERIFY_RESTORE_BLOCKED', 'BLOCKED')
}

req_map = {r['case_id']: r for _, r in df_req.iterrows()}

errors = []
status_counts = {'COMPLETE': 0, 'INCOMPLETE': 0, 'NOT_APPLICABLE': 0}
total_steps = 0

for idx, row in df_out.iterrows():
    cid = row['case_id']
    st = row['deletion_status']
    raw_json = row['steps_json']
    req_row = req_map[cid]
    audit_dt = pd.to_datetime(req_row['audit_at'])

    if st not in ALLOWED_STATUSES:
        errors.append(f"Row {idx} ({cid}): Invalid status {st}")
        continue
    status_counts[st] += 1

    try:
        steps = json.loads(raw_json)
    except Exception as e:
        errors.append(f"Row {idx} ({cid}): Invalid JSON - {e}")
        continue

    if not isinstance(steps, list):
        errors.append(f"Row {idx} ({cid}): steps_json is not an array")
        continue

    total_steps += len(steps)

    if st == 'NOT_APPLICABLE':
        if len(steps) != 0:
            errors.append(f"Row {idx} ({cid}): NOT_APPLICABLE must have empty steps [], got {len(steps)} steps")
        continue

    # Check step numbering & schema
    last_phase_rank = 0
    phase_ranks = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}

    for s_idx, step in enumerate(steps, 1):
        if step.get('step_no') != s_idx:
            errors.append(f"Row {idx} ({cid}): Step {s_idx} has invalid step_no {step.get('step_no')}")

        phase = step.get('phase')
        if phase not in ALLOWED_PHASES:
            errors.append(f"Row {idx} ({cid}): Invalid phase {phase} in step {s_idx}")
        else:
            p_rank = phase_ranks[phase]
            if p_rank < last_phase_rank:
                errors.append(f"Row {idx} ({cid}): Phase ordering violation {phase} after prior phase")
            last_phase_rank = p_rank

        op = step.get('operation')
        state = step.get('state')
        if (op, state) not in ALLOWED_OP_STATE:
            errors.append(f"Row {idx} ({cid}): Invalid op/state ({op}, {state}) in step {s_idx}")

        ev = step.get('evidence_id')
        if st == 'INCOMPLETE':
            if phase == 'FINDING':
                if not ev or ev not in valid_fids:
                    errors.append(f"Row {idx} ({cid}): FINDING step {s_idx} must cite valid evidence, got '{ev}'")
                elif fid_to_dt[ev] > audit_dt:
                    errors.append(f"Row {idx} ({cid}): FINDING step {s_idx} cites evidence {ev} captured after audit_at!")
            elif phase in ('REMEDIATION', 'VERIFICATION'):
                if ev != "":
                    errors.append(f"Row {idx} ({cid}): INCOMPLETE {phase} step {s_idx} must have evidence_id '', got '{ev}'")
        elif st == 'COMPLETE':
            if phase != 'VERIFICATION':
                errors.append(f"Row {idx} ({cid}): COMPLETE case has non-VERIFICATION phase {phase}")
            if not ev or ev not in valid_fids:
                errors.append(f"Row {idx} ({cid}): COMPLETE verification step {s_idx} must cite valid evidence, got '{ev}'")
            elif fid_to_dt[ev] > audit_dt:
                errors.append(f"Row {idx} ({cid}): COMPLETE verification step {s_idx} cites evidence {ev} captured after audit_at!")

print("\nValidation Summary:")
print(f"Total rows validated: {len(df_out)}")
print(f"Status distribution: {status_counts}")
print(f"Total steps across all cases: {total_steps}")
print(f"Errors found: {len(errors)}")

if errors:
    print(f"\nFirst 10 errors:")
    for err in errors[:10]:
        print(f"  ERROR: {err}")
else:
    print("\nALL CONTRACT CONSTRAINTS VERIFIED: 0 ERRORS FOUND!")
