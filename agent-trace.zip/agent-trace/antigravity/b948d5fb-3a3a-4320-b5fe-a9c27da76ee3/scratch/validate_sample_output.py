import os
import sys
import json
import glob
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

ALLOWED_PHASES = ["FINDING", "REMEDIATION", "VERIFICATION"]
ALLOWED_STATUSES = ["COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"]

ALLOWED_OP_STATE = {
    # Findings
    "REPORT_REMAINING_RECORD": "PRESENT",
    "REPORT_EXPOSED_PII": "PRESENT",
    "REPORT_ACTIVE_DATA_FLOW": "ACTIVE",
    "REPORT_RESTORE_RISK": "ACTIVE",
    # Remediation
    "DISABLE_DATA_FLOW": "DISABLED",
    "BLOCK_RESTORE": "BLOCKED",
    "DELETE_RECORD": "ABSENT",
    "REDACT_RECORD": "REDACTED",
    "ANONYMIZE_RECORD": "ANONYMIZED",
    # Verification
    "VERIFY_RECORD_ABSENT": "ABSENT",
    "VERIFY_RECORD_PRESENT": "PRESENT",
    "VERIFY_RECORD_REDACTED": "REDACTED",
    "VERIFY_RECORD_ANONYMIZED": "ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED": "DISABLED",
    "VERIFY_RESTORE_BLOCKED": "BLOCKED"
}

PHASE_ORDER = {"FINDING": 1, "REMEDIATION": 2, "VERIFICATION": 3}

OP_ORDER = {
    # Phase 1: Findings
    "REPORT_REMAINING_RECORD": 1,
    "REPORT_EXPOSED_PII": 2,
    "REPORT_ACTIVE_DATA_FLOW": 3,
    "REPORT_RESTORE_RISK": 4,
    # Phase 2: Remediation
    "DISABLE_DATA_FLOW": 1,
    "BLOCK_RESTORE": 2,
    "DELETE_RECORD": 3,
    "REDACT_RECORD": 4,
    "ANONYMIZE_RECORD": 5,
    # Phase 3: Verification
    "VERIFY_RECORD_ABSENT": 1,
    "VERIFY_RECORD_PRESENT": 2,
    "VERIFY_RECORD_REDACTED": 3,
    "VERIFY_RECORD_ANONYMIZED": 4,
    "VERIFY_DATA_FLOW_DISABLED": 5,
    "VERIFY_RESTORE_BLOCKED": 6
}

def validate_sample_output():
    manifest_df = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv"))
    valid_file_ids = set(manifest_df["file_id"])
    activity_df = pd.read_csv(os.path.join(dataset_dir, "system_activity.csv"))
    valid_activity_ids = set(activity_df["activity_id"])
    audit_df = pd.read_csv(os.path.join(dataset_dir, "user_audit_log.csv"))
    valid_audit_ids = set(audit_df["audit_id"])

    all_valid_evidence_ids = valid_file_ids | valid_activity_ids | valid_audit_ids

    sample_out_path = os.path.join(dataset_dir, "sample_output.csv")
    sample_df = pd.read_csv(sample_out_path)

    print(f"=== VALIDATING {sample_out_path} ===")
    print(f"Columns: {list(sample_df.columns)}")
    assert list(sample_df.columns) == ["case_id", "deletion_status", "steps_json"], "Column mismatch!"
    print(f"Row count: {len(sample_df)}")

    errors = []
    warnings = []

    for idx, row in sample_df.iterrows():
        case_id = row["case_id"]
        status = row["deletion_status"]
        steps_raw = row["steps_json"]

        if status not in ALLOWED_STATUSES:
            errors.append(f"{case_id}: Invalid status '{status}'")

        try:
            steps = json.loads(steps_raw)
        except Exception as e:
            errors.append(f"{case_id}: JSON parse error: {e}")
            continue

        if not isinstance(steps, list):
            errors.append(f"{case_id}: steps_json is not an array")
            continue

        if status == "NOT_APPLICABLE":
            if len(steps) != 0:
                errors.append(f"{case_id}: NOT_APPLICABLE must have empty steps_json, got {len(steps)}")
            continue

        if status == "COMPLETE":
            # Must only have VERIFICATION steps
            for s in steps:
                if s.get("phase") != "VERIFICATION":
                    errors.append(f"{case_id} (COMPLETE): Has non-VERIFICATION step: {s}")
                if not s.get("evidence_id"):
                    errors.append(f"{case_id} (COMPLETE): Missing evidence_id in verification step: {s}")

        # Check step_no and fields
        prev_sort_key = None
        for i, s in enumerate(steps):
            expected_step_no = i + 1
            if s.get("step_no") != expected_step_no:
                errors.append(f"{case_id}: Step index {i} has step_no {s.get('step_no')}, expected {expected_step_no}")

            required_keys = ["step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"]
            if set(s.keys()) != set(required_keys):
                diff = set(s.keys()) ^ set(required_keys)
                errors.append(f"{case_id} step {expected_step_no}: Key mismatch: diff={diff}")

            phase = s.get("phase")
            op = s.get("operation")
            state = s.get("state")
            ev_id = s.get("evidence_id")

            if phase not in ALLOWED_PHASES:
                errors.append(f"{case_id} step {expected_step_no}: Invalid phase '{phase}'")

            if op not in ALLOWED_OP_STATE:
                errors.append(f"{case_id} step {expected_step_no}: Unknown operation '{op}'")
            elif ALLOWED_OP_STATE[op] != state:
                errors.append(f"{case_id} step {expected_step_no}: State mismatch for {op}. Expected {ALLOWED_OP_STATE[op]}, got {state}")

            # Evidence ID validation
            if phase == "FINDING":
                if not ev_id:
                    errors.append(f"{case_id} step {expected_step_no}: FINDING step must have evidence_id")
                elif ev_id not in all_valid_evidence_ids:
                    errors.append(f"{case_id} step {expected_step_no}: evidence_id '{ev_id}' not found in manifest/activity/audit")
            elif phase == "REMEDIATION":
                if ev_id != "":
                    errors.append(f"{case_id} step {expected_step_no}: REMEDIATION step must have empty evidence_id, got '{ev_id}'")
            elif phase == "VERIFICATION":
                if status == "INCOMPLETE":
                    if ev_id != "":
                        errors.append(f"{case_id} step {expected_step_no} (INCOMPLETE): VERIFICATION step must have empty evidence_id, got '{ev_id}'")
                elif status == "COMPLETE":
                    if not ev_id:
                        errors.append(f"{case_id} step {expected_step_no} (COMPLETE): VERIFICATION step must have evidence_id")
                    elif ev_id not in all_valid_evidence_ids:
                        errors.append(f"{case_id} step {expected_step_no}: evidence_id '{ev_id}' not found")

            # Check sort ordering
            current_sort_key = (
                PHASE_ORDER.get(phase, 99),
                OP_ORDER.get(op, 99),
                s.get("system_id", ""),
                s.get("resource_id", "")
            )
            if prev_sort_key is not None and current_sort_key < prev_sort_key:
                errors.append(f"{case_id} step {expected_step_no}: Sorting order violated! current={current_sort_key} < prev={prev_sort_key}")
            prev_sort_key = current_sort_key

    print(f"Total errors found in sample_output.csv: {len(errors)}")
    for err in errors[:20]:
        print("  ERROR:", err)
    if not errors:
        print(">>> ALL 32 SAMPLE ROWS STRICTLY CONFORM TO THE CONTRACT! <<<")

if __name__ == "__main__":
    validate_sample_output()
