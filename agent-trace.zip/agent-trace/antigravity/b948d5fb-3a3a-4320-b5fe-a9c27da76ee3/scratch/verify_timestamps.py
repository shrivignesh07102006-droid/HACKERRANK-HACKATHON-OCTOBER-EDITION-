import os
import sys
import json
import sqlite3
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')
dataset_dir = r"d:\hackathon october 26\dataset"

manifest = pd.read_csv(os.path.join(dataset_dir, "evidence_files.csv"))

print(f"Total manifest files: {len(manifest)}")

timestamp_comparisons = []

for idx, row in manifest.iterrows():
    fid = row["file_id"]
    fpath = os.path.join(dataset_dir, row["file_path"])
    cap_at = row["captured_at"]
    ext = os.path.splitext(fpath)[1].lower()
    
    internal_time = None
    if ext == ".json":
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                d = json.load(f)
            internal_time = d.get("captured_at") or d.get("exported_at")
        except Exception:
            pass
    elif ext == ".sql":
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if "Captured at:" in line:
                        internal_time = line.split("Captured at:")[1].strip()
                        break
        except Exception:
            pass
    elif ext == ".txt":
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if "Snapshot:" in line:
                        internal_time = line.split("Snapshot:")[1].strip()
                        break
        except Exception:
            pass
    elif ext == ".log":
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                first_line = f.readline()
                internal_time = first_line.split()[0].strip()
        except Exception:
            pass
            
    timestamp_comparisons.append({
        "file_id": fid,
        "file_path": row["file_path"],
        "manifest_captured_at": cap_at,
        "internal_timestamp": internal_time,
        "matches": (internal_time == cap_at) if internal_time else "N/A"
    })

df_comp = pd.DataFrame(timestamp_comparisons)
print("Timestamp comparison summary:")
print(df_comp["matches"].value_counts())
mismatches = df_comp[df_comp["matches"] == False]
if len(mismatches) > 0:
    print("\nFiles with internal timestamp differing from manifest:")
    for _, r in mismatches.iterrows():
        print(f"  {r['file_id']} ({r['file_path']}): manifest={r['manifest_captured_at']} vs internal={r['internal_timestamp']}")
else:
    print("All comparable internal timestamps match manifest captured_at!")
