import os
import sys
import json
import pandas as pd

def validate_submission_csv(csv_path, req_csv_path='dataset/deletion_requests.csv'):
    print(f"=== Validating {csv_path} ===")
    if not os.path.exists(csv_path):
        print(f"ERROR: File {csv_path} does not exist.")
        return False

    df_out = pd.read_csv(csv_path)
    print(f"Columns: {list(df_out.columns)}")
    print(f"Row count: {len(df_out)}")

    df_req = pd.read_csv(req_csv_path)
    req_case_ids = df_req['case_id'].tolist()

    errors = []

    # 1. Exact columns
    expected_cols = ['case_id', 'deletion_status', 'steps_json']
    if list(df_out.columns) != expected_cols:
        errors.append(f"Columns mismatch: expected {expected_cols}, got {list(df_out.columns)}")

    # 2. Row count and uniqueness
    if len(df_out) != 518:
        errors.append(f"Expected 518 rows, got {len(df_out)}")
    if not df_out['case_id'].is_unique:
        errors.append("Duplicate case_ids found!")
    if df_out['case_id'].tolist() != req_case_ids:
        errors.append("case_id list does not match deletion_requests.csv ascending order!")

    ALLOWED_STATUSES = {'COMPLETE', 'INCOMPLETE', 'NOT_APPLICABLE'}
    ALLOWED_FINDING_OPS = {
        ('REPORT_REMAINING_RECORD', 'PRESENT'),
        ('REPORT_EXPOSED_PII', 'PRESENT'),
        ('REPORT_ACTIVE_DATA_FLOW', 'ACTIVE'),
        ('REPORT_RESTORE_RISK', 'ACTIVE')
    }
    ALLOWED_REMED_OPS = {
        ('DISABLE_DATA_FLOW', 'DISABLED'),
        ('BLOCK_RESTORE', 'BLOCKED'),
        ('DELETE_RECORD', 'ABSENT'),
        ('REDACT_RECORD', 'REDACTED'),
        ('ANONYMIZE_RECORD', 'ANONYMIZED')
    }
    ALLOWED_VERIF_OPS = {
        ('VERIFY_RECORD_ABSENT', 'ABSENT'),
        ('VERIFY_RECORD_PRESENT', 'PRESENT'),
        ('VERIFY_RECORD_REDACTED', 'REDACTED'),
        ('VERIFY_RECORD_ANONYMIZED', 'ANONYMIZED'),
        ('VERIFY_DATA_FLOW_DISABLED', 'DISABLED'),
        ('VERIFY_RESTORE_BLOCKED', 'BLOCKED')
    }

    status_counts = df_out['deletion_status'].value_counts().to_dict()
    print("Status counts:", status_counts)

    REQUIRED_STEP_FIELDS = {'step_no', 'phase', 'system_id', 'resource_id', 'operation', 'state', 'evidence_id'}

    for idx, row in df_out.iterrows():
        cid = row['case_id']
        status = row['deletion_status']
        if status not in ALLOWED_STATUSES:
            errors.append(f"{cid}: invalid status {status}")

        try:
            steps = json.loads(row['steps_json'])
        except Exception as e:
            errors.append(f"{cid}: invalid JSON: {e}")
            continue

        if not isinstance(steps, list):
            errors.append(f"{cid}: steps_json is not an array")
            continue

        if status == 'NOT_APPLICABLE':
            if len(steps) != 0:
                errors.append(f"{cid}: NOT_APPLICABLE must have empty steps_json, got {len(steps)} steps")
        elif status == 'COMPLETE':
            if len(steps) == 0:
                errors.append(f"{cid}: COMPLETE case has empty steps")
            for s in steps:
                if s.get('phase') != 'VERIFICATION':
                    errors.append(f"{cid}: COMPLETE case has non-VERIFICATION step phase {s.get('phase')}")
                if not s.get('evidence_id'):
                    errors.append(f"{cid}: COMPLETE verification step missing evidence_id: {s}")
        elif status == 'INCOMPLETE':
            if len(steps) == 0:
                errors.append(f"{cid}: INCOMPLETE case has empty steps")

        phases = [s.get('phase') for s in steps]
        phase_order = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}
        for i in range(len(phases) - 1):
            if phase_order.get(phases[i], 0) > phase_order.get(phases[i+1], 0):
                errors.append(f"{cid}: Invalid phase order: {phases[i]} before {phases[i+1]}")
                break

        for step_idx, s in enumerate(steps, 1):
            # Check fields
            if set(s.keys()) != REQUIRED_STEP_FIELDS:
                errors.append(f"{cid} step {step_idx}: step fields mismatch: {set(s.keys())} vs {REQUIRED_STEP_FIELDS}")

            if s.get('step_no') != step_idx:
                errors.append(f"{cid}: step_no {s.get('step_no')} != expected {step_idx}")

            phase = s.get('phase')
            op = s.get('operation')
            st = s.get('state')
            ev = s.get('evidence_id')

            if phase == 'FINDING':
                if (op, st) not in ALLOWED_FINDING_OPS:
                    errors.append(f"{cid}: Invalid FINDING op/state: ({op}, {st})")
                if not ev:
                    errors.append(f"{cid}: FINDING must have evidence_id, got empty")
            elif phase == 'REMEDIATION':
                if (op, st) not in ALLOWED_REMED_OPS:
                    errors.append(f"{cid}: Invalid REMEDIATION op/state: ({op}, {st})")
                if ev != "":
                    errors.append(f"{cid}: REMEDIATION evidence_id must be empty string, got '{ev}'")
            elif phase == 'VERIFICATION':
                if (op, st) not in ALLOWED_VERIF_OPS:
                    errors.append(f"{cid}: Invalid VERIFICATION op/state: ({op}, {st})")
                if status == 'INCOMPLETE' and ev != "":
                    errors.append(f"{cid}: INCOMPLETE post-remediation verification evidence_id must be empty string, got '{ev}'")

    print(f"Total validation errors: {len(errors)}")
    if errors:
        print("First 10 errors:")
        for err in errors[:10]:
            print("  ", err)
        return False
    else:
        print("ALL ESSENTIAL CHECKS PASSED WITH 0 ERRORS!")
        return True

if __name__ == '__main__':
    csv_to_check = sys.argv[1] if len(sys.argv) > 1 else 'output.csv'
    success = validate_submission_csv(csv_to_check)
    sys.exit(0 if success else 1)
