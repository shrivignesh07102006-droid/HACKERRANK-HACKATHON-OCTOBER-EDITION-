"""
code/evidence_index.py - Comprehensive Multi-Source Evidence Engine for Ghost Data Still Exists.
Parses, indexes, and enables in-memory temporal queries across all 94 evidence files:
- 24 SQLite-compatible database snapshots (inventory tables, read/failover/regional replicas)
- 26 Structured service and trace logs with requestId / traceId correlation (KV & JSON-lines)
- 29 JSON records, service exports, and snapshot bundles
- 1 TXT handover registry
- 4 ReportLab PDF documents (ASCII85 + Flate decompression)
- 10 Console screenshots (cataloged from verified visual inspection)
"""

import os
import glob
import json
import sqlite3
import base64
import zlib
import re
import pandas as pd
from typing import Dict, List, Set, Any, Optional
from dataclasses import dataclass

@dataclass
class EvidenceFileMeta:
    file_id: str
    file_path: str
    origin: str
    captured_at: str
    captured_dt: pd.Timestamp

class EvidenceIndex:
    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        self.ev_dir = os.path.join(dataset_dir, 'evidence')
        self.manifest_df = pd.read_csv(os.path.join(dataset_dir, 'evidence_files.csv'))
        self.manifest_df['captured_dt'] = pd.to_datetime(self.manifest_df['captured_at'])
        
        self.file_to_fid: Dict[str, str] = dict(zip(
            self.manifest_df['file_path'].apply(os.path.basename),
            self.manifest_df['file_id']
        ))
        self.fid_to_meta: Dict[str, EvidenceFileMeta] = {}
        for _, row in self.manifest_df.iterrows():
            fid = str(row['file_id']).strip()
            fpath = str(row['file_path']).strip().replace('\\', '/')
            meta = EvidenceFileMeta(
                file_id=fid,
                file_path=fpath,
                origin=str(row['origin']).strip(),
                captured_at=str(row['captured_at']).strip(),
                captured_dt=row['captured_dt']
            )
            self.fid_to_meta[fid] = meta

        # In-memory structured indices
        self.json_cache: Dict[str, Any] = {}
        self.txt_records: List[Dict[str, Any]] = []
        self.log_traces: Dict[tuple, Dict[str, Any]] = {}
        self.sql_observations: List[Dict[str, Any]] = []
        self.pdf_observations: List[Dict[str, Any]] = []
        self.res_to_user: Dict[str, str] = {}
        self.res_to_email: Dict[str, str] = {}

        # Verified visual screenshot catalog from manual inspection
        self.image_entries = [
            {'file_id': 'evidence_04', 'captured_at': '2026-09-26T11:00:00Z', 'user_id': 'user_11', 'email': 'haruka.s1838@zoho.com', 'system_id': 'account_service', 'resource_id': 'account_5762', 'category': 'USER_PROFILE', 'state': 'PRESENT'},
            {'file_id': 'evidence_09', 'captured_at': '2026-09-01T06:00:00Z', 'user_id': 'user_13', 'email': 'g.silva76@gmail.com', 'system_id': 'search_service', 'resource_id': 'search_428', 'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT'},
            {'file_id': 'evidence_14', 'captured_at': '2026-08-07T08:00:00Z', 'user_id': 'user_14', 'email': 'jain.aditi@gmail.com', 'system_id': 'integration_service', 'resource_id': 'data_flow_1121', 'category': 'DATA_FLOW', 'state': 'ACTIVE'},
            {'file_id': 'evidence_19', 'captured_at': '2026-07-13T10:00:00Z', 'user_id': 'user_20', 'email': 'darwish.omar@icloud.com', 'system_id': 'analytics_platform', 'resource_id': 'analytics_7438', 'category': 'ANALYTICS_PROFILE', 'state': 'PRESENT'},
            {'file_id': 'evidence_24', 'captured_at': '2026-06-18T12:00:00Z', 'user_id': 'user_18', 'email': 'ingrid.dahl@outlook.com', 'system_id': 'export_service', 'resource_id': 'export_1260', 'category': 'USER_EXPORT', 'state': 'PRESENT'},
            {'file_id': 'evidence_29', 'captured_at': '2026-05-24T07:00:00Z', 'user_id': 'user_22', 'email': 'kagyeman8947@fastmail.com', 'system_id': 'support_platform', 'resource_id': 'support_1034', 'category': 'SUPPORT_MESSAGE', 'state': 'PRESENT'},
            {'file_id': 'evidence_34', 'captured_at': '2026-04-29T09:00:00Z', 'user_id': 'user_16', 'email': 'areed1433@gmail.com', 'system_id': 'backup_service', 'resource_id': 'backup_9287', 'category': 'BACKUP_ARCHIVE', 'state': 'ACTIVE'},
            {'file_id': 'evidence_39', 'captured_at': '2026-04-04T11:00:00Z', 'user_id': 'user_17', 'email': 'elena.popa@gmail.com', 'system_id': 'account_service', 'resource_id': 'account_4092', 'category': 'USER_PROFILE', 'state': 'PRESENT'},
            {'file_id': 'evidence_43', 'captured_at': '2026-03-10T06:00:00Z', 'user_id': 'user_17', 'email': 'leonie.g9352@outlook.com', 'system_id': 'identity_service', 'resource_id': 'tombstone_17', 'category': 'ACCOUNT_TOMBSTONE', 'state': 'REDACTED'},
            {'file_id': 'evidence_55', 'captured_at': '2026-09-16T07:20:00Z', 'user_id': 'user_09', 'email': 'kwame-mensah@proton.me', 'system_id': 'marketing_platform', 'resource_id': 'marketing_001', 'category': 'MARKETING_PROFILE', 'state': 'PRESENT'}
        ]
        for img in self.image_entries:
            if img.get('user_id'): self.res_to_user[img['resource_id']] = img['user_id']
            if img.get('email'): self.res_to_email[img['resource_id']] = img['email'].lower()

        self._load_all()

    def _extract_pdf(self, fpath: str) -> tuple:
        fname = os.path.basename(fpath)
        fid = self.file_to_fid.get(fname, '')
        with open(fpath, 'rb') as f:
            data = f.read()
        
        idx = 0
        all_text = []
        while True:
            s_pos = data.find(b'stream\n', idx)
            if s_pos == -1: break
            content_start = s_pos + 7
            e_pos = data.find(b'endstream', content_start)
            if e_pos == -1: break
            raw_stream = data[content_start:e_pos].rstrip(b'\r\n')
            
            try:
                s_adobe = raw_stream
                if not s_adobe.startswith(b'<~'): s_adobe = b'<~' + s_adobe
                if not s_adobe.endswith(b'~>'): s_adobe = s_adobe + b'~>'
                a85 = base64.a85decode(s_adobe, adobe=True)
                dec = zlib.decompress(a85)
                text = dec.decode('latin1', errors='ignore')
                all_text.append(text)
            except Exception:
                pass
            idx = e_pos + 9
        return fid, ' '.join(all_text)

    def _load_all(self):
        # 1. JSON records & exports
        for p in glob.glob(os.path.join(self.ev_dir, 'records', '*.json')):
            fname = os.path.basename(p)
            fid = self.file_to_fid.get(fname, '')
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    d = json.load(f)
                    self.json_cache[fid] = (fname, d)

                    # Map service_exports
                    if 'service_exports' in d:
                        for sname, sdata in d['service_exports'].items():
                            for coll, items in sdata.items():
                                for it in items:
                                    rid = it.get('resource_id')
                                    if not rid: continue
                                    u = it.get('customer_reference') or it.get('subject_reference') or it.get('user_id')
                                    em = it.get('email') or it.get('owner_email') or it.get('customer_email') or it.get('requester_email')
                                    if u: self.res_to_user[rid] = u
                                    if em: self.res_to_email[rid] = em.lower()
                                    if 'profile' in it and isinstance(it['profile'], dict):
                                        pu = it['profile'].get('customer_reference')
                                        pem = it['profile'].get('email')
                                        if pu: self.res_to_user[rid] = pu
                                        if pem: self.res_to_email[rid] = pem.lower()
                                    if 'hits' in it and isinstance(it['hits'], dict):
                                        for doc in it['hits'].get('documents', []):
                                            d_rid = doc.get('resource_id')
                                            d_u = doc.get('customer_reference')
                                            d_em = doc.get('email')
                                            if d_rid and d_u: self.res_to_user[d_rid] = d_u
                                            if d_rid and d_em: self.res_to_email[d_rid] = d_em.lower()

                    # Map snapshots
                    if 'snapshots' in d:
                        for s in d['snapshots']:
                            for r in s.get('records', []):
                                rid = r.get('resource_id')
                                if not rid: continue
                                u = r.get('subject_reference') or r.get('customer_reference') or r.get('user_id')
                                em = r.get('email') or r.get('owner_email') or r.get('customer_email') or r.get('requester_email')
                                if u: self.res_to_user[rid] = u
                                if em: self.res_to_email[rid] = em.lower()
                                if 'document' in r and isinstance(r['document'], dict):
                                    du = r['document'].get('customer_reference')
                                    dem = r['document'].get('email')
                                    if du: self.res_to_user[rid] = du
                                    if dem: self.res_to_email[rid] = dem.lower()

                    # Map direct collections
                    if 'records' in d:
                        for r in d.get('records', []):
                            rid = r.get('resource_id')
                            if not rid: continue
                            u = r.get('subject_reference') or r.get('customer_reference') or r.get('user_id')
                            em = r.get('email') or r.get('owner_email') or r.get('customer_email') or r.get('requester_email')
                            if u: self.res_to_user[rid] = u
                            if em: self.res_to_email[rid] = em.lower()
            except Exception:
                pass

        # 2. TXT records
        txt_path = os.path.join(self.ev_dir, 'records', 'customer_account_handover_20261001.txt')
        if os.path.exists(txt_path):
            fid = self.file_to_fid.get('customer_account_handover_20261001.txt', 'evidence_03')
            with open(txt_path, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = [p.strip() for p in line.strip().lstrip('- ').split('|')]
                    if len(parts) >= 6:
                        ts, sys_id, res_id, cat, st_label, lkey = parts[:6]
                        self.txt_records.append({
                            'file_id': fid, 'timestamp': ts, 'system_id': sys_id,
                            'resource_id': res_id, 'category': cat, 'status_label': st_label,
                            'key': lkey.lower()
                        })
                        if '@' in lkey:
                            self.res_to_email[res_id] = lkey.lower()
                        elif lkey.startswith('user_'):
                            self.res_to_user[res_id] = lkey

        # 3. Logs with Trace Grouping (supporting both KV and JSON lines)
        for p in glob.glob(os.path.join(self.ev_dir, 'logs', '*.log')):
            fname = os.path.basename(p)
            fid = self.file_to_fid.get(fname, '')
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line: continue
                    clean_pairs = {}
                    
                    brace_idx = line.find('{')
                    if brace_idx != -1:
                        try:
                            clean_pairs = json.loads(line[brace_idx:])
                        except Exception:
                            clean_pairs = {}
                    
                    if not clean_pairs:
                        for m in re.finditer(r'(\w+)=(?:"([^"]*)"|([^\s]+))', line):
                            k = m.group(1)
                            v = m.group(2) if m.group(2) is not None else m.group(3)
                            clean_pairs[k] = v

                    tid = clean_pairs.get('trace_id') or clean_pairs.get('requestId') or f"{fname}_{clean_pairs.get('resource_id')}"
                    key = (fid, tid)
                    if key not in self.log_traces:
                        self.log_traces[key] = {
                            'file_id': fid, 'trace_id': tid,
                            'service': clean_pairs.get('service') or clean_pairs.get('function') or clean_pairs.get('logger'),
                            'resource_id': None, 'http_status': None, 'result': None,
                            'integrity': None, 'rows': None, 'marker_found': None,
                            'keys': set(), 'events': [], 'raw_props': {}
                        }
                    tr = self.log_traces[key]
                    tr['raw_props'].update(clean_pairs)
                    if clean_pairs.get('service'): tr['service'] = clean_pairs['service']
                    if clean_pairs.get('function'): tr['service'] = clean_pairs['function']
                    if clean_pairs.get('logger'): tr['service'] = clean_pairs['logger']
                    if clean_pairs.get('resource_id'): tr['resource_id'] = clean_pairs['resource_id']
                    if clean_pairs.get('http_status'): tr['http_status'] = str(clean_pairs['http_status'])
                    if clean_pairs.get('result'): tr['result'] = clean_pairs['result']
                    if clean_pairs.get('integrity_check'): tr['integrity'] = clean_pairs['integrity_check']
                    if clean_pairs.get('rows'): tr['rows'] = str(clean_pairs['rows'])
                    if clean_pairs.get('marker_found'): tr['marker_found'] = str(clean_pairs['marker_found'])
                    
                    for k in ['lookup_key', 'correlation_key', 'subject_key', 'subject_ref', 'match_key', 'matched_value', 'scan_key', 'subject_reference', 'email', 'requester_email']:
                        val = clean_pairs.get(k)
                        if val and str(val).lower() != 'null':
                            s_val = str(val).strip('"').lower()
                            tr['keys'].add(s_val)
                            if tr['resource_id']:
                                if '@' in s_val: self.res_to_email[tr['resource_id']] = s_val
                                elif s_val.startswith('user_'): self.res_to_user[tr['resource_id']] = s_val

                    if clean_pairs.get('event'): tr['events'].append(clean_pairs['event'])

        # 4. SQLite parsing for all 24 database snapshots
        sql_files = sorted(glob.glob(os.path.join(self.ev_dir, 'databases', '*.sql')))
        for fpath in sql_files:
            fname = os.path.basename(fpath)
            fid = self.file_to_fid.get(fname, '')
            conn = sqlite3.connect(':memory:')
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as fp:
                conn.executescript(fp.read())
            
            tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            
            if 'customer_profiles' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, full_name, email, phone, email_hash, account_status FROM customer_profiles").fetchall():
                    res_id, ref, name, email, phone, eh, status = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'account_service', 'resource_id': res_id,
                        'category': 'USER_PROFILE', 'state': 'PRESENT' if status == 'ACTIVE' else 'ABSENT',
                        'refs': {x.lower() for x in [ref, email, phone, eh] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'customer_search_documents' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, display_name, email, phone, email_hash FROM customer_search_documents").fetchall():
                    res_id, ref, name, email, phone, eh = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'search_service', 'resource_id': res_id,
                        'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT',
                        'refs': {x.lower() for x in [ref, email, phone, eh] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'search_documents_primary' in tables:
                for r in conn.execute("SELECT resource_id, email FROM search_documents_primary").fetchall():
                    res_id, email = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'search_service', 'resource_id': res_id,
                        'category': 'SEARCH_INDEX_ENTRY', 'state': 'PRESENT',
                        'refs': {x.lower() for x in [email] if x}
                    })
                    if email: self.res_to_email[res_id] = email.lower()

            if 'customer_analytics_profiles' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, email, phone, email_hash FROM customer_analytics_profiles").fetchall():
                    res_id, ref, email, phone, eh = r
                    is_pii = bool(email or phone or eh)
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'analytics_platform', 'resource_id': res_id,
                        'category': 'ANALYTICS_PROFILE', 'state': 'PRESENT' if is_pii else 'ANONYMIZED',
                        'refs': {x.lower() for x in [ref, email, phone, eh] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'support_records' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, requester_name, requester_email, requester_phone FROM support_records").fetchall():
                    res_id, ref, name, email, phone = r
                    is_pii = bool(name or email or phone)
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'support_platform', 'resource_id': res_id,
                        'category': 'SUPPORT_MESSAGE', 'state': 'PRESENT' if is_pii else 'REDACTED',
                        'refs': {x.lower() for x in [ref, email, phone] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'customer_exports' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, owner_email, owner_phone FROM customer_exports").fetchall():
                    res_id, ref, email, phone = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'export_service', 'resource_id': res_id,
                        'category': 'USER_EXPORT', 'state': 'PRESENT',
                        'refs': {x.lower() for x in [ref, email, phone] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'connector_subscriptions' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, customer_email, enabled FROM connector_subscriptions").fetchall():
                    res_id, ref, email, en = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'integration_service', 'resource_id': res_id,
                        'category': 'DATA_FLOW', 'state': 'ACTIVE' if en == 1 else 'DISABLED',
                        'refs': {x.lower() for x in [ref, email] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'backup_restore_entries' in tables:
                for r in conn.execute("SELECT resource_id, customer_reference, customer_email, restore_allowed FROM backup_restore_entries").fetchall():
                    res_id, ref, email, ra = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'backup_service', 'resource_id': res_id,
                        'category': 'BACKUP_ARCHIVE', 'state': 'ACTIVE' if ra == 1 else 'BLOCKED',
                        'refs': {x.lower() for x in [ref, email] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref
                    if email: self.res_to_email[res_id] = email.lower()

            if 'security_audit_records' in tables:
                for r in conn.execute("SELECT resource_id, subject_reference FROM security_audit_records").fetchall():
                    res_id, ref = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'security_service', 'resource_id': res_id,
                        'category': 'SECURITY_AUDIT_LOG', 'state': 'PRESENT',
                        'refs': {x.lower() for x in [ref] if x}
                    })
                    if ref: self.res_to_user[res_id] = ref

            if 'customer_profiles_failover_replica' in tables:
                for r in conn.execute("SELECT resource_id, user_id, full_name, email, phone, account_status FROM customer_profiles_failover_replica").fetchall():
                    res_id, uid, name, email, phone, status = r
                    self.sql_observations.append({
                        'file_id': fid, 'system_id': 'account_service', 'resource_id': res_id,
                        'category': 'USER_PROFILE', 'state': 'PRESENT' if status == 'ACTIVE' else 'ABSENT',
                        'refs': {x.lower() for x in [uid, email, phone] if x}
                    })
                    if uid: self.res_to_user[res_id] = uid
                    if email: self.res_to_email[res_id] = email.lower()

            replica_tables = [t for t in tables if t.startswith('customer_data_') and t != 'customer_data_primary']
            for rt in replica_tables:
                for r in conn.execute(f"SELECT resource_id, origin_system, collection_name, record_json FROM {rt}").fetchall():
                    res_id, origin_sys, coll, rjson_str = r
                    try:
                        rj = json.loads(rjson_str)
                        refs = set()
                        for k in ['user_id', 'customer_reference', 'subject_reference', 'email', 'owner_email', 'phone', 'email_hash']:
                            if rj.get(k): refs.add(str(rj[k]).lower())
                        doc = rj.get('document') or {}
                        for k in ['user_id', 'customer_reference', 'subject_reference', 'email', 'owner_email', 'phone', 'email_hash', 'display_name']:
                            if doc.get(k): refs.add(str(doc[k]).lower())

                        cat = 'USER_PROFILE'
                        st = 'PRESENT'
                        if origin_sys == 'account_service':
                            cat = 'USER_PROFILE'
                            st = 'PRESENT' if rj.get('account_status') == 'ACTIVE' else 'ABSENT'
                        elif origin_sys == 'search_service':
                            cat = 'SEARCH_INDEX_ENTRY'
                        elif origin_sys == 'security_service':
                            cat = 'SECURITY_AUDIT_LOG'
                            st = 'PRESENT'
                        elif origin_sys == 'analytics_platform':
                            cat = 'ANALYTICS_PROFILE'
                            is_pii = bool(rj.get('email') or rj.get('phone') or rj.get('user_id'))
                            st = 'PRESENT' if is_pii else 'ANONYMIZED'
                        elif origin_sys == 'integration_service':
                            cat = 'DATA_FLOW'
                            st = 'ACTIVE' if rj.get('enabled') else 'DISABLED'
                        elif origin_sys == 'backup_service':
                            cat = 'BACKUP_ARCHIVE'
                            st = 'ACTIVE' if rj.get('restore_allowed') else 'BLOCKED'
                        
                        self.sql_observations.append({
                            'file_id': fid, 'system_id': origin_sys, 'resource_id': res_id,
                            'category': cat, 'state': st, 'refs': refs
                        })

                        u = rj.get('customer_reference') or rj.get('subject_reference') or rj.get('user_id') or doc.get('customer_reference')
                        em = rj.get('email') or rj.get('owner_email') or doc.get('email')
                        if u: self.res_to_user[res_id] = u
                        if em: self.res_to_email[res_id] = em.lower()
                    except Exception:
                        pass
            conn.close()

        # 5. ReportLab PDF documents
        for p in glob.glob(os.path.join(self.ev_dir, 'documents', '*.pdf')):
            fid, text = self._extract_pdf(p)
            self.pdf_observations.append({'file_id': fid, 'filename': os.path.basename(p), 'text': text})
            m_ref = re.search(r'reference\s+([A-Z0-9_-]+)\s*/\s*([a-z0-9_-]+)', text)
            m_em = re.search(r'([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)', text)
            if m_ref and m_em:
                res_id = m_ref.group(2)
                email = m_em.group(1).lower()
                self.res_to_email[res_id] = email
