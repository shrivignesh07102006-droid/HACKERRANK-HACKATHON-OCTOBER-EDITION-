"""
code/identity.py - Identity resolution module for Ghost Data Still Exists.
Resolves stable user_id, current and historical emails, names, phones, and email hashes.
"""

import os
import pandas as pd
from typing import Dict, Set, Optional, List
from dataclasses import dataclass, field

@dataclass
class UserSubject:
    user_id: str
    current_name: Optional[str] = None
    historical_names: Set[str] = field(default_factory=set)
    current_email: Optional[str] = None
    historical_emails: Set[str] = field(default_factory=set)
    current_phone: Optional[str] = None
    historical_phones: Set[str] = field(default_factory=set)
    email_hash: Optional[str] = None
    historical_hashes: Set[str] = field(default_factory=set)
    updated_at: Optional[str] = None

    @property
    def all_emails(self) -> Set[str]:
        emails = set(self.historical_emails)
        if self.current_email:
            emails.add(self.current_email)
        return {e.lower() for e in emails if e}

    @property
    def all_names(self) -> Set[str]:
        names = set(self.historical_names)
        if self.current_name:
            names.add(self.current_name)
        return {n for n in names if n}

    @property
    def all_phones(self) -> Set[str]:
        phones = set(self.historical_phones)
        if self.current_phone:
            phones.add(self.current_phone)
        return {p for p in phones if p}

    @property
    def all_hashes(self) -> Set[str]:
        hashes = set(self.historical_hashes)
        if self.email_hash:
            hashes.add(self.email_hash)
        return {h for h in hashes if h}

    @property
    def all_identifiers(self) -> Set[str]:
        res = {self.user_id}
        res.update(self.all_emails)
        res.update(self.all_names)
        res.update(self.all_phones)
        res.update(self.all_hashes)
        return res


class IdentityGraph:
    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        self.users_by_id: Dict[str, UserSubject] = {}
        self.email_to_user_id: Dict[str, str] = {}
        self.phone_to_user_id: Dict[str, str] = {}
        self.hash_to_user_id: Dict[str, str] = {}
        self._load_identities()
        self._load_audit_log()

    def _load_identities(self):
        path = os.path.join(self.dataset_dir, 'user_identities.csv')
        df = pd.read_csv(path)
        for _, row in df.iterrows():
            uid = str(row['user_id']).strip()
            name = str(row['name']).strip() if pd.notna(row['name']) else None
            email = str(row['email']).strip().lower() if pd.notna(row['email']) else None
            phone = str(row['phone']).strip() if pd.notna(row['phone']) else None
            ehash = str(row['email_hash']).strip().lower() if pd.notna(row['email_hash']) else None
            updated_at = str(row['updated_at']).strip() if pd.notna(row['updated_at']) else None

            subject = UserSubject(
                user_id=uid,
                current_name=name,
                current_email=email,
                current_phone=phone,
                email_hash=ehash,
                updated_at=updated_at
            )
            self.users_by_id[uid] = subject
            if email:
                self.email_to_user_id[email] = uid
            if phone:
                self.phone_to_user_id[phone] = uid
            if ehash:
                self.hash_to_user_id[ehash] = uid

    def _load_audit_log(self):
        path = os.path.join(self.dataset_dir, 'user_audit_log.csv')
        df = pd.read_csv(path)
        for _, row in df.iterrows():
            uid = str(row['user_id']).strip()
            if uid not in self.users_by_id:
                self.users_by_id[uid] = UserSubject(user_id=uid)
            subject = self.users_by_id[uid]

            field_name = str(row['field_name']).strip().lower()
            old_val = str(row['old_value']).strip() if pd.notna(row['old_value']) else None
            new_val = str(row['new_value']).strip() if pd.notna(row['new_value']) else None

            if field_name == 'email':
                if old_val:
                    old_em = old_val.lower()
                    subject.historical_emails.add(old_em)
                    if old_em not in self.email_to_user_id:
                        self.email_to_user_id[old_em] = uid
                if new_val:
                    new_em = new_val.lower()
                    subject.historical_emails.add(new_em)
                    if new_em not in self.email_to_user_id:
                        self.email_to_user_id[new_em] = uid
            elif field_name == 'phone':
                if old_val:
                    subject.historical_phones.add(old_val)
                    if old_val not in self.phone_to_user_id:
                        self.phone_to_user_id[old_val] = uid
                if new_val:
                    subject.historical_phones.add(new_val)
                    if new_val not in self.phone_to_user_id:
                        self.phone_to_user_id[new_val] = uid
            elif field_name in ('name', 'full_name'):
                if old_val:
                    subject.historical_names.add(old_val)
                if new_val:
                    subject.historical_names.add(new_val)
            elif field_name in ('email_hash', 'hash'):
                if old_val:
                    subject.historical_hashes.add(old_val.lower())
                if new_val:
                    subject.historical_hashes.add(new_val.lower())

    def resolve(self, email_or_id: str) -> Optional[UserSubject]:
        term = email_or_id.strip()
        term_lower = term.lower()
        if term in self.users_by_id:
            return self.users_by_id[term]
        if term_lower in self.email_to_user_id:
            uid = self.email_to_user_id[term_lower]
            return self.users_by_id.get(uid)
        return None
