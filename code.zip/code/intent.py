"""
code/intent.py - Intent classification module for deletion requests.
Determines if request_text actually authorizes account/data deletion,
or if it is a non-deletion request (access, export, invoices, modification) -> NOT_APPLICABLE.
"""

import re
from typing import Optional

def is_deletion_request(text: Optional[str]) -> bool:
    """
    Returns True if request_text authorizes deletion.
    Returns False if it is a non-deletion request (NOT_APPLICABLE).
    """
    if not text or not isinstance(text, str):
        return True # Default to True if empty, unless explicitly non-deletion
    
    t = text.lower().strip()
    
    # Specific non-deletion patterns
    non_deletion_patterns = [
        r'keep the account',
        r'leave my profile',
        r'leave my profile and purchase history in place',
        r'continue using the service',
        r"don't delete",
        r"do not delete",
        r'still use it',
        r'just want to download',
        r'only want a copy',
        r'please keep the account as it is',
        r'want to continue using the service',
        r'please don\'t delete or change anything',
        r'por favor mantenga la cuenta',
        r'bitte das konto behalten',
        r'veuillez garder le compte',
        r'アカウントを維持してください',
        r'削除しないでください',
    ]
    
    for pat in non_deletion_patterns:
        if re.search(pat, t):
            return False
            
    return True
