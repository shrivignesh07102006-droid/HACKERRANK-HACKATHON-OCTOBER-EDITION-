"""
code/policy.py - Deletion policy rules and canonical sorting for Ghost Data Still Exists.
Encodes the 15 deletion rules and exact priority order for Findings, Remediation, and Verification.
"""

from typing import Dict, Any, Tuple

PHASE_ORDER = {
    'FINDING': 1,
    'REMEDIATION': 2,
    'VERIFICATION': 3
}

OP_ORDER = {
    # Findings
    'REPORT_REMAINING_RECORD': 1,
    'REPORT_EXPOSED_PII': 2,
    'REPORT_ACTIVE_DATA_FLOW': 3,
    'REPORT_RESTORE_RISK': 4,
    
    # Remediation
    'DISABLE_DATA_FLOW': 1,
    'BLOCK_RESTORE': 2,
    'DELETE_RECORD': 3,
    'REDACT_RECORD': 4,
    'ANONYMIZE_RECORD': 5,
    
    # Verification
    'VERIFY_RECORD_ABSENT': 1,
    'VERIFY_RECORD_PRESENT': 2,
    'VERIFY_RECORD_REDACTED': 3,
    'VERIFY_RECORD_ANONYMIZED': 4,
    'VERIFY_DATA_FLOW_DISABLED': 5,
    'VERIFY_RESTORE_BLOCKED': 6,
}

# Mapping of data category to policy action
CATEGORY_ACTIONS = {
    'USER_PROFILE': 'DELETE',
    'SECONDARY_IDENTIFIER': 'DELETE',
    'SEARCH_INDEX_ENTRY': 'DELETE',
    'CACHE_ENTRY': 'DELETE',
    'SUPPORT_ATTACHMENT': 'DELETE',
    'USER_EXPORT': 'DELETE',
    'MARKETING_PROFILE': 'DELETE',
    
    'SUPPORT_MESSAGE': 'REDACT',
    'EMAIL_DELIVERY_LOG': 'REDACT',
    'ACCOUNT_TOMBSTONE': 'REDACT',
    
    'ANALYTICS_PROFILE': 'ANONYMIZE',
    'PRODUCT_TELEMETRY': 'ANONYMIZE',
    
    'SECURITY_AUDIT_LOG': 'RETAIN',
    'LEGAL_HOLD_RECORD': 'RETAIN',
    'BACKUP_ARCHIVE': 'RETAIN', # Restore access blocked
}

def step_sort_key(step: Dict[str, Any]) -> Tuple[int, int, str, str]:
    """
    Canonical sort key for steps:
    1. Phase (FINDING -> REMEDIATION -> VERIFICATION)
    2. Operation priority within phase
    3. system_id ascending
    4. resource_id ascending
    """
    p = PHASE_ORDER.get(step['phase'], 99)
    op = OP_ORDER.get(step['operation'], 99)
    sys_id = step.get('system_id', '')
    res_id = step.get('resource_id', '')
    return (p, op, sys_id, res_id)
