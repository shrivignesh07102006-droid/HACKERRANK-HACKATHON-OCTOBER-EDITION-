"""
code/test_scenarios.py - Reproducible Unit Tests for Deletion Audit Agent Scenarios.
Tests:
1. Non-deletion request intent handling
2. Multi-hop historical identity resolution
3. Remaining replica record detection (replication drift)
4. Exposed support attachment detection
5. Active background data flow detection and remediation
6. Backup restore risk detection and remediation
7. Retained security audit log preservation vs account tombstone redaction
"""

import os
import sys
import json
import unittest
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from identity import IdentityGraph
from intent import is_deletion_request
from policy import step_sort_key

class TestDeletionAuditScenarios(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        dataset_dir = 'dataset'
        cls.id_graph = IdentityGraph(dataset_dir)

    def test_01_non_deletion_request(self):
        """Scenario 1: Non-deletion request (access, export, or email change only)."""
        text = "Please change the email address used for this account. I want to continue using the service."
        self.assertFalse(is_deletion_request(text))
        
        del_text = "I request the permanent deletion and erasure of my personal account and data."
        self.assertTrue(is_deletion_request(del_text))

    def test_02_historical_identity_resolution(self):
        """Scenario 2: Request uses an old email that was changed in user_audit_log."""
        # Nadia Ionescu changed email to nadia.petrescu -> user_10
        sub = self.id_graph.resolve("nadia.ionescu@yahoo.com")
        self.assertIsNotNone(sub)
        self.assertEqual(sub.user_id, "user_10")
        self.assertIn("nadia.ionescu@yahoo.com", sub.all_emails)

    def test_03_remaining_replica_record(self):
        """Scenario 3: Failover replica still holds customer record while primary deleted it."""
        from auditor import DeletionAuditor
        auditor = DeletionAuditor('dataset')
        # Case 05 has replica drift in evidence_54
        samples = pd.read_csv('dataset/sample_deletion_requests.csv')
        c5 = samples[samples['case_id'] == 'case_05'].iloc[0]
        res = auditor.audit_case(c5)
        self.assertEqual(res.deletion_status, 'INCOMPLETE')
        findings = [s for s in res.steps if s['phase'] == 'FINDING']
        self.assertTrue(any(f['system_id'] == 'account_service' and f['resource_id'] == 'account_005' and f['evidence_id'] == 'evidence_54' for f in findings))

    def test_04_exposed_pii_in_support_attachment(self):
        """Scenario 4: Support attachment contains PII belonging to deletion subject."""
        from auditor import DeletionAuditor
        auditor = DeletionAuditor('dataset')
        # Case 07 has support attachment in evidence_58
        samples = pd.read_csv('dataset/sample_deletion_requests.csv')
        c7 = samples[samples['case_id'] == 'case_07'].iloc[0]
        res = auditor.audit_case(c7)
        self.assertEqual(res.deletion_status, 'INCOMPLETE')
        findings = [s for s in res.steps if s['phase'] == 'FINDING']
        self.assertTrue(any(f['resource_id'] == 'support_001' and f['evidence_id'] == 'evidence_58' for f in findings))

    def test_05_active_data_flow(self):
        """Scenario 5: Active background data flow that can replicate customer data."""
        from auditor import DeletionAuditor
        auditor = DeletionAuditor('dataset')
        # Case 15 has data flow 9846
        samples = pd.read_csv('dataset/sample_deletion_requests.csv')
        c15 = samples[samples['case_id'] == 'case_15'].iloc[0]
        res = auditor.audit_case(c15)
        self.assertEqual(res.deletion_status, 'INCOMPLETE')
        remediations = [s for s in res.steps if s['phase'] == 'REMEDIATION']
        self.assertTrue(any(r['operation'] == 'DISABLE_DATA_FLOW' and r['state'] == 'DISABLED' for r in remediations))

    def test_06_restore_risk(self):
        """Scenario 6: Backup snapshot has restore_allowed=True."""
        from auditor import DeletionAuditor
        auditor = DeletionAuditor('dataset')
        # Case 09 has backup restore risk in evidence_93
        samples = pd.read_csv('dataset/sample_deletion_requests.csv')
        c9 = samples[samples['case_id'] == 'case_09'].iloc[0]
        res = auditor.audit_case(c9)
        self.assertEqual(res.deletion_status, 'INCOMPLETE')
        remediations = [s for s in res.steps if s['phase'] == 'REMEDIATION']
        self.assertTrue(any(r['operation'] == 'BLOCK_RESTORE' and r['state'] == 'BLOCKED' for r in remediations))

    def test_07_tombstone_and_retained_records(self):
        """Scenario 7: Retained audit log remains PRESENT, tombstone is REDACTED."""
        from auditor import DeletionAuditor
        auditor = DeletionAuditor('dataset')
        # Case 31 has compliant tombstone and audit log
        samples = pd.read_csv('dataset/sample_deletion_requests.csv')
        c31 = samples[samples['case_id'] == 'case_31'].iloc[0]
        res = auditor.audit_case(c31)
        self.assertEqual(res.deletion_status, 'COMPLETE')
        verifs = [s for s in res.steps if s['phase'] == 'VERIFICATION']
        self.assertTrue(any(v['system_id'] == 'security_service' and v['state'] == 'PRESENT' for v in verifs))
        self.assertTrue(any(v['system_id'] == 'identity_service' and v['state'] == 'REDACTED' for v in verifs))

if __name__ == '__main__':
    unittest.main()
